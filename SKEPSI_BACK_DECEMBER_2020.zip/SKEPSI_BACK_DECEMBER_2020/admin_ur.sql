-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 03, 2020 at 04:43 PM
-- Server version: 10.2.36-MariaDB
-- PHP Version: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin_ur`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'periklisur', 'dfc84cbf22367af2ed122e7948bc84a0');

-- --------------------------------------------------------

--
-- Table structure for table `groupons`
--

CREATE TABLE `groupons` (
  `id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `code` varchar(100) NOT NULL,
  `used` int(1) NOT NULL DEFAULT 0,
  `assets` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groupons`
--

INSERT INTO `groupons` (`id`, `u_id`, `code`, `used`, `assets`) VALUES
(31, 123, '15700dc7210e78', 1, 0),
(32, 101, '25700dc7211262', 1, 1),
(33, 0, '35700dc721164b', 0, 1),
(34, 0, '45700dc7211a31', 0, 1),
(35, 0, '05701159d10439', 0, 1),
(36, 0, '15701159d10821', 0, 1),
(37, 0, '25701159d10c0f', 0, 1),
(38, 0, '35701159d10ff2', 0, 1),
(39, 0, '45701159d113d9', 0, 1),
(40, 0, '0570115a3dfc5b', 0, 1),
(41, 0, '05704bf143d36b', 0, 1),
(42, 0, '15704bf143d752', 0, 1),
(43, 0, '25704bf143db3a', 0, 1),
(47, 9, '0571ca5082e199', 1, 1),
(48, 9, '1571ca5082e5ed', 1, 1),
(49, 111, '05778eb1a67890', 1, 0),
(50, 16, '15778eb1a67c79', 1, 0),
(51, 15, '25778eb1a68063', 1, 0),
(52, 13, '35778eb1a68443', 1, 0),
(53, 0, '05827a3dac2469', 0, 1),
(54, 94, '15827a3dac250a', 1, 0),
(55, 17, '0587bc36b321b4', 1, 1),
(56, 1, '05884c2a22ec6b', 1, 1),
(57, 18, '15884c2a22ecca', 1, 1),
(58, 98, '25884c2a22ed17', 1, 1),
(59, 1, '35884c2a22ed5f', 1, 1),
(60, 0, '45884c2a22eda6', 0, 1),
(61, 1, '0588513512bba4', 1, 1),
(62, 1, '1588513512bc06', 1, 1),
(63, 1, '2588513512bc5e', 1, 1),
(64, 1, '0588543f250020', 1, 0),
(65, 1, '1588543f250087', 1, 1),
(66, 0, '2588543f2500df', 0, 0),
(67, 19, '05887ade5b84d1', 1, 1),
(68, 0, '05887b652adb8b', 0, 1),
(69, 20, '05888732e05c04', 1, 1),
(70, 21, '05888785747aec', 1, 1),
(71, 45, '05889e89a9b9e6', 1, 1),
(72, 0, '0588f47741be19', 0, 1),
(73, 0, '1588f47741be7d', 0, 1),
(74, 0, '058a18a20e5ba4', 0, 0),
(75, 0, '058ca86da5fa6b', 0, 0),
(76, 90, '05aa1195ef2024', 1, 1),
(77, 0, '05c891040241fe', 0, 1),
(78, 0, '15c89104024236', 0, 1),
(79, 92, '05c93b3d65f8bc', 1, 1),
(80, 110, '05dd23fe81d308', 1, 0),
(81, 0, '05e35cc6628259', 0, 0),
(82, 96, '15e35cc6628290', 1, 0),
(83, 94, '25e35cc66282c6', 1, 0),
(84, 0, '35e35cc66282fc', 0, 0),
(85, 97, '05e40436ecd532', 1, 1),
(86, 98, '05e428608e248d', 1, 0),
(90, 94, '25e5a3c6a8bf8a', 1, 0),
(91, 96, '35e5a3c6a8c372', 1, 0),
(92, 96, '45e5a3c6a8c75a', 1, 0),
(93, 18, '05e5a916236d99', 1, 0),
(94, 109, '05e5aa167865a1', 1, 0),
(95, 96, '05e5aca60c7dbb', 1, 0),
(96, 94, '05e5acab07c12a', 1, 0),
(97, 108, '05e5ae114f116f', 1, 0),
(100, 109, '05e5b48da53cab', 1, 0),
(101, 109, '05e5b4923986d4', 1, 0),
(103, 109, '05e5fdc5a69e29', 1, 0),
(104, 0, '05e5fddfbf4211', 0, 0),
(105, 109, '15e5fddfbf4213', 1, 0),
(107, 0, '05e5fdf84da838', 0, 0),
(108, 0, '15e5fdf84da83c', 0, 0),
(109, 0, '25e5fdf84da83d', 0, 0),
(110, 0, '35e5fdf84da83e', 0, 0),
(111, 110, '45e5fdf84da83f', 1, 0),
(112, 109, '05e5fdf94481ba', 1, 0),
(113, 111, '05e5ff1860b64e', 1, 0),
(114, 110, '05e6241cab7986', 1, 0),
(115, 110, '05e62428724fb0', 1, 0),
(116, 110, '05e62465e5bfb8', 1, 0),
(117, 110, '05e624f65a4451', 1, 0),
(118, 110, '05e62577bb5479', 1, 0),
(119, 109, '05e627952dcf4a', 1, 0),
(120, 109, '05e6279a22e646', 1, 0),
(121, 109, '05e6279d08950b', 1, 0),
(122, 109, '15e6279d08950f', 1, 0),
(123, 110, '05e628a96b9613', 1, 0),
(124, 110, '05e628b1e10929', 1, 0),
(125, 109, '05e628b71396d6', 1, 0),
(126, 110, '05e629235e4f6d', 1, 0),
(127, 110, '05e62930bbc87a', 1, 0),
(128, 111, '05e62bef6e40e6', 1, 0),
(129, 109, '05e63ad5a29cb9', 1, 0),
(130, 111, '05e63ae8021dff', 1, 0),
(131, 109, '05e63c3400679c', 1, 0),
(132, 110, '05e63f9dfc63b5', 1, 0),
(133, 110, '15e63f9dfc63b7', 1, 0),
(134, 97, '25e63f9dfc63b8', 1, 0),
(135, 0, '05e641e5a5dfd0', 0, 0),
(136, 0, '15e641e5a5dfd4', 0, 0),
(137, 97, '05e64d9af123b9', 1, 0),
(138, 111, '05e64e5eb3ceeb', 1, 0),
(139, 0, '05e65346513c49', 0, 0),
(140, 0, '15e65346513c4b', 0, 0),
(141, 115, '05e654b3ab66d8', 1, 0),
(142, 114, '15e654b3ab66da', 1, 0),
(143, 0, '05e65eb6d79d23', 0, 0),
(144, 0, '05e6687d272057', 0, 0),
(145, 0, '05e677ecda0006', 0, 0),
(146, 0, '15e677ecda000a', 0, 0),
(147, 0, '25e677ecda000b', 0, 0),
(148, 0, '35e677ecda000c', 0, 0),
(149, 0, '05e6a486eacda7', 0, 0),
(150, 0, '15e6a486eacdaa', 0, 0),
(151, 0, '25e6a486eacdab', 0, 0),
(152, 0, '35e6a486eacdac', 0, 0),
(153, 0, '05e6a491bedd89', 0, 0),
(154, 116, '05e6a5af6e6bf4', 1, 0),
(155, 0, '05e6a6a3e0d0bc', 0, 0),
(156, 0, '15e6a6a3e0d0c0', 0, 0),
(157, 111, '05e6c79de47d2b', 1, 0),
(158, 97, '05fba535819b71', 1, 0),
(159, 97, '05fba545a16abc', 1, 0),
(160, 97, '05fba54b136651', 1, 0),
(161, 97, '05fba56192fb48', 1, 0),
(162, 0, '05fbaa4ca82103', 0, 0),
(163, 0, '15fbaa4ca82107', 0, 0),
(164, 97, '05fbb61b7279d6', 1, 0),
(165, 97, '05fbb6237a6340', 1, 0),
(166, 0, '05fbbf8e975104', 0, 0),
(167, 119, '15fbbf8e975108', 1, 0),
(168, 0, '25fbbf8e975109', 0, 0),
(169, 0, '35fbbf8e97510a', 0, 0),
(170, 118, '45fbbf8e97510b', 1, 0),
(171, 0, '05fbe270a9e6be', 0, 0),
(172, 0, '15fbe270a9e6c0', 0, 0),
(173, 109, '05fbea220e5ff2', 1, 0),
(174, 97, '05fbeb192f16da', 1, 0),
(175, 125, '05fbeb7c791a50', 1, 0),
(176, 97, '05fbeb86b28aa2', 1, 0),
(177, 97, '05fbeb91d73dc8', 1, 0),
(178, 97, '05fbed7b4c29cf', 1, 0),
(179, 0, '15fbed7b4c29d6', 0, 0),
(180, 0, '25fbed7b4c29d7', 0, 0),
(181, 97, '05fbedca4ead92', 1, 0),
(182, 0, '05fbffbd9b4baf', 0, 0),
(183, 97, '05fc3af5419700', 1, 0),
(184, 130, '05fc3cf2dbb06a', 1, 0),
(185, 109, '05fc66a34953fc', 1, 0),
(186, 132, '05fc7c4a7af427', 1, 0),
(187, 0, '15fc7c4a7af42b', 0, 0),
(188, 0, '25fc7c4a7af42c', 0, 0),
(189, 0, '35fc7c4a7af42d', 0, 0),
(190, 0, '45fc7c4a7af42e', 0, 0),
(191, 0, '05fc8c233c1375', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `letter_type`
--

CREATE TABLE `letter_type` (
  `id` int(11) NOT NULL,
  `letter` varchar(1) NOT NULL,
  `l_body` text NOT NULL,
  `l_body_en` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `letter_type`
--

INSERT INTO `letter_type` (`id`, `letter`, `l_body`, `l_body_en`) VALUES
(1, 'E', 'Το Ε πιθανότατα να σημαίνει πως ταυτίζεστε περισσότερο με τον εξωτερικό κόσμο των ανθρώπων των πραγμάτων απ\' ότι  με τον εσωτερικό. Οι τύποι Ε προτιμούν την ματαιοδοξία και τη δράση, συχνά είναι καλοί στις νέες γνωριμίες και δεν είναι υπομονετικοί με τις μεγάλες και αργές εργασίες, συχνά παίρνουν γρήγορα αποφάσεις, μερικές φορές χωρίς να το σκεφτούν, τους αρέσει να βρίσκονται με ανθρώπους γύρω τους και συνήθως δεν έχουν πρόβλημα επικοινωνίας.', 'E probably means that you identify more with the outside world of people rather than the inside. E types prefer vanity and action, they are often good at meeting new people and are not patient with the long and slow tasks, often they make quick decisions, sometimes without thinking too much, they like being around people and usually do not have communication issues.'),
(2, 'S', 'Το S πιθανότατα να σημαίνει πως σας αρέσει περισσότερο να δουλεύετε με δεδομένα παρά να έχετε απέναντί σας νέες πιθανότητες και σχέσεις. Οι τύποι  S  δεν αρέσκονται ν\' αντιμετωπίζουν νέα προβλήματα, εκτός αν η επίλυσή τους ακολουθεί δεδομένους τρόπους, τους αρέσει να ακολουθούν κάποιο συγκεκριμένο τρόπο όταν κάνουν πράγματα, τους αρέσει ν\' ακολουθούν τρόπους που ήδη έχουν μάθει αντί να μαθαίνουν νέους, είναι πολύ καλοί σε εργασίες που απαιτούν ακρίβεια και δείχνουν υπομονετικοί με λεπτομέρειες ρουτίνας.', 'S probably means that you enjoy working with data rather than new opportunities and relationships. S types do not like to face new problems, unless the ways to solve them are given, they like to follow a certain route when doing things, they prefer ways they are already familiar with instead of learning new ones, they are very good at tasks that require precision and are patient with routine details.'),
(3, 'T', 'Το Τ πιθανότατα να σημαίνει πως βασίζεστε περισσότερο στη κρίση σας παρά σε απρόσωπες αναλύσεις και στη λογική παρά στις προσωπικές αξίες. Οι τύποι Τ δεν δείχνουν εύκολα τα συναισθήματά τους και συνήθως δεν αισθάνονται εύκολα όταν έχουν ν\' αντιμετωπίσουν τα συναισθήματα των άλλων, μπορεί να πληγώσουν τους άλλους χωρίς να το καταλάβουν, τους αρέσει η ανάλυση και να βάζουν τα πράγματα σε μία λογική σειρά, οι αποφάσεις τους είναι απρόσωπες, μερικές φορές δεν δείχνουν το απαραίτητο ενδιαφέρον επιπλήττουν τους άλλους και μπορούν να τους χρησιμοποιήσουν όταν το θεωρήσουν αναγκαίο.', 'T probably means that you rely more on your own judgment and the logic rather than on impersonal analysis and personal values. T types do not express their emotions and usually feel uneasy when they have to deal with emotions of others, they may hurt others without realizing it, they like to analyse and put things in a logical order, decisions they make are impersonal, sometimes do not show the required interest, they scold others, and can use them when they consider it necessary.'),
(4, 'J', 'Το J πιθανότατα να σημαίνει πως σας αρέσει η ζωή σας να είναι οργανωμένη παρά ευέλικτη και τυχαία. Οι τύποι J λειτουργούν καλύτερα όταν μπορούν να προγραμματίσουν την εργασία τους και ακολουθούν αυτό το πρόγραμμα, τους αρέσει τα πάντα να είναι οργανωμένα, μπορεί να παίρνουν γρήγορα αποφάσεις, δεν τους αρέσει να τους διακόπτουν όταν έχουν κάτι να κάνουν και είναι πολύ καλοί για επείγοντα πράγματα.', 'J probably means that you like your life to be organized rather than flexible and random. J types work best when they can plan their work and follow this schedule, they like everything to be organized, they can make quick decisions, they don\'t like being interrupted when they have to do something and they are great at resolving urgent matters. '),
(5, 'I', 'Το Ι πιθανότατα σημαίνει πως σας αρέσει περισσότερο να ταυτίζεστε με τον εσωτερικό κόσμο των ιδεών απ\' ότι με τον εξωτερικό κόσμο των ανθρώπων και των πραγμάτων. Οι τύποι Ι  είναι συνήθως ήρεμοι, τείνουν να δίνουν προσοχή στη λεπτομέρεια, δεν τους αρέσουν τα μεγάλα λόγια, δεν μπορούν να θυμηθούν ονόματα και πρόσωπα, δεν τους αρέσει να μιλούν στο τηλέφωνο ή να τους διακόπτουν, προτιμούν να δουλεύουν μόνοι και αντιμετωπίζουν προβλήματα στην επικοινωνία τους με τους άλλους.', 'I probably means that you like to identify with the inner world of ideas rather than the outer world of people and things. I types are usually calm, tend to pay attention to detail, they don\'t like to hear big promises, they can\'t remember names and faces, they don\'t like talking on the phone or being interrupted, they prefer working alone and have communication issues with others.'),
(6, 'N', 'Το Ν πιθανότατα σημαίνει πως σας αρέσει να δίνετε σημασία στις πιθανότητες και στις σχέσεις παρά σε πράγματα γνωστά και δεδομένα. Οι τύποι Ν αρέσκονται να λύνουν νέα προβλήματα, δεν τους αρέσουν πράγματα που επαναλαμβάνονται, τους αρέσει να μαθαίνουν νέα πράγματα χωρίς να τα χρησιμοποιούν, στην εργασία τους είναι γεμάτοι ζωτικότητα και ενθουσιασμό, βγάζουν εύκολα συμπεράσματα και δεν έχουν υπομονή με λεπτομέρειες ρουτίνας.', 'N probably means that you like to focus on chances and relationships rather than on things known and given. N types like to solve new problems, they don\'t like repetitive things, they like to learn new things without necessarily applying them, they are full of vitality and enthusiasm in their work, they come easy to conclusions and they are not patient with routine details.'),
(7, 'F', 'Το F πιθανότατα να σημαίνει πως βασίζετε τις κρίσεις σας περισσότερο στις προσωπικές αξίες παρά στην απρόσωπη ανάλυση και στη λογική. Οι τύποι F έχουν επίγνωση της ύπαρξης των άλλων και των συναισθημάτων τους, τους αρέσει να διασκεδάζουν τους άλλους ακόμα και για πράγματα ασήμαντα, δεν τους αρέσει να λένε στους άλλους πράγματα δυσάρεστα και τους αρέσει η αρμονία.', 'F probably means that you base your judgment mainly on personal values rather than on impersonal analysis and logic. F types are aware of the existence of others and their emotions, they like to entertain others even for trivial things, they do not like to tell others unpleasant things and they like harmony.'),
(8, 'P', 'Το Ρ πιθανότατα να σημαίνει πως σας αρέσει ένας ευέλικτος τρόπος ζωής περισσότερο από ένα καλά οργανωμένο. Οι τύποι Ρ  προσαρμόζονται εύκολα στις αλλαγές, δεν τους πειράζει να αφήνουν χώρο για το ενδεχόμενο αλλαγών, μπορεί να αντιμετωπίζουν προβλήματα στη λήψη αποφάσεων και ίσως να ξεκινήσουν πολλά πράγματα και να μην τα τελειώσουν.', 'P probably means that you like a more flexible lifestyle than a well-organized one. P types are easy to adapt to change, they don\'t mind leaving room for potential change, they may have trouble making decisions and they may start many things without finishing them.');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `txn_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_gross` float(10,2) NOT NULL,
  `currency_code` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `payer_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `internalcode` varchar(100) CHARACTER SET utf8 NOT NULL,
  `ventor` varchar(255) CHARACTER SET utf8 NOT NULL,
  `date` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`payment_id`, `user_id`, `product_id`, `txn_id`, `payment_gross`, `currency_code`, `payer_email`, `payment_status`, `internalcode`, `ventor`, `date`) VALUES
(4, 109, 1122, '1S478595XP356711U', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', '00:00:00'),
(5, 5, 1122, '59612637BN361681G', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', '00:00:00'),
(6, 5, 1122, '92B51507L7694634L', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', '00:00:00'),
(7, 5, 1122, '7CM52347TE907114R', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', '00:00:00'),
(8, 5, 1122, '3CK44943EP942671E', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', '00:00:00'),
(9, 5, 1122, '6YJ14811A8444480A', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', '', '5fbbbb1305c5b', 'PayPal', '1606138671'),
(10, 5, 1122, '6YJ14811A8444480A', 15.00, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', ''),
(11, 5, 1122, '3KG01342HA054132C', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', '', '5fbeaf8a83182', 'PayPal', '1606332332'),
(12, 5, 1122, '3KG01342HA054132C', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', ''),
(13, 5, 1122, '1G180755C45033118', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', '', '5fbeda21a89e3', 'PayPal', '1606343229'),
(14, 5, 1122, '1G180755C45033118', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', ''),
(15, 5, 1122, '3VB518521J702482D', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', '', '5fbeda8a33e5e', 'PayPal', '1606343505'),
(16, 5, 1122, '3VB518521J702482D', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', ''),
(17, 5, 1122, '43665832CU771742A', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', '', '5fc3ac316819e', 'PayPal', '1606659179'),
(18, 5, 1122, '43665832CU771742A', 4.99, 'EUR', 'RENAKTOROU@NETHOUSE.GR', 'Completed', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` float(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `image`, `price`, `status`) VALUES
(1122, 'TEST ONLINE', '', 15.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `steps` int(2) NOT NULL,
  `payment` int(1) NOT NULL DEFAULT 0,
  `light_blue` int(3) NOT NULL,
  `blue` int(3) NOT NULL,
  `yellow` int(3) NOT NULL,
  `orange` int(3) NOT NULL,
  `green` int(3) NOT NULL,
  `brown` int(3) NOT NULL,
  `red` int(3) NOT NULL,
  `pink` int(3) NOT NULL,
  `left_sum` int(4) NOT NULL,
  `right_sum` int(4) NOT NULL,
  `charact` varchar(4) NOT NULL,
  `finish` int(1) NOT NULL DEFAULT 0,
  `date` int(100) DEFAULT NULL,
  `code` varchar(100) NOT NULL,
  `internalcode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`id`, `u_id`, `steps`, `payment`, `light_blue`, `blue`, `yellow`, `orange`, `green`, `brown`, `red`, `pink`, `left_sum`, `right_sum`, `charact`, `finish`, `date`, `code`, `internalcode`) VALUES
(1, 1, 50, 1, 14, 1, 11, 4, 12, 6, 12, 6, 49, 17, 'ESTJ', 1, 1459534649, '', ''),
(2, 2, 50, 1, 10, 5, 8, 8, 7, 9, 5, 12, 30, 34, 'ENFP', 1, 1459537283, '', ''),
(3, 7, 50, 1, 8, 8, 14, 4, 18, 2, 17, 0, 57, 14, 'ISTJ', 1, 1460019674, '8906785442572601', ''),
(4, 3, 50, 1, 9, 8, 12, 5, 6, 10, 8, 8, 35, 31, 'ESFP', 1, 1459588061, '1632018749572603', ''),
(5, 5, 50, 1, 10, 7, 17, 4, 4, 10, 7, 10, 38, 31, 'ESFP', 1, 1459680157, '4842959352072600', ''),
(6, 6, 50, 1, 9, 6, 16, 5, 8, 7, 15, 2, 48, 20, 'ESTJ', 1, 1459683841, '', ''),
(7, 1, 50, 1, 10, 6, 11, 9, 6, 12, 14, 3, 41, 30, 'ESFJ', 1, 1485084883, '5198391572272602', ''),
(8, 8, 50, 1, 13, 5, 10, 10, 3, 9, 14, 3, 40, 27, 'ENFJ', 1, 1460019698, '', ''),
(9, 9, 50, 1, 10, 6, 9, 8, 11, 7, 10, 7, 40, 28, 'ESTJ', 1, 1461495545, '', ''),
(10, 9, 50, 1, 6, 10, 13, 5, 4, 12, 14, 2, 37, 29, 'ISFJ', 1, 1461496171, '', ''),
(11, 10, 50, 1, 4, 11, 13, 9, 20, 1, 8, 8, 45, 29, 'ISTP', 1, 1461867066, '4385751134372608', ''),
(12, 10, 50, 1, 7, 8, 8, 9, 17, 3, 7, 10, 39, 30, 'INTP', 1, 1461868436, '9470560464572607', ''),
(13, 11, 50, 1, 4, 10, 13, 5, 12, 7, 6, 9, 35, 31, 'ISTP', 1, 1461869707, '5212446968472601', ''),
(14, 10, 50, 1, 9, 7, 13, 7, 12, 7, 6, 10, 40, 31, 'ESTP', 1, 1461879580, '2078478827372605', ''),
(15, 10, 50, 1, 6, 11, 11, 7, 5, 12, 7, 9, 29, 39, 'ISFP', 1, 1461926203, '8628134058872609', ''),
(16, 10, 50, 1, 8, 9, 13, 4, 6, 9, 9, 6, 36, 28, 'ISFJ', 1, 1462003463, '5754091769572601', ''),
(17, 10, 50, 1, 5, 10, 14, 7, 4, 9, 6, 9, 29, 35, 'ISFP', 1, 1462004322, '6530350617572601', ''),
(18, 12, 50, 1, 6, 9, 8, 8, 5, 11, 10, 6, 29, 34, 'INFJ', 1, 1462292844, '6376670876372601', ''),
(19, 12, 50, 1, 11, 5, 8, 10, 11, 8, 9, 7, 39, 30, 'ENTJ', 1, 1463644712, '8987608427072601', ''),
(20, 12, 50, 1, 6, 10, 7, 9, 2, 11, 8, 8, 23, 38, 'INFP', 1, 1463646028, '6068055012572604', ''),
(21, 13, 50, 1, 8, 7, 11, 6, 15, 4, 14, 3, 48, 20, 'ESTJ', 1, 1467543359, '', ''),
(22, 15, 50, 1, 9, 7, 9, 9, 23, 1, 14, 3, 55, 20, 'ENTJ', 1, 1467544335, '', ''),
(23, 16, 50, 1, 8, 9, 9, 7, 10, 7, 6, 10, 33, 33, 'ISTP', 1, 1467546656, '', ''),
(24, 12, 50, 1, 7, 8, 4, 13, 8, 9, 12, 5, 31, 35, 'INFJ', 1, 1480280650, '6702707057272607', ''),
(25, 12, 50, 1, 5, 11, 10, 7, 12, 5, 12, 5, 39, 28, 'ISTJ', 1, 1483479507, '5586832984972600', ''),
(26, 17, 50, 1, 11, 6, 3, 11, 4, 10, 3, 13, 21, 40, 'ENFP', 1, 1484689684, '', ''),
(27, 1, 50, 1, 12, 6, 7, 8, 14, 5, 12, 4, 45, 23, 'ENTJ', 1, 1485092045, '5492435411572607', ''),
(28, 1, 50, 1, 5, 10, 15, 7, 16, 9, 5, 13, 41, 39, 'ISTP', 1, 1485096716, '', ''),
(29, 1, 50, 1, 4, 11, 10, 8, 18, 2, 2, 13, 34, 34, 'ISTP', 1, 1485098469, '', ''),
(30, 1, 50, 1, 5, 11, 11, 6, 18, 2, 11, 5, 45, 24, 'ISTJ', 1, 1485098907, '', ''),
(32, 18, 50, 1, 12, 5, 10, 7, 11, 6, 10, 6, 43, 24, 'ESTJ', 1, 1485100297, '', ''),
(33, 1, 50, 1, 5, 12, 0, 15, 20, 6, 3, 13, 28, 46, 'INTP', 1, 1485118481, '', ''),
(35, 1, 50, 1, 0, 16, 4, 13, 15, 5, 0, 17, 19, 51, 'INTP', 1, 1485118718, '', ''),
(36, 1, 50, 1, 0, 6, 4, 6, 6, 4, 0, 4, 10, 20, 'INTP', 1, 1485119875, '', ''),
(38, 1, 50, 1, 12, 6, 7, 8, 16, 4, 12, 4, 47, 22, 'ENTJ', 1, 1485120311, '', ''),
(39, 1, 50, 1, 0, 0, 0, 0, 2, 0, 0, 3, 2, 3, 'INTP', 1, 1485120420, '', ''),
(40, 1, 50, 1, 0, 0, 0, 0, 0, 1, 3, 2, 3, 3, 'INFJ', 1, 1485120513, '', ''),
(41, 1, 50, 1, 0, 0, 0, 0, 0, 1, 2, 0, 2, 1, 'INFJ', 1, 1485120921, '', ''),
(42, 1, 50, 1, 0, 0, 0, 0, 4, 0, 0, 3, 4, 3, 'INTP', 1, 1485125531, '', ''),
(43, 1, 50, 1, 0, 0, 0, 0, 2, 0, 0, 3, 2, 3, 'INTP', 1, 1485126921, '', ''),
(44, 1, 50, 1, 0, 0, 0, 0, 0, 2, 5, 0, 5, 2, 'INFJ', 1, 1485127955, '', ''),
(45, 1, 50, 1, 0, 0, 0, 0, 0, 1, 4, 0, 4, 1, 'INFJ', 1, 1485128383, '', ''),
(47, 1, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1485128868, '', ''),
(48, 1, 50, 1, 17, 0, 12, 2, 12, 6, 13, 3, 54, 11, 'ESTJ', 1, 1485185630, '', ''),
(49, 1, 50, 1, 14, 3, 14, 5, 10, 9, 17, 0, 55, 17, 'ESTJ', 1, 1485191896, '8988425190072607', ''),
(51, 19, 50, 1, 8, 8, 7, 9, 6, 9, 10, 7, 31, 33, 'INFJ', 1, 1485290644, '', ''),
(52, 20, 50, 1, 10, 9, 12, 6, 13, 6, 15, 2, 50, 23, 'ESTJ', 1, 1485338110, '', ''),
(53, 21, 50, 1, 1, 14, 9, 7, 5, 10, 14, 2, 29, 33, 'ISFJ', 1, 1485339244, '', ''),
(57, 45, 50, 1, 9, 7, 14, 6, 9, 7, 11, 5, 43, 25, 'ESTJ', 1, 1485518923, '', ''),
(60, 90, 50, 1, 7, 9, 6, 8, 17, 4, 6, 11, 36, 32, 'INTP', 1, 1520509762, '', ''),
(61, 92, 50, 1, 4, 12, 13, 7, 10, 9, 4, 13, 31, 41, 'ISTP', 1, 1553184346, '', ''),
(65, 98, 50, 1, 10, 4, 9, 9, 13, 5, 9, 7, 41, 25, 'ENTJ', 1, 1581418592, '', ''),
(66, 98, 50, 1, 0, 16, 10, 13, 12, 8, 0, 17, 22, 54, 'INTP', 1, 1582051552, '', ''),
(67, 98, 50, 1, 0, 16, 10, 13, 10, 9, 4, 13, 24, 51, 'INTP', 1, 1582574421, '', ''),
(69, 101, 50, 1, 5, 12, 7, 14, 12, 8, 5, 13, 29, 47, 'INTP', 1, 1582377473, '', ''),
(102, 110, 50, 1, 2, 14, 9, 10, 16, 5, 6, 11, 33, 40, 'INTP', 1, 1583518462, '', ''),
(103, 109, 50, 1, 7, 10, 20, 1, 9, 8, 17, 0, 53, 19, 'ISTJ', 1, 1583516767, '', ''),
(104, 110, 50, 1, 11, 4, 10, 12, 6, 12, 8, 9, 35, 37, 'ENFP', 1, 1583520338, '', ''),
(105, 111, 50, 1, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 'INTP', 1, 1583521266, '', ''),
(106, 111, 50, 1, 3, 0, 1, 4, 4, 0, 1, 3, 9, 7, 'ENTP', 1, 1583521806, '', ''),
(107, 111, 50, 1, 0, 0, 0, 0, 4, 0, 0, 2, 4, 2, 'INTP', 1, 1583522087, '7478255385972604', ''),
(108, 111, 50, 1, 0, 0, 0, 2, 4, 2, 4, 1, 8, 5, 'INTJ', 1, 1583524352, '1201840211572607', ''),
(111, 111, 50, 1, 2, 15, 11, 11, 12, 8, 5, 11, 30, 45, 'INTP', 1, 1583566210, '', ''),
(123, 109, 50, 1, 17, 0, 12, 2, 12, 6, 15, 2, 56, 10, 'ESTJ', 1, 1583590933, '', ''),
(124, 111, 50, 1, 0, 16, 10, 13, 10, 10, 2, 15, 22, 54, 'INFP', 1, 1583591144, '', ''),
(125, 109, 50, 1, 4, 11, 10, 8, 18, 2, 6, 11, 38, 32, 'ISTP', 1, 1583591367, '', ''),
(126, 109, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1583596185, '', ''),
(127, 109, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1583596450, '', ''),
(128, 109, 50, 1, 0, 16, 10, 13, 12, 8, 0, 17, 22, 54, 'INTP', 1, 1583596645, '', ''),
(129, 113, 50, 1, 9, 7, 10, 8, 12, 6, 8, 9, 39, 30, 'ESTP', 1, 1583599807, '', ''),
(130, 110, 50, 1, 0, 0, 0, 0, 4, 0, 0, 2, 4, 2, 'INTP', 1, 1583667910, '', ''),
(131, 110, 50, 1, 0, 0, 0, 0, 4, 0, 0, 2, 4, 2, 'INTP', 1, 1583669306, '', ''),
(132, 113, 50, 1, 5, 0, 5, 0, 0, 3, 5, 0, 15, 3, 'ESFJ', 1, 1583669708, '', ''),
(133, 112, 50, 1, 4, 11, 10, 8, 18, 2, 6, 11, 38, 32, 'ISTP', 1, 1583670820, '', ''),
(134, 111, 50, 1, 4, 11, 10, 8, 18, 2, 8, 10, 40, 31, 'ISTP', 1, 1583757055, '', ''),
(135, 97, 50, 1, 4, 11, 10, 8, 18, 2, 6, 11, 38, 32, 'ISTP', 1, 1583671130, '', ''),
(136, 114, 50, 1, 9, 8, 8, 9, 4, 11, 5, 11, 26, 39, 'ENFP', 1, 1583748383, '', ''),
(137, 115, 50, 1, 4, 13, 13, 6, 19, 3, 4, 12, 40, 34, 'ISTP', 1, 1583750678, '', ''),
(138, 109, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1583753051, '', ''),
(139, 109, 50, 1, 17, 0, 12, 2, 12, 6, 15, 2, 56, 10, 'ESTJ', 1, 1606058400, '', ''),
(140, 116, 50, 1, 10, 6, 9, 5, 9, 8, 12, 6, 40, 25, 'ESTJ', 1, 1584028966, '', ''),
(141, 111, 50, 1, 0, 16, 10, 13, 12, 8, 4, 13, 26, 50, 'INTP', 1, 1584169145, '', ''),
(144, 97, 50, 1, 13, 5, 18, 2, 6, 12, 17, 0, 54, 19, 'ESFJ', 1, 1606046637, '', ''),
(145, 97, 50, 1, 0, 0, 0, 0, 4, 0, 0, 3, 4, 3, 'INTP', 1, 1606046791, '6437984549072601', ''),
(146, 97, 50, 1, 0, 0, 0, 0, 2, 1, 0, 2, 2, 3, 'INTP', 1, 1606046840, '', ''),
(147, 97, 50, 1, 0, 16, 10, 13, 12, 8, 0, 17, 22, 54, 'INTP', 1, 1606046971, '', ''),
(148, 97, 50, 1, 17, 0, 12, 2, 12, 6, 15, 2, 56, 10, 'ESTJ', 1, 1606067045, '', ''),
(150, 111, 50, 1, 0, 16, 10, 13, 12, 8, 0, 17, 22, 54, 'INTP', 1, 1606114174, '', ''),
(155, 97, 50, 1, 10, 7, 10, 6, 18, 2, 9, 8, 47, 23, 'ESTJ', 1, 1606115885, '', ''),
(159, 97, 50, 1, 12, 3, 6, 10, 12, 6, 7, 10, 37, 29, 'ENTP', 1, 1606116030, '', ''),
(171, 97, 50, 1, 0, 16, 10, 13, 12, 8, 0, 15, 22, 52, 'INTP', 1, 1606138751, '6YJ14811A8444480A', '5fbbbb1305c5b'),
(172, 118, 50, 1, 8, 10, 13, 4, 16, 5, 11, 6, 48, 25, 'ISTJ', 1, 1606158480, '', ''),
(173, 119, 50, 1, 0, 16, 15, 6, 11, 5, 8, 8, 34, 35, 'ISTP', 1, 1606160751, '', ''),
(174, 109, 50, 1, 14, 1, 13, 4, 14, 5, 8, 10, 49, 20, 'ESTP', 1, 1606659094, '', ''),
(175, 122, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 1606332101, '', '5fbeaec517508'),
(176, 122, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 1606332116, '', '5fbeaed459dde'),
(177, 97, 50, 1, 1, 16, 15, 10, 17, 4, 6, 11, 39, 41, 'ISTP', 1, 1606332393, '3KG01342HA054132C', '5fbeaf8a83182'),
(178, 97, 50, 1, 17, 0, 18, 2, 12, 6, 12, 4, 59, 12, 'ESTJ', 1, 1606332675, '3809226674972605', ''),
(179, 97, 50, 1, 0, 16, 10, 13, 12, 8, 0, 17, 22, 54, 'INTP', 1, 1606332887, '', ''),
(181, 123, 50, 1, 4, 11, 10, 8, 18, 2, 6, 11, 38, 32, 'ISTP', 1, 1606334139, '', ''),
(182, 125, 50, 1, 17, 0, 18, 2, 8, 7, 13, 4, 56, 13, 'ESTJ', 1, 1606334470, '', ''),
(183, 97, 50, 1, 0, 16, 10, 13, 12, 8, 0, 17, 22, 54, 'INTP', 1, 1606334671, '', ''),
(184, 97, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1606334800, '', ''),
(188, 124, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 1606342464, '', '5fbed740ee614'),
(189, 124, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 0, 1606342475, '', '5fbed74b4b728'),
(195, 97, 50, 1, 4, 11, 10, 8, 14, 4, 6, 11, 34, 34, 'ISTP', 1, 1606342850, '', ''),
(196, 97, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1606343296, '1G180755C45033118', '5fbeda21a89e3'),
(197, 97, 50, 1, 4, 11, 10, 8, 18, 2, 6, 11, 38, 32, 'ISTP', 1, 1606343643, '3VB518521J702482D', '5fbeda8a33e5e'),
(198, 97, 50, 1, 17, 0, 12, 2, 12, 6, 17, 0, 58, 8, 'ESTJ', 1, 1606343756, '4558723023672601', ''),
(199, 97, 50, 1, 5, 10, 14, 8, 6, 12, 5, 13, 30, 43, 'ISFP', 1, 1606343917, '', ''),
(202, 109, 50, 1, 7, 9, 11, 8, 12, 10, 4, 14, 34, 41, 'ISTP', 1, 1606659237, '43665832CU771742A', '5fc3ac316819e'),
(203, 109, 50, 1, 5, 10, 11, 12, 12, 10, 2, 15, 30, 47, 'INTP', 1, 1606659431, '4160412777472601', ''),
(204, 97, 50, 1, 7, 9, 8, 8, 11, 8, 7, 10, 33, 35, 'INTP', 1, 1606660041, '', ''),
(205, 130, 50, 1, 0, 16, 10, 13, 12, 8, 0, 15, 22, 52, 'INTP', 1, 1606668164, '', ''),
(212, 109, 50, 1, 0, 16, 10, 13, 10, 9, 0, 17, 20, 55, 'INTP', 1, 1606839058, '', ''),
(213, 132, 11, 1, 2, 4, 3, 2, 4, 0, 3, 1, 0, 0, '', 0, 1606927615, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id` int(11) NOT NULL,
  `charact` varchar(4) NOT NULL,
  `desc` varchar(200) NOT NULL,
  `desc_en` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `body_en` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id`, `charact`, `desc`, `desc_en`, `body`, `body_en`) VALUES
(2, 'ISTJ', 'ΕΣΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'INTROVERT TYPES WITH PERCEPTION\r\n', 'Συμπερασματικά θα έλεγα πως οι τύποι ISTJ είναι άτομα σοβαρά, ήρεμα, που επιτυγχάνουν με την συγκέντρωση και την ολοκλήρωση. \r\nΠρακτικά, προγραμματισμένα, πραγματικά, λογικά, ρεαλιστικά και γενικά άτομα στα οποία μπορεί κάποιος να βασιστεί. \r\nΦροντίζουν να είναι τα πάντα πολύ καλά οργανωμένα. \r\nΑναλαμβάνουν υπευθυνότητες. \r\nΑποφασίζουν από μόνα τους ως προς το τί θα κάνουν και προχωρούν προς τον σκοπό τους με σταθερά βήματα, άσχετα με το τί θα έχουν ν’ αντιμετωπίσουν.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες που έχουν να κάνουν με γεγονότα και αντικείμενα, με αποτέλεσμα να γίνονται καλοί σε Εφαρμοσμένες Επιστήμες, σε Επιχειρήσεις στην Παραγωγή και την Κατασκευή.', 'In conclusion I would say that the ISTJ types is a person that is serious, calm and accomplished through concentration. A practical, organized, realistic and reasonable person, and in general a person that someone can rely on. A person that is always well organized and takes on responsibilities. A person that takes initiatives and targets a goal regardless of the difficulties to be faced.  '),
(3, 'ISFJ', 'ΕΣΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'INTROVERT TYPES WITH PERCEPTION', 'Συμπερασματικά θα έλεγα πως οι τύποι ISFJ είναι άτομα ήρεμα, φιλικά, υπεύθυνα και συνεπή. \r\nΦροντίζουν να καλύπτουν τις υποχρεώσεις τους. \r\nΠροσφέρουν τη σταθερότητα είτε στην εργασία που έχουν να επιτελέσουν είτε στην ομάδα με την οποία δουλεύουν μαζί.\r\n Ολοκληρωμένα, ακριβή άτομα που δεν διστάζουν να αναλάβουν δύσκολα πράγματα. \r\nΊσως να χρειαστούν χρόνο για να αποκτήσουν την πείρα που τους χρειάζεται, εφόσον τα ενδιαφέροντά τους δεν είναι τεχνικού περιεχομένου. \r\nΕίναι υπομονετικά με τις λεπτομέρειες, πιστά, διακριτικά άτομα που δείχνουν ενδιαφέρον για τα αισθήματα των άλλων.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες στην Πρακτική βοήθεια και παροχή υπηρεσιών στον κόσμο, με αποτέλεσμα να γίνονται καλοί στη Φροντίδα ασθενών, Παροχή υπηρεσιών σε κοινότητες, στις Πωλήσεις και την Εκπαίδευση.', 'In conclusion I would say that the ISFJ types is a calm, friendly, responsible and consistent person. A person that fulfils their obligations. Provides stability in the work and the team they work in. A whole, accurate person that does not hesitate to take on difficult tasks. It may take time for them to gain the experience they need, since their interests are not of technical character. They are patient with details, loyal, discreet and are interested in other peoples’ feelings.'),
(4, 'ISTP', 'ΕΣΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'INTROVERT TYPES WITH PERCEPTION', 'Συμπερασματικά θα έλεγα πως οι τύποι ISTP είναι ψυχρά άτομα, ήρεμα, επιφυλακτικά που παρατηρούν και αναλύουν την ζωή με ανεπηρέαστη περιέργεια και δόσεις πολύ καλού χιούμορ. \r\nΣυνήθως δείχνουν ενδιαφέρον για τις απρόσωπες αρχές, το αίτιον και το αιτιατόν, το πώς και γιατί λειτουργούν με τον τρόπο που λειτουργούν τα μηχανικά πράγματα. \r\nΔεν ασκούν μεγαλύτερη απ’ ότι πρέπει επιρροή γιατί δεν θέλουν να σπαταλούν αλόγιστα την ενεργητικότητά τους.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες που έχουν να κάνουν με γεγονότα και αντικείμενα, με αποτέλεσμα να γίνονται καλοί σε Εφαρμοσμένες Επιστήμες, σε Επιχειρήσεις στην Παραγωγή και την Κατασκευή.', 'In conclusion I would say that the ISTP types is a distant, calm and cautious person that observes and analyses life with unaffected curiosity and a good dose of humour. Usually shows interest in impersonal principles, in cause and effect, and in how and why mechanical things work the way they do. Does not want to spend energy for no particular reason and avoids to influence things around. '),
(5, 'ISFP', 'ΕΣΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'INTROVERT TYPES WITH PERCEPTION', 'Συμπερασματικά θα έλεγα πως οι τύποι ISFP είναι άτομα απομονωμένα, φιλικά, ευαίσθητα, καλά και μετριόφρονα ως προς τις δυνατότητες τους. Αποφεύγουν τις διαφωνίες και δεν επιβάλλουν τις απόψεις ή τις αξίες που έχουν στους άλλους. \r\nΣυνήθως δεν ενδιαφέρονται για αρχηγικές θέσεις, αλλά περιλαμβάνονται  στο πλήθος των πιστών οπαδών. \r\nΒλέπουν με ήρεμο τρόπο το πώς θα γίνουν τα πράγματα γιατί τείνουν να απολαμβάνουν το παρόν και δεν θέλουν να το σπαταλήσουν σε πράγματα άσκοπα.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες στην Πρακτική βοήθεια και παροχή υπηρεσιών στον κόσμο, με αποτέλεσμα να γίνονται καλοί στη Φροντίδα ασθενών, Παροχή υπηρεσιών σε κοινότητες, στις Πωλήσεις και την Εκπαίδευση.', 'In conclusion I would say that the ISFP type is an isolated, friendly, sensitive, kind and modest person. They avoid conflicts and do not impose their views or values on others. Usually are not interested in leadership positions, but consist the crowd of loyal fans. They examine things in a calm way because they tend to enjoy the present and do not want to waste it on unnecessary things.'),
(6, 'INFJ', 'ΕΣΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES INTROVERTS', 'Συμπερασματικά θα έλεγα πως ο τύπος INFJ είναι άτομα Άτομο που επιτυγχάνει με την επιμονή του, την πρωτοτυπία και την επιθυμία να κάνει ό,τι χρειάζεται ή του ζητήσουν. Στην δουλειά του προσφέρει το καλύτερο που μπορεί. Επιβάλλεται με ήρεμο τρόπο, είναι ευσυνείδητο και δείχνει ενδιαφέρον για τους άλλους. Γίνεται σεβαστό για τις σταθερές του αρχές. Πιθανότατα να τιμηθεί και να αποκτήσει οπαδούς γιατί οι πεποιθήσεις του αφορούν στην καλύτερη εξυπηρέτηση για ένα κοινό σκοπό.', 'In conclusion I would say that the INFJ type is a person who succeeds with their perseverance, originality and desire to do what they have to or are asked to do. In their job they do their best. They impose themselves in an easy way, are conscientious and show interest in other people. They are respected for their solid principles. They are likely to be honoured and obtain fans as their beliefs are about claiming a common cause.'),
(7, 'INTJ', 'ΕΣΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES INTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι INTJ είναι άτομα με πρωτότυπο συνήθως τρόπο σκέψης και μεγάλα κίνητρα για τις ιδέες και τους σκοπούς τους. \r\nΣτους τομείς που τους ενδιαφέρουν τείνουν  να είναι ιδιαίτερα οργανωτικά και να φέρουν σε πέρας μια εργασία με ή χωρίς βοήθεια. \r\nΆτομα που σκέπτονται, με κριτικό πνεύμα, ανεξάρτητο, αποφασιστικό, συχνά πεισματάρικο. Θα πρέπει να μάθουν να υποχωρούν ώστε να κερδίζουν το σημαντικότερο.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες σε Θεωρητικά και Τεχνικά επιτεύγματα, με αποτέλεσμα να γίνονται καλοί στις Φυσικές Επιστήμες, στην Έρευνα, την Οργάνωση και την Ανάλυση.', 'In conclusion I would say that the INTJ type is a person with original mindset and great motivation for their ideas and goals. In the areas of interest, they tend to be highly organized and are able to complete a task with or without assistance. A critical thinker, independent, decisive and often stubborn. They have to learn to retreat to be able to earn the most of it.'),
(8, 'INFP', 'ΕΣΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES INTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι INFP είναι άτομα με μεγάλο ενθουσιασμό και πίστη, όμως σπάνια ανοίγουν το στόμα τους για αυτά τους τα χαρίσματα παρά μόνο όταν γνωρίζουν πολύ καλά το άτομο που έχουν απέναντι τους. \r\nΔείχνουν θέληση για μάθηση, ενδιαφέρονται για νέες ιδέες, για τη γλώσσα και για τα ανεξάρτητα τους σχέδια. \r\nΤείνουν ν’ αναλαμβάνουν πολλά περισσότερα από όσα μπορούν. \r\nΕίναι φιλικά, αλλά συχνά βρίσκονται απορροφημένα σε αυτά που κάνουν και δεν φαίνονται κοινωνικά. \r\nΔεν ενδιαφέρονται τόσο για να αποκτήσουν πράγματα, ή για το φυσικό τους περιβάλλον.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες κατανόησης και επικοινωνίας με τον κόσμο με αποτέλεσμα να γίνονται καλοί  σε Επιστήμες της συμπεριφοράς, την Έρευνα, τη Λογοτεχνία, την Τέχνη και την Εκπαίδευση.', 'In conclusion I would say that the INFP types are people with great enthusiasm and faith, however, they rarely reveal their talents unless they know someone very well. They have willingness to learn, are interested in new ideas, language and independent projects. They tend to take on much more than they can handle. They are friendly, but they are often absorbed in what they do and do not look social. They are not interested in acquiring things, or in their natural environment.'),
(9, 'INTP', 'ΕΣΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES INTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι INTP είναι άτομα ήρεμα, επιφυλακτικά και άνευ προσωπικότητας. \r\nΑπολαμβάνουν ιδιαίτερα θεωρητικά και επιστημονικά θέματα. \r\nΗ λογική τους φτάνει σε τέτοιο σημείο που να σηκώνει τις τρίχες των άλλων. Συνήθως δείχνουν ενδιαφέρον κυρίως για τις ιδέες και όχι για τα πάρτι ή τις συζητήσεις. \r\nΤα ενδιαφέροντα τους είναι συγκεκριμένα. Απαιτούν καριέρες με μεγάλο ενδιαφέρον.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες μέσα σε Θεωρητικά και Τεχνικά επιτεύγματα, με αποτέλεσμα να γίνονται καλοί στις Φυσικές επιστήμες, την  Έρευνα, την Οργάνωση και την Ανάλυση. ', 'In conclusion I would say that the INTP types are calm, reserved and with no personality. They enjoy particularly theoretical and scientific subjects. Their high logic reaches to others. They are mainly interested in ideas and not in parties or discussions. Their interests are specific. They aim careers of great interest. '),
(10, 'ESTP', 'ΕΞΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'TYPES WITH PERCEPTION EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ESTP  είναι άτομα που έχουν τα πόδια τους στη γη, που δεν ανησυχούν ή βιάζονται και που απολαμβάνουν τα πράγματα έτσι όπως έρχονται. \r\nΈχουν τη τάση να τους αρέσουν τα μηχανικά πράγματα και ο αθλητισμός και να έχουν φίλους στο πλευρό τους. \r\nΜπορεί να δώσουν την εντύπωση των απότομων και αναίσθητων ατόμων. Προσαρμόζονται εύκολα, είναι ανεκτικά και γενικά συντηρητικά στις αξίες τους. Δεν τους αρέσουν οι μακροσκελείς εξηγήσεις. \r\nΤα καταφέρνουν πολύ καλά με πράγματα που είναι πραγματικά και που μπορούν να έχουν αποτέλεσμα, που μπορούν να τα επεξεργαστούν, να τα διαλύσουν και συνθέσουν ξανά.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες που έχουν να κάνουν με γεγονότα και αντικείμενα, με αποτέλεσμα να γίνονται καλοί σε Εφαρμοσμένες Επιστήμες, σε Επιχειρήσεις στην Παραγωγή και την Κατασκευή.', 'In conclusion I would say that the ESTP types are people who step on their feet, are not worried or in a hurry and enjoy things as they come. They tend to like mechanical things and sports and have friends by their side. They may give the impression of an abrupt and unconscious person. They are easily adapted, tolerant and generally conservative in their values. They don\'t like long explanations. They do well with things that are real and have output, and that can be processed, broken down and re-assembled.'),
(11, 'ESFP', 'ΕΞΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'TYPES WITH PERCEPTION EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ESFP είναι άτομα εξωστρεφή, εύκολα, που δέχονται, είναι φιλικά, απολαμβάνουν τα πάντα και σπάνε πλάκα με τους άλλους. \r\nΤους αρέσει ο αθλητισμός και να κατασκευάζουν πράγματα. \r\nΓνωρίζουν τί γίνεται και γίνονται αμέσως ένα με την υπόλοιπη παρέα. \r\nΗ μνήμη τους είναι καλή, αλλά δεν τα καταφέρνουν και τόσο καλά με τις θεωρίες.  Τα καταφέρνουν σε περιπτώσεις που απαιτείται η κοινή λογική και η πρακτικότητα τόσο με τους ανθρώπους όσο και με τα αντικείμενα.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες στην Πρακτική βοήθεια και παροχή υπηρεσιών στον κόσμο, με αποτέλεσμα να γίνονται καλοί στη Φροντίδα ασθενών, Παροχή υπηρεσιών σε κοινότητες, στις Πωλήσεις και την Εκπαίδευση.', 'In conclusion I would say that the ESFP types are Extroverts, easy-going people who are friendly, enjoy everything and have fun with others. They like sports and constructions. They know what is going on and immediately get along with the rest of the group. Their memory is good, but they don\'t do so well with theories. They do well in cases where common sense and practicality are needed both with humans and with objects.'),
(12, 'ESTJ', 'ΕΞΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'TYPES WITH PERCEPTION EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ESTJ είναι πρακτικά άτομα, ρεαλιστές και με τα πόδια να πατούν στη γη. \r\nΚλίνουν προς τις επιχειρήσεις και τη μηχανική.  \r\nΔεν τα ενδιαφέρουν θέματα για τα οποία πιστεύουν πως δεν έχουν καμία  χρησιμότητα, αλλά αν χρειαστεί μπορούν να ασχοληθούν και με τέτοια. \r\nΤους αρέσει να οργανώνουν και να αναλαμβάνουν δραστηριότητες.\r\nΓίνονται πολύ καλοί διευθυντές, ιδιαίτερα αν θυμηθούν να λαμβάνουν υπόψη τα συναισθήματα και τις απόψεις των άλλων.\r\n<br>\r\n Ακόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα Τεχνικές δυνατότητες που έχουν να κάνουν με γεγονότα και αντικείμενα  με αποτέλεσμα να γίνονται καλοί  σε Εφαρμοσμένες επιστήμες, σε Επιχειρήσεις, στην Παραγωγή και Κατασκευή.', 'In conclusion I would say that the ESTJ types are practical, realistic and down to earth people. They lean towards business and engineering. They are not interested in topics that they consider to be of no use, but they can also deal with them if needed. They like to organize and undertake activities. They become very good managers, especially if they remember to take into account the feelings and opinions of others.'),
(13, 'ESFJ', 'ΕΞΩΣΤΡΕΦΕΙΣ ΤΥΠΟΙ ΜΕ ΑΝΤΙΛΗΨΗ', 'TYPES WITH PERCEPTION EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ESFJ είναι άτομα με ζεστή καρδιά, ομιλητικά, δημοφιλή, ευσυνείδητα, γεννημένοι για συνεργάτες και για ενεργή δράση σε κοινότητες. \r\nΧρειάζονται αρμονία και ίσως να έχουν την ικανότητα να την δημιουργούν. Πάντα θα κάνουν κάτι που θα συγκινήσει τους άλλους. Δουλεύουν καλύτερα αν έχουν ενθάρρυνση και εγκώμια. \r\nΔεν δείχνουν ιδιαίτερο ενδιαφέρον για αφηρημένες σκέψεις ή τεχνικά θέματα. Το κύριο ενδιαφέρον τους τραβούν πράγματα που επηρεάζουν άμεσα τη ζωή των άλλων και που φαίνονται.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες στην Πρακτική βοήθεια και παροχή υπηρεσιών στον κόσμο, με αποτέλεσμα να γίνονται καλοί στη Φροντίδα ασθενών, Παροχή υπηρεσιών σε κοινότητες, στις Πωλήσεις και την Εκπαίδευση.', 'In conclusion I would say that the ESFJ types are people with a warm heart, talkative, popular, conscientious, born to be partners and to be active in communities. They need harmony and they may have the ability to create it. They always do something that excites others. They work best if they receive encouragement and praise. They are not particularly interested in abstract thoughts or technical issues. '),
(14, 'ENFP', 'ΕΞΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES  EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ENFP είναι άτομα που ενθουσιάζονται, έχουν πολύ καλή διάθεση, είναι ειλικρινή και έχουν φαντασία. \r\nΜπορούν να κάνουν σχεδόν τα πάντα όσα τα ενδιαφέρουν. \r\nΒρίσκουν γρήγορα λύσεις για την οποιαδήποτε δυσκολία και είναι έτοιμα να βοηθήσουν τον οποιονδήποτε να λύσει τα προβλήματα του. \r\nΣυχνά βασίζονται στη δυνατότητα τους να αυτοσχεδιάζουν αντί να προετοιμάζονται εκ των προτέρων. \r\nΣυνήθως βρίσκουν λόγους ανάγκης για το οτιδήποτε κάνουν.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες κατανόησης και επικοινωνίας με τον κόσμο με αποτέλεσμα να γίνονται καλοί στις επιστήμες της συμπεριφοράς, έρευνας, στη Λογοτεχνία την Τέχνη και την Εκπαίδευση.', 'In conclusion I would say that the ENFP types are people who are excited, have a good mood, are honest and have imagination. They can do almost anything that they are interested in. They are quick to find solutions to any difficulties and are ready to help anyone solve their problems. They often rely on their ability to improvise rather than prepare in advance. They usually find reasons for everything they do.'),
(15, 'ENTP', 'ΕΞΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES  EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ENTP είναι άτομα γρήγορα, ειλικρινή, και είναι καλά για πολλά πράγματα. \r\nΘεωρούνται τα ιδανικά για παρέα. \r\nΜπορεί να αμφισβητήσουν κάτι έτσι για πλάκα. \r\nΕίναι ευρηματικά στην επίλυση των προβλημάτων, αλλά ίσως να φέρουν αντιρρήσεις ως προς τη διαδικασία επίλυσης. \r\nΤείνουν να στρέφουν το ενδιαφέρον τους από το ένα πράγμα στο άλλο. Μπορούν να βρουν λογικές λύσεις για αυτά που θέλουν.\r\n<br>\r\n Ακόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες μέσα σε Θεωρητικά και Τεχνικά επιτεύγματα, με αποτέλεσμα να γίνονται καλοί στις Φυσικές επιστήμες, την  Έρευνα, την Οργάνωση και την Ανάλυση. ', 'In conclusion I would say that the ENTP types are fast and honest people who are good at many things. They are considered ideal for company. They may question something just for fun. They are inventive in solving problems, but they may have objections regarding the solution process. They tend to shift their interest from one thing to another. They can find reasonable solutions to what they want.'),
(16, 'ENFJ', 'ΕΞΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES  EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ENFJ είναι άτομα που ανταποκρίνονται και που είναι υπεύθυνα. \r\nΓενικά δείχνουν πραγματικό ενδιαφέρον για το τί σκέπτονται και θέλουν οι άλλοι και προσπαθούν να φέρουν τα πράγματα κατά τέτοιο τρόπο που να μην θίγουν τα συναισθήματα του άλλου. \r\nΜπορούν να παρουσιάσουν μία πρόταση ή να ηγηθούν της συζήτησης που θα έχει μία ομάδα με μεγάλη ευκολία και διακριτικότητα. \r\nΕίναι κοινωνικά, δημοφιλή, συμπαθητικά άτομα. Ανταποκρίνονται στους επαίνους και την κριτική.\r\n<br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες κατανόησης και επικοινωνίας με τον κόσμο με αποτέλεσμα να γίνονται καλοί  σε Επιστήμες της συμπεριφοράς, την Έρευνα, τη Λογοτεχνία, την Τέχνη και την Εκπαίδευση.', 'In conclusion I would say that the ENFJ types are responsive and responsible people. They generally show a genuine interest in what others think and want, and try to handle things in a way that does not affect other peoples’ feelings. They can present a proposal or lead the discussion of a group with ease and discretion. They are social, popular and nice people. They respond to praise and criticism.'),
(17, 'ENTJ', 'ΕΞΩΣΤΡΕΦΕΙΣ ΔΙΟΡΑΤΙΚΟΙ ΤΥΠΟΙ', 'INSIGHTFUL TYPES  EXTROVERTS', 'Συμπερασματικά θα έλεγα πως οι τύποι ENTJ είναι άτομα καλόκαρδα, ειλικρινή, αποφασιστικά, με δυνατότητες αρχηγού. \r\nΣυνήθως είναι πολύ καλά σε οτιδήποτε απαιτεί λογική και έξυπνη κουβέντα, π.χ. οι δημόσιοι λόγοι. \r\nΕίναι συνήθως καλά πληροφορημένα και τους αρέσει πάρα πολύ να πλουτίζουν τις γνώσεις τους. \r\nΜερικές φορές μπορεί να είναι παραπάνω θετικά και με μεγαλύτερη αυτοπεποίθηση από τις πραγματικές τους δυνατότητες.\r\n  <br>\r\nΑκόμη έχουν ή μπορούν να καλλιεργήσουν εύκολα δυνατότητες μέσα σε Θεωρητικά και Τεχνικά επιτεύγματα, με αποτέλεσμα να γίνονται καλοί στις Φυσικές επιστήμες, την  Έρευνα, την Οργάνωση και την Ανάλυση.', 'In conclusion I would say that the ENTJ types are good-hearted, honest, determined people with leadership abilities. They are usually very good at anything that requires rational and intelligent conversation, e.g. public speech. They are usually well-informed and very keen to enriching their knowledge. Sometimes they can be too positive and over-confident than their true potential.');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `yearbirthdate` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `gender`, `yearbirthdate`) VALUES
(1, 'xargrigoris@gmail.com', '670b14728ad9902aecba32e22fa4f6bd', 'male', '2016'),
(2, 'nikoskrem@yahoo.gr', '69d7c87b2eb9f25e613e5476284f9965', 'male', '1973'),
(3, 'cristos@gmail.com', '4360185baa0f8031694af85b3b58a7e9', 'male', '1982'),
(4, 'test@testaki.gt', '827ccb0eea8a706c4c34a16891f84e7b', 'male', '1950'),
(5, 'testexam@yahoo.gr', 'fc12b7efff1bab48513d44ab340d4d84', 'male', '1981'),
(6, 'mour.chris@gmail.com', '60784e47fb873748b42342ecaed0b5d2', 'male', '1958'),
(9, 'frankypap1979@gmail.com', '2c26a7afdc5237740189ff700328ea65', 'male', '2016'),
(10, 'antonis.thanos@yahoo.com', 'd6b7835b878d66223926e317a2d56dcb', 'male', '1997'),
(11, 'trikoul77@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'female', '1977'),
(12, 'thomas.thanos@hotmail.gr', 'baf9e5c44e6493ad35dffcc98114a970', 'male', '1990'),
(13, 'gepapadok@gmail.com', '9589ea31967dc559047029411df81ab5', 'male', '2002'),
(14, 'elpapadokostaki@hotmail.gr', 'c8c31f4fe1695444de51ffa38cbce671', 'male', '2016'),
(15, 'eleannapapadok@gmail.com', 'c8c31f4fe1695444de51ffa38cbce671', 'female', '2000'),
(16, 'gepapadok@sch.gr', '9589ea31967dc559047029411df81ab5', 'male', '1966'),
(17, 'aggoikon@yahoo.gr', '48c9f21cdd68281b5dbf39cc03f6bcec', 'female', '1969'),
(18, 'periklis@deos.gr', '6625f6491ace6f7ff40861a046da6040', 'male', '1973'),
(19, 'ekamaterou@hotmail.com', 'a337b2e88c97f0da47f989fec072a266', 'male', '2017'),
(20, 'arischry@yahoo.gr', '0b4138ff30a00863ce428516b2cfb865', 'male', '1967'),
(21, 'renaktorou@nethouse.gr', '95186dc455ea42884efac4e0fc1d9092', 'female', '1973'),
(22, 'stefmitsis@gmail.com', 'b3ad61476f363b62db87987553f5de1b', 'male', '1971'),
(23, 'papakikok@yahoo.com', '021e235b11b30dbac7012eaeeea89ff0', 'male', '1995'),
(24, 'georgiakor2003@gmail.com', '931550c86343342479d113caca2dfa5c', 'female', '2003'),
(25, 'kxyloportas13@gmail.com', 'b7eb8c960a736945eedd833bcd916d54', 'male', '2002'),
(26, 'giouli.giann@gmail.com', 'dd13267a386f96165bb9ee61823cc9f9', 'female', '1981'),
(27, 'argyrakos.iw@gmail.com', '102f5b78b2ab06dd18b411d25668dad3', 'male', '1999'),
(28, 'test@example.com', 'dcddb75469b4b4875094e14561e573d8', 'male', '2017'),
(29, 'yeiah1@hotmail.com', 'a468219194f2fb511b6697141f057519', 'male', '2017'),
(30, 'katrin1997katsika@gmail.com', '45610e622850f74b9600531df2b02619', 'female', '1997'),
(31, 'athanasiamp1998@gmail.com', '6ebe76c9fb411be97b3b0d48b791a7c9', 'female', '1999'),
(32, 'sotiriskaramanoglou@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'male', '1999'),
(33, 'maglakelitzemero@gmail.com', '645e6507769c25721f54575122c7834f', 'male', '2000'),
(34, 'elena.pournaraki@hotmail.com', '93ba40ee55ae450ce1e927aad753db8a', 'male', '2017'),
(35, 'sofia.papadimitrioy@gmail.com', '263af00974357cce217336c9790a6bf9', 'female', '1972'),
(36, 'geostouk@gmail.com', '329ba27f7c004309aa9ac862957b7a52', 'male', '2000'),
(37, 'peripap74@yahoo.com', '4ab41b95217b6962995f8c9d298895e3', 'male', '2017'),
(38, 'dimitrisdimakos@yahoo.gr', '4b08f780d4389def734af12a72586340', 'male', '1981'),
(39, 'sophaki_301_1d@hotmail.gr', '60f19d420b81d9f91e7f0c4e5c27c9a1', 'female', '2002'),
(40, 'lamp-18@hotmail.com', '21ce1aae5e659e52f78ce8e314a785c9', 'male', '2017'),
(41, 'moikanoss64@gmail.com', 'c98703aed69284552ffffea25a1706d9', 'male', '2017'),
(42, 'giannis_21@hotmail.gr', 'cad479c99b33395795ca90b1fa14ce06', 'male', '2017'),
(43, 'g.mourgelas@gmail.com', 'd87b7874440cd4437b8d694de13d05cf', 'male', '1999'),
(44, 'kwnstantina@example.com', 'c221bc7fe1748d4e374bf03e5bce288a', 'female', '2001'),
(45, 'melina.mega@yahoo.com', '40292501664380944538f672da44f4c3', 'male', '2017'),
(46, 'K.Eleutherios@gmail.com', 'cbe2430aea7f6f7c71112edbec7fc073', 'male', '2017'),
(47, 'riosrosso@hotmail.com', 'cbe2430aea7f6f7c71112edbec7fc073', 'male', '1996'),
(48, 'fettgd@gmail.com', '813e6c7384802bd654bba63a6e3f0d8f', 'female', '1998'),
(49, 'lalaoops73@gmail.com', '82c3e353ac3b4cea75f052e8bf4464ce', 'female', '1998'),
(50, 'tsartsarake@gmail.com', '3cd224eef85a54e80160ef7d9ed8cd56', 'female', '2002'),
(51, 'konstantinasma@hotmail.com', 'e33357a2a757de16d5cdef7cfb155204', 'female', '1985'),
(52, 'danai@hotmail.com', 'fdf14fa22b6f5da644a9c00bba99bc40', 'female', '2017'),
(53, 'rialampropoulou@hotmail.com', '3b53516768339b477ee7891cbe87c1f9', 'female', '1997'),
(54, 'elpsiha@hotmail.com', 'dffcc83a4d9c42323eb856df8f75b618', 'female', '2001'),
(55, 'popipapaz1252@gmail.com', '9df0399e4b716c098f214c755433a23a', 'male', '2000'),
(56, 'lydia.kalaitzidaki@gmail.com', '259e4d51d75828819996b86db7a75c4f', 'female', '2004'),
(57, 'mariakaristos@outlook.com', 'ca4f7f6c545f42ee2387e1836e5695d8', 'female', '1998'),
(58, 'xanthippi.kassoy@hotmail.gr', 'cd9ea8cbe1b1c357554503f5fd96e263', 'male', '2017'),
(59, 'ekrst@gmail.com', '057eeb885922360919cd9c1e76e13999', 'female', '2001'),
(60, 'marilena_masouri@gmail.com', '4ee9e56fcf67643fe960059c346bf5df', 'female', '2001'),
(61, 'hra.theod@gmail.com', 'c26116e530ac78ce16085d8880ee8c25', 'male', '1998'),
(62, 'mixalism2003@gmail.com', '3303bcc1f5a6a5aeefa8fe9bb7cf3a5c', 'male', '1994'),
(63, 'tountzel-tzan@hotmail.nl', '29833ab42f9a371d939df93a22961cf9', 'male', '2001'),
(64, 'giorgosziab@gmail.com', 'ba08a459b0d6015bf25f80fd0fb3e128', 'male', '1995'),
(65, 'katerinatzob123@gmail.com', '79def78c83bf5b2f88c56b97adac22fc', 'female', '1973'),
(66, 'ilias.wakeb@hotmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'male', '2017'),
(67, 'fanisk98@gmail.com', 'c12c6eb8636cf9d3da0b6a6728826b4c', 'male', '2017'),
(68, 'joannamita@gmail.com', 'c3c6bd8a11e328875e6c3be0d85b53bc', 'female', '2003'),
(69, 'test@exampleeee.com', '35bc8cec895861697a0243c1304c7789', 'male', '2017'),
(70, 'alexanderbrooks666@yahoo.gr', 'c76e18c3561df0efd3ecc34db16e63c6', 'male', '2017'),
(71, 'elsa@gmail.com', '8ab5d1c6f6baeac466157364976fc49b', 'male', '2017'),
(72, 'george.tdk@hotmail.com', '543e5f6b53298fd84c28314058add855', 'male', '1998'),
(73, 'jimboszz@hotmail.com', '7a8c61a45049dd80fca5520fedf0d241', 'male', '1997'),
(74, 'mar@sxolio.com', '059b35d7d35f5817957339948832cb53', 'female', '1999'),
(75, 'panostaek@gmail.com', 'df13e56ffbc1db98bad6a84dbf8d6837', 'male', '1983'),
(76, 'giannikiro@gmail.com', '53ae43c4655310d64c123fc25e620dce', 'male', '1998'),
(77, 'lamvi@hotmail.com', 'a620d644e3a2fbfe5a20dd722b56ed58', 'male', '2003'),
(78, 'tomasmilosmanolis@gmail.com', '2aab479ef5cee433e7767f8abf05faa6', 'male', '2001'),
(79, 'stelatoci0@gmail.com', '209414e1b04277690a00a77abc33b3c2', 'female', '1998'),
(80, 'dionisia.m10@gmail.com', 'e0450d97f7faa16edcdce7f1be0f1448', 'female', '1998'),
(81, 'DiyTube3@hotmail.gr', '8f06d5f74de32e128b22282be5c8f23d', 'female', '1993'),
(82, 'sonicfo@hotmail.com', '3d07f006c084e1197bf107c5364fddc6', 'female', '1994'),
(83, 'mich.pol@hotmail.com', '93ceafb6280915252715e717bd47de16', 'male', '2017'),
(84, 'melinaki232@gmail.com', 'f76d507e0507146dfb2cd188c1acc0b5', 'female', '2000'),
(85, 'likos13@hotmail.gr', '90b55733ac8f6780e29d9a7b69be0869', 'male', '2000'),
(86, 'andreasphilippatos@gmail.com', '87fc17b97452188a523b5de4e52135e7', 'male', '2017'),
(87, 'mauroukos02@yahoo.gr', '34819d7beeabb9260a5c854bc85b3e44', 'female', '1984'),
(88, 'elisavetkon@outlook.com', '30321cb304aa275cf76a5f136d33170a', 'female', '1985'),
(89, 'diegololita46@gmail.com', 'febc8f9e6e7ba1b00925f5672cabea9e', 'male', '2017'),
(90, 'an_kall1989@yahoo.gr', '711321f13321c246e46bd603e0d5e0e9', 'female', '1989'),
(91, 'bf9279@gmail.com', 'f373b9a5d91d57b7bc5c2cf81a067464', 'male', '2000'),
(92, 'kyriaki.domm@gmail.com', '0f2d96d0599a34c7b16aa63f7979911c', 'female', '2001'),
(93, 'konliaksos@yahoo.gr', '947599d56d9c3a20956d310e26f68ab2', 'male', '1974'),
(97, 'perispap@icloud.com', 'e10adc3949ba59abbe56e057f20f883e', 'male', '1973'),
(109, 'periklis@nethouse.gr', '6625f6491ace6f7ff40861a046da6040', 'male', '2020'),
(110, 'anastasis1722004@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'female', '2001'),
(111, 'bourlokas@yahoo.com', '6f67b24a8cca3f826bf64fe3e495b936', 'male', '2020'),
(112, 'g84u@msn.com', 'e10adc3949ba59abbe56e057f20f883e', 'male', '1973'),
(113, 'afentis@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'male', '1973'),
(114, 'kyriaki.papage@gmail.com', '0f2d96d0599a34c7b16aa63f7979911c', 'female', '2001'),
(115, 'jimvoulgaris14@gmail.com', '25f9e794323b453885f5181f1b624d0b', 'male', '2001'),
(116, 'akelepourims@gmail.com', 'efc96336142ca5eb33dbdba551433b59', 'female', '1975'),
(117, 'anastasiathanas@gmail.com', 'f82b2ac2741d0eb0c10d2632a03c8806', 'female', '1977'),
(118, 'malik.ismail254@gmail.com', 'd871cd2a36b26008ee87b34dc987dea8', 'male', '1998'),
(119, 'nimrarafique56@gmail.com', '09644372e99020106946045c6fd2d70b', 'female', '1997'),
(120, 'john12@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'male', '1967'),
(121, 'khatoonsobia87@gmail.com', '91c8c24699a52959a7c8b85f862e39ef', 'female', '1989'),
(122, 'bourlokas111@gmail.com', '6f67b24a8cca3f826bf64fe3e495b936', 'male', '1962'),
(123, 'bourlokas112@gmail.com', '6f67b24a8cca3f826bf64fe3e495b936', 'male', '1962'),
(124, 'bourlokas113@gmail.com', '6f67b24a8cca3f826bf64fe3e495b936', 'male', '1960'),
(127, 'test1@test.gr', 'e10adc3949ba59abbe56e057f20f883e', 'female', '1966'),
(128, 'bourlokas@gmail.com', '6f67b24a8cca3f826bf64fe3e495b936', 'male', '1960'),
(129, 'testo11@gmail.com', '6f67b24a8cca3f826bf64fe3e495b936', 'male', '1961'),
(130, 'webmaster@nethouse.gr', '6625f6491ace6f7ff40861a046da6040', 'male', '1973'),
(131, 'abc@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'male', '1956'),
(132, 'sobiakhatoon@gmail.com', 'fcea920f7412b5da7be0cf42b8c93759', 'female', '1990');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `groupons`
--
ALTER TABLE `groupons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `letter_type`
--
ALTER TABLE `letter_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `u_id` (`u_id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `groupons`
--
ALTER TABLE `groupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=192;

--
-- AUTO_INCREMENT for table `letter_type`
--
ALTER TABLE `letter_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1123;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=214;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
