<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Model {
     
     private $table = 'users';

    function __construct() {
        parent::__construct();
    }

    public function register($email = null, $pass = null, $gender = null, $yearbirthdate = null){

    	$this->db->insert($this->table, ['email' => $email, 'password' => md5($pass), 'gender' => $gender, 'yearbirthdate' => $yearbirthdate]);
        $this->session->set_userdata('login', true);
        $this->session->set_userdata('loged_id', $this->db->insert_id());
    }

    public function login($email = null, $pass = null){

        $user = $this->db->get_where($this->table, ['email' => $email, 'password' => md5($pass)])->num_rows();

        if($user == 0){
            return false;
        }else{
            return true;
        }
    }


    public function forgot($email = null){

    	$user = $this->db->get_where($this->table, ['email' => $email])->num_row();

    	if($user == 0){
    		return false;
    	}else{
    		return true;
    	}
    }

    public function is_login(){

        if(!$this->session->has_userdata('login') && !$this->session->has_userdata('loged_id')){
            redirect('user/login');
        }
    }

    public function is_login_with_save_step(){

        if($this->session->has_userdata('login') && $this->session->has_userdata('loged_id')){
            return true;
        }else{
            return false;
        }
    }

    public function is_login_return_boolean(){

        if($this->session->has_userdata('login') && $this->session->has_userdata('loged_id')){
            return true;
        }else{
            return false;
        }
    }


    public function start_test(){

        $record = $this->db->get_where('tests', ['u_id' => $this->session->userdata('loged_id'), 'finish' => 0])->num_rows();

        if ($record == 0) {
            $this->db->insert('tests', ['u_id' => $this->session->userdata('loged_id'), 'finish' => 0, 'date' => time()]);
        }elseif($record == 1){
           $this->db->where(['u_id' => $this->session->userdata('loged_id'), 'finish' => 0]);
           $this->db->limit(1);
           $step = $this->db->get('tests')->row('steps');

           if ($step != 0) {
               $step = ($step+1);
               redirect('home/step'.$step);
           }

            
        }
        
    }


    public function save_step($step = 0, $points = 0, $color = null){

        $this->db->where('u_id', $this->session->userdata('loged_id'));
        $this->db->where('finish', 0);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $steps = $this->db->get('tests')->row('steps');

        if((int)$steps){
            if(filter_var($this->uri->segment(2), FILTER_SANITIZE_NUMBER_INT) > (int)$steps) {   
                $this->db->where('u_id', $this->session->userdata('loged_id'));
                $this->db->where('finish', 0);
                $this->db->order_by('id', 'DESC');
                $this->db->limit(1);
                $this->db->set('steps', (int)$step);
                $this->db->set($color, $color.'+'.$points, FALSE);
                $this->db->update('tests');
            }
        }else{
            $this->db->where('u_id', $this->session->userdata('loged_id'));
            $this->db->where('finish', 0);
            $this->db->order_by('id', 'DESC');
            $this->db->limit(1);
            $this->db->set('steps', (int)$step);
            $this->db->set($color, $color.'+'.$points, FALSE);
            $this->db->update('tests');
        }
        
    }


    public function is_payment(){
        $this->db->where('u_id', $this->session->userdata('loged_id'));
        $this->db->where('finish', 0);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $payment = $this->db->get('tests')->row('payment');

        if($payment == 0){
            redirect('home/pay');
        }else{
            return true;
        }
        
    }

    public function is_payment_to_save(){
        $this->db->where('u_id', $this->session->userdata('loged_id'));
        $this->db->where('finish', 0);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $payment = $this->db->get('tests')->row('payment');

        if($payment == 0){
            return false;
        }elseif($payment == 1){
            return true;
        }
        
    }

    public function finnish_test(){

        $type1 = null;
        $type2 = null;
        $type3 = null;
        $type4 = null;

        $this->db->where('u_id', (int)$this->session->userdata('loged_id'));
        $this->db->where('finish', 0);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $test = $this->db->get('tests')->row();


        if((int)$test->light_blue > (int)$test->blue){
            $type1 = 'E'; 
        }else{
            $type1 = 'I'; 
        }

        if((int)$test->yellow > (int)$test->orange){
            $type2 = 'S'; 
        }else{
            $type2 = 'N'; 
        }

        if((int)$test->green > (int)$test->brown){
            $type3 = 'T'; 
        }else{
            $type3 = 'F'; 
        }

        if((int)$test->red > (int)$test->pink){
            $type4 = 'J'; 
        }else{
            $type4 = 'P'; 
        }

        $type = $type1.$type2.$type3.$type4;
        
        $this->db->where('id', $test->id);
        $this->db->set('charact', $type);
        $this->db->set('left_sum', ( (int)$test->light_blue + (int)$test->yellow + (int)$test->green + (int)$test->red ) );
        $this->db->set('right_sum', ( (int)$test->blue + (int)$test->orange + (int)$test->brown + (int)$test->pink ) );
        $this->db->set('finish', 1);
        $this->db->set('date', time());
        $this->db->update('tests');


        /////////////////


        $data['types'] = $this->db->where_in('letter', [$type1, $type2, $type3, $type4])->get('letter_type')->result();
        $data['char'] = $this->db->get_where('type', ['charact' => $type])->row();
        $data['test'] = $this->db->order_by('id', 'DESC')->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id')])->row();
        $data['left'] = ((int)$test->light_blue + (int)$test->yellow + (int)$test->green + (int)$test->red);
        $data['right'] = ((int)$test->blue + (int)$test->orange + (int)$test->brown + (int)$test->pink);

		$user = $this->db->get_where('users', ['id' => $this->session->userdata('loged_id')])->row();

                $addresmail=$user->email;
                $this->load->library('email');
                //$this->email->from('testforSKEPSI@agan.gr', 'TestForSkepsi');
                $this->email->from($this->config->item('sender_email'), $this->config->item('sender_name'));
                $this->email->to($addresmail);
                $this->email->set_header("MIME-Version","1.0"."\r\n");
                $this->email->set_header("Content-type","text/html;charset=UTF-8" . "\r\n");
                $this->email->cc('');
                $this->email->bcc('');
                $this->email->subject($this->users->echo_lang_text('Result from Skepsis Graph','Αποτέλεσμα σκεψηγραφήματος'));
                $this->email->message($this->load->view('email/result', $data, true));
                $this->email->send();
    }

    public function pass_change($new = null){
        $this->db->where('id', (int)$this->session->userdata('loged_id'));
        $this->db->set('password', md5($new));
        if($this->db->update($this->table)){
            return true;
        }else{
            return false;
        }
    }

    public function get_email(){
        return $this->db->get_where($this->table, ['id' => (int)$this->session->userdata('loged_id')])->row('email');
    }


    public function change_email($email = null){
        $this->db->where('id', (int)$this->session->userdata('loged_id'));
        $this->db->set('email', $email);
        if($this->db->update($this->table)){
            return true;
        }else{
            return false;
        }
    }

    public function get_tests(){
        //$tests = $this->db->order_by('id', 'DESC')->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'payment' => 1, 'finish' => 1]);
        
        $tests = $this->db->order_by('id', 'DESC')->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'payment' => 1]);

        if ($tests->num_rows() > 0) {
            return $tests->result();
        }else{
            return false;
        }
    }

    public function get_test($id = null){
        $this->db->join('users', 'tests.u_id=users.id', 'left');
        $this->db->join('type', 'tests.charact=type.charact', 'left');
        return $this->db->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'payment' => 1, 'finish' => 1, 'tests.id' => $id])->row();

    }

    public function get_by_letter($id = null){

        $char = $this->db->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'payment' => 1, 'finish' => 1, 'tests.id' => $id])->row('charact');

        $char = str_split($char);

        $this->db->where_in('letter', [$char[0], $char[1], $char[2], $char[3]]);      
        return $this->db->get('letter_type')->result();

    }

	public function echo_lang_text($entext,$grtext){
			if($this->session->userdata('mylang') ==='english') return $entext;
			if($this->session->userdata('mylang') ==='greek') return $grtext;
	}	
	
	public function echo_valid_errors($val_errors){
		//echo $val_errors;
		$retval='';
		if($val_errors !== ''){
			$tmpval=$val_errors;
			
			while (strpos($tmpval, '<all>')>0){
				$mm = substr($tmpval, strpos($tmpval, '<all>')+5);
				$m = substr($mm, 0, strpos($mm, '</all>'));
				$retval=$retval.$m.' ';
				$mm = substr($tmpval, strpos($tmpval, '</all>')+6);
				$tmpval=$mm;
				
				if($this->session->userdata('mylang') ==='english'){
					$mm = substr($tmpval, strpos($tmpval, '<en>')+4);
					$m = substr($mm, 0, strpos($mm, '</en>'));
					$retval=$retval.$m.'<br>';
					$mm = substr($tmpval, strpos($tmpval, '</en>')+5);
					$tmpval=$mm;
				}
				if($this->session->userdata('mylang') ==='greek'){
					$mm = substr($tmpval, strpos($tmpval, '<gr>')+4);
					$m = substr($mm, 0, strpos($mm, '</gr>'));
					$retval=$retval.$m.'<br>';
					$tmpval=$mm;
				}
				
			}
			
		}
			return $retval;
	}
}
