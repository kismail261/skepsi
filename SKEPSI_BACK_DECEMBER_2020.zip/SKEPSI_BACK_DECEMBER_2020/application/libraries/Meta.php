<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Meta{

	
	public function __construct(){
		$this->CI =& get_instance();		
	}


	public function title(){

		//$title = '';

		// $url1 = $this->CI->uri->segment(1);
		// $url2 = $this->CI->uri->segment(2);
		// $url3 = $this->CI->uri->segment(3);
			
		// if($url1){
		// 	$title = 'Σκέψης Γράφημα ur | ' . $url1;
		// }

		return '<title>Σκέψης Γράφημα </title>'. PHP_EOL;
	}


}
