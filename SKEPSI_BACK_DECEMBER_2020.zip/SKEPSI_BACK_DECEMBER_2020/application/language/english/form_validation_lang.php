<?php
/**
 * System messages translation for CodeIgniter(tm)
 *
 * @author	CodeIgniter community
 * @author	Grigoris Charamidis
 * @copyright	Copyright (c) 2014 - 2016, British Columbia Institute of Technology (http://bcit.ca/)
 * @license	http://opensource.org/licenses/MIT	MIT License
 * @link	http://codeigniter.com
 */
defined('BASEPATH') OR exit('No direct script access allowed');
/*
$lang['required'] = "The %s field is required.";
$lang['required_post'] = "The %s field is required.";
$lang['required_get'] = "The %s field is required.";
$lang['required_put'] = "The %s field is required.";
$lang['required_delete'] = "The %s field is required.";
$lang['isset'] = "The %s field must have a value.";
$lang['valid_email'] = "The %s field must contain a valid email address.";
$lang['valid_emails'] = "The %s field must contain all valid email addresses.";
$lang['valid_url'] = "The %s field must contain a valid URL.";
$lang['valid_ip'] = "The %s field must contain a valid IP.";
$lang['min_length'] = "The %s field must be at least %s characters in length.";
$lang['max_length'] = "The %s field can not exceed %s characters in length.";
$lang['exact_length'] = "The %s field must be exactly %s characters in length.";
$lang['alpha'] = "The %s field may only contain alphabetical characters.";
$lang['alpha_numeric'] = "The %s field may only contain alpha-numeric characters.";
$lang['alpha_dash'] = "The %s field may only contain alpha-numeric characters, underscores, and dashes.";
$lang['numeric'] = "The %s field must contain only numbers.";
$lang['is_numeric'] = "The %s field must contain only numeric characters.";
$lang['integer'] = "The %s field must contain an integer.";
$lang['regex_match'] = "The %s field is not in the correct format.";
$lang['matches'] = "The %s field does not match the %s field.";
$lang['is_unique'] = "The %s field must contain a unique value.";
$lang['is_natural'] = "The %s field must contain only positive numbers.";
$lang['is_natural_no_zero'] = "The %s field must contain a number greater than zero.";
$lang['decimal'] = "The %s field must contain a decimal number.";
$lang['less_than'] = "The %s field must contain a number less than %s.";
*/
/*
$lang['form_validation_required']		= 'The "{field}" is required.';
$lang['form_validation_isset']			= 'The "{field}" must contain a value.';
$lang['form_validation_valid_email']		= 'The "{field}" must contain a valid email.';
$lang['form_validation_valid_emails']		= 'The "{field}" must contain valid email address';
$lang['form_validation_valid_url']		= 'The "{field}" must contain valid URL.';
$lang['form_validation_valid_ip']		= 'The "{field}" must contain valid IP.';
$lang['form_validation_min_length']		= 'The "{field}" πεδίο πρέπει να περιέχει τουλάχιστον {param} χαρακτήρες.';
$lang['form_validation_max_length']		= 'The "{field}" πεδίο δεν μπορεί να υπερβαίνει τους {param} χαρακτήρες.';
$lang['form_validation_exact_length']		= 'The "{field}" πεδίο πρέπει να είναι ακριβώς {param} χαρακτήρες.';
$lang['form_validation_alpha']			= 'The "{field}" πεδίο μπορεί να περιέχει μόνο αλφαβητικούς χαρακτήρες.';
$lang['form_validation_alpha_numeric']		= 'The "{field}" πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες.';
$lang['form_validation_alpha_numeric_spaces']	= 'The "{field}" πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες και κενά.';
$lang['form_validation_alpha_dash']		= 'The "{field}" πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες, κάτω παύλες και παύλες.';
$lang['form_validation_numeric']		= 'The "{field}" πεδίο πρέπει να περιέχει μόνο αριθμούς.';
$lang['form_validation_is_numeric']		= 'The "{field}" πεδίο πρέπει να περιέχει μόνο αριθμητικούς χαρακτήρες.';
$lang['form_validation_integer']		= 'The {field πρέπει να περιέχει έναν ακέραιο αριθμό.';
$lang['form_validation_regex_match']		= 'The "{field}" πεδίο δεν είναι στη σωστή μορφή.';
$lang['form_validation_matches']		= 'The "{field}" πεδίο δεν ταιριάζει με το {param} πεδίο.';
$lang['form_validation_differs']		= 'The "{field}" πεδίο πρέπει να διαφέρει από το {param} πεδίο.';
$lang['form_validation_is_unique'] 		= 'The email αυτό δεν μπορεί να χρησιμοποιηθεί, χρησιμοποιήστε διαφορετικό.';
$lang['form_validation_is_natural']		= 'The "{field}" πεδίο πρέπει να περιέχει μόνο ψηφία.';
$lang['form_validation_is_natural_no_zero']	= 'The "{field}" πεδίο πρέπει να περιέχει μόνο ψηφία και πρέπει να είναι μεγαλύτερο από το μηδέν.';
$lang['form_validation_decimal']		= 'The "{field}" πεδίο πρέπει να περιλαμβάνει ένα δεκαδικό αριθμό.';
$lang['form_validation_less_than']		= 'The "{field}" πεδίο πρέπει να περιέχει έναν αριθμό μικρότερο από {param}.';
$lang['form_validation_less_than_equal_to']	= 'The "{field}" πεδίο πρέπει να περιέχει έναν αριθμό μικρότερο ή ίσο με {param}.';
$lang['form_validation_greater_than']		= 'The "{field}" πεδίο πρέπει να περιέχει έναν αριθμό μεγαλύτερο από το {param}.';
$lang['form_validation_greater_than_equal_to']	= 'The "{field}" πεδίο πρέπει να περιέχει ένα αριθμό μεγαλύτερο ή ίσο με {param}.';
$lang['form_validation_error_message_not_set']	= 'Δεν είναι δυνατή η πρόσβαση σε ένα μήνυμα σφάλματος που αντιστοιχεί στο πεδίο "{field}".';
$lang['form_validation_in_list']		= 'The "{field}" πεδίο πρέπει να περιέχει ένα απο: {param}.';
*/