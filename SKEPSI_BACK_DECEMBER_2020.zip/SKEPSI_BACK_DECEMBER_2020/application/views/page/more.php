<div class="row pages">

<div class="col-md-8 col-md-offset-2 pages_content">
	<h3><?php echo $this->users->echo_lang_text("What is SkepsisGraph","Τι είναι το Skepsis Graph");?></h3>
	<p>
	<?php echo $this->users->echo_lang_text("Skepsis Graph is a pioneering science-based Vocational Guidance system that explores one's personality, skills, inclinations, abilities and interests and identifies the professions that suit each individual as well as their respective fields of study, exploring how making decisions through the domains of his brain.<br><br>
	It is well known that the way a decision is made depends on a series of processes that take place in the brain, which are directly related to the recordings in it, the experience and the way the person perceives things and their environment.<br><br>
So the point in this case is to find out how one perceives reality and situations, that is, the domains of one's brain.<br><br>
For the first time, in April 1997, the first questionnaires were answered manually by students of Professor Christos Mouratidis, the results of which were studied and compared with the course of these people in their lives.<br><br>
During these years more than 4,000 questionnaires were completed and evaluated, with the primary aim of the individual-person-student pedagogical approach, the way in which mathematics, science, visual, literary and other subjects are perceived, and their attitudes toward and in general application of knowledge.<br><br>
As a result of this 20 years of research and monitoring the validity of the results, 2017 brings a new collaboration with the business consultant Mr. PeriklisPapageorgiou, so that the whole project will operate in electronic automated form, bringing knowledge and experience to everyone.<br><br>
Skepsis Graph consists of 50 questions and usually takes a few minutes. Questions do not require any level of knowledge as you can see in 'Try it'. The results of the test, utilized, support and make career guidance more effective, where possible:<br><br>

•	Make the right decisions about integrating the individual into the scientific fields, choosing directions and vocational education and training in new fields.<br>
•	Check whether the practitioner or candidate is fit for the individual's actual abilities, skills, inclinations and personality.<br>
•	Identify more individual inclinations and alternative career opportunities.<br>
•	Determine whether the individual is able to meet the requirements arising from a particular work environment.<br>
•	Identify the slopes, talents, abilities and skills but also the personality traits of the individual and the level at which the individual holds them.
","Το <strong>Skepsis Graph</strong> είναι ένα πρότυπο πρωτοποριακό επιστημονικό σύστημα Επαγγελματικού Προσανατολισμού, που διερευνά την προσωπικότητα, τις δεξιότητες, τις κλίσεις, τις ικανότητες αλλά και τα ενδιαφέροντα του ατόμου και προσδιορίζει τα επαγγέλματα εκείνα που ταιριάζουν στον καθένα καθώς και τα αντίστοιχα πεδία σπουδών, ερευνώντας  τον  τρόπο  λήψης αποφάσεών του μέσα από τις κυριαρχίες του εγκεφάλου του.</p><p> 
Είναι γνωστό πως ο τρόπος λήψης μιας απόφασης εξαρτάται από μια σειρά διεργασιών που συμβαίνουν στον εγκέφαλο, που έχουν άμεση σχέση με τις καταγραφές  που υπάρχουν σ΄ αυτόν, την εμπειρία και τον τρόπο που αντιλαμβάνεται το άτομο τα πράγματα και το περιβάλλον του.</p><p>
Έτσι το ζητούμενο στην  προκειμένη περίπτωση είναι, να ανακαλύψει το άτομο τον τρόπο με τον  οποίο αντιλαμβάνεται την πραγματικότητα και τις καταστάσεις, δηλαδή τις κυριαρχίες του εγκεφάλου του.</p><p> 
Για πρώτη φορά, τον Απρίλιο του 1997 απαντήθηκαν τα πρώτα ερωτηματολόγια χειρόγραφα τότε, από μαθητές του καθηγητή κ. Χρήστου Μουρατίδη, τα αποτελέσματα των οποίων μελετήθηκαν και συγκρίθηκαν  με  την πορεία  των ατόμων αυτών στη ζωή τους.</p><p>
Στη διάρκεια των ετών αυτών περισσότερα από 4.000 ερωτηματολόγια συμπληρώθηκαν και αξιολογήθηκαν, με πρωταρχικό στόχο την παιδαγωγική προσέγγιση του ατόμου-προσώπου-μαθητή, τον  τρόπο αντίληψής των μαθηματικών, φυσικών επιστημών, εικαστικών, φιλολογικών και άλλων μαθημάτων και γενικότερα τη στάση του απέναντι στη πρόσληψη και εφαρμογή της γνώσης. </p><p>
Σαν αποτέλεσμα αυτής της 20ετούς έρευνας και η παρακολούθηση της εγκυρότητας των αποτελεσμάτων, φέρνει από το 2017 μια νέα συνεργασία με τον επιχειρησιακό σύμβουλο κ. Περικλή Παπαγεωργίου, ώστε το όλο εγχείρημα να λειτουργεί σε ηλεκτρονική αυτοματοποιημένη μορφή ενώνοντας γνώσεις και πείρα κάνοντάς το προσβάσιμο σε όλους.</p><p>
Το Skepsis Graph αποτελείται από 50 ερωτήσεις και η διάρκεια του συνήθως διαρκεί μερικά λεπτά. Οι ερωτήσεις δεν απαιτούν κανένα γνωστικό επίπεδο όπως μπορείτε να δείτε και στο «Δοκίμασέ το».</p><p>
Τα αποτελέσματα του τεστ, αξιοποιούμενα, στηρίζουν και καθιστούν αποτελεσματικότερο τον επαγγελματικό προσανατολισμό, εφόσον μέσω αυτών είναι δυνατόν: <br><br>
•	Να ληφθούν οι σωστές αποφάσεις όσον αφορά την ένταξη του ατόμου σε επιστημονικά πεδία, στην επιλογή κατευθύνσεων και επαγγελματικής εκπαίδευσης και κατάρτισης σε νέους τομείς.<br>
•	Να ελεγχθεί αν το ασκούμενο ή υποψήφιο επάγγελμα ή ειδικότητα ταιριάζει στις πραγματικές ικανότητες, δεξιότητες, κλίσεις και προσωπικότητα του ατόμου.<br>
•	Να εντοπιστούν περισσότερες κλίσεις του ατόμου και εναλλακτικές επαγγελματικές δυνατότητες.<br>
•	Να διαπιστωθεί εάν το άτομο είναι σε θέση να ανταποκριθεί στις απαιτήσεις που προκύπτουν από συγκεκριμένο εργασιακό περιβάλλον.<br>
•	Να διαπιστωθούν οι κλίσεις, τα ταλέντα, οι ικανότητες και δεξιότητες αλλά και τα χαρακτηριστικά της προσωπικότητας που διαθέτει όπως και το επίπεδο στο οποίο το άτομο τα κατέχει.</p>");?>


</div>
	
</div>