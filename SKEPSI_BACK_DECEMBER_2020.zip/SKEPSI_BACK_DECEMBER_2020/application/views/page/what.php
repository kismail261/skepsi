<div class="row pages">

<div class="col-md-8 col-md-offset-2 pages_content">
	<h3><?php echo $this->users->echo_lang_text("Skepsis Graph is based on scientific data.","Το Skepsis Graph βασίζεται σε επιστημονικά δεδομένα.");?></h3>
<p><?php echo $this->users->echo_lang_text("
A)	It is based on the weighted abbreviated Myers - Briggs index type, which analyzes 4 basic personality types such as: Inbound or Outbound with Perception or Insight. The combination of these basic types gives 16 different types of personality while at the same time giving us brain dominance in how to make decisions through left or right dominance. All this, always the moment we answer the questionnaire honestly, thinking about how we work and what we usually do - in the appropriate cases - questions - and not what we would like to do, or what we like to do.<br><br>
B)	Applies the established theory to the career orientation of F. Kuder and John Holland which analyzes the professional personality of the individual in six types: Practical, Research, Artistic, Social, Business, Conventional. Skepsis Graph deepens, however, by analyzing each of the six professional types in 14 subcategories. Only Skepsis Graph in addition to the six professional types accurately maps professional personality giving a total of 84 truth-telling personality data. Finally, Skepsis Graph explores one's overall self-esteem as well as one's self-esteem in a family, friendly, school, and work environment. As Abraham Maslow 1943 -707 points out about the work incentives assessed by this questionnaire, you can:<br><br>

(a) choose the work environment that suits you best;<br>
(b) move to the most appropriate specialty;<br>
(c) choose the optimal combination from alternative work environments;<br>
(d) Offer profitable work for the benefit of all.","Α)  Σαν βάση του έχει τον σταθμισμένο συντετμημένο τύπο δείκτη Myers - Briggs, με τον οποίο αναλύονται 4 βασικοί τύποι προσωπικότητας όπως :  Εσωστρεφείς ή Εξωστρεφείς με Αντίληψη ή Διορατικότητα. Ο
Ο συνδυασμός αυτών των βασικών τύπων δίνει 16 διαφορετικούς τύπους προσωπικότητας  ενώ συγχρόνως μας δίνει και την κυριαρχία του εγκεφάλου ως προς τον τρόπο λήψης αποφάσεων μέσα από την αριστερή ή δεξιά κυριαρχία.
Όλα αυτά, πάντα για τη στιγμή που απαντάμε με ειλικρίνεια το ερωτηματολόγιο, σκεπτόμενοι πώς λειτουργούμε και τί συνήθως κάνουμε –στις αντίστοιχες περιπτώσεις – ερωτήσεις - και όχι τι θα θέλαμε να κάνουμε, ή τι μας αρέσει να κάνουμε. <br><br>
Β)  Εφαρμόζει την καθιερωμένη θεωρία στον επαγγελματικό προσανατολισμό των F. Kuder και John Holland η οποία αναλύει την επαγγελματική προσωπικότητα του ατόμου σε έξι τύπους: Πρακτικός, Ερευνητικός, Καλλιτεχνικός, Κοινωνικός, Επιχειρηματικός, Συμβατικός.
Το Skepsis Graph  εμβαθύνει όμως αναλύοντας κάθε έναν από τους έξι επαγγελματικούς τύπους σε 14 υποκατηγορίες. Μόνο το Skepsis Graph επιπλέον  των έξι επαγγελματικών τύπων χαρτογραφεί με ακρίβεια την επαγγελματική προσωπικότητα δίνοντας συνολικά 84 δεδομένα στοιχεία προσωπικότητας με δείκτη αλήθειας. Τέλος το Skepsis Graph  διερευνά τη γενική αυτοαντίληψη του ατόμου καθώς και την αυτοεκτίμησή του στο οικογενειακό, φιλικό, σχολικό και εργασιακό πλαίσιο.
Όπως αναφέρει και ο Abraham Maslow 1943 -1970 για τα εργασιακά κίνητρα που αξιολογεί το παρόν ερωτηματολόγιο, μπορείτε: <br><br>
α) να επιλέξετε το εργασιακό περιβάλλον που σας ταιριάζει, <br>
β) να κινηθείτε προς την πλέον ενδεδειγμένη ειδικότητα, <br>
γ) να επιλέξετε το βέλτιστο συνδυασμό από εναλλακτικά εργασιακά περιβάλλοντα, <br>
δ) να προσφέρετε αποδοτικό έργο προς όφελος όλων.");?></p>
</div>
	
</div>



