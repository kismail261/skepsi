<div class="row pages">

<div class="col-md-8 col-md-offset-2 pages_content">
	<h3><?php echo $this->users->echo_lang_text("What does it mean to be characterized as left or right dominion.","Τι σημαίνει ότι το άτομο χαρακτηρίζεται ως αριστερής ή δεξιάς κυριαρχίας.");?></h3>
<p><?php echo $this->users->echo_lang_text("The left hemisphere specializes in linear (serial) processing of information. For example, the person with left-brain dominance will first notice the details in a painting and then the whole. He will look for logical mathematical answers, proofs, he will work step by step understanding the foregoing. Therefore, it is easier to learn in the classroom, where knowledge is usually transmitted 'down' (from detail to generality).<br><br>
The right hemisphere specializes in the composition of information, preferably the whole and less the individual components. For example, the person with right-brain dominance will first analyze the image as a whole and then look at the details. This means that the person learns much more easily when he has been informed in advance of the subject matter or has read a summary, and is therefore prepared to have the required learning framework in place.","Το αριστερό ημισφαίριο ειδικεύεται στη γραμμική (σειριακή) επεξεργασία των πληροφοριών. Για παράδειγμα, το άτομο με αριστερή κυριαρχία εγκεφάλου, θα προσέξει πρώτα τις λεπτομέρειες σε μια ζωγραφιά και στη συνέχεια το σύνολό της. Θα αναζητήσει λογικές μαθηματικές απαντήσεις, αποδείξεις, θα δουλέψει βήμα-βήμα κατανοώντας τα προηγούμενα. Επομένως, μαθαίνει πιο εύκολα στην αίθουσα διδασκαλίας, όπου συνήθως η μετάδοση της γνώσης γίνεται 'κάτωθεν' (από τη λεπτομέρεια στη γενικότητα).<br><br>
Το δεξιό ημισφαίριο ειδικεύεται στη σύνθεση των πληροφοριών, προτιμά , το σύνολο και λιγότερο τα επιμέρους συνθετικά στοιχεία. Για παράδειγμα, το άτομο με δεξιά κυριαρχία εγκεφάλου, θα αναλύσει πρώτα την εικόνα στο σύνολό της και στη συνέχεια θα προσέξει τις λεπτομέρειες. Το γεγονός αυτό σημαίνει ότι το άτομο μαθαίνει πολύ πιο εύκολα όταν έχει ενημερωθεί εκ των προτέρων για το θέμα του μαθήματος ή έχει διαβάσει μια περίληψη, και, επομένως, είναι προετοιμασμένο έχοντας σχηματίσει το απαιτούμενο μαθησιακό πλαίσιο.");?></p><p>
</div>
	
</div>


