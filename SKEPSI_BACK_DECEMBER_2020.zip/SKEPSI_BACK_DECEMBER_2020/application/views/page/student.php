<div class="row pages">

<div class="col-md-8 col-md-offset-2 pages_content">
	<h3><?php echo $this->users->echo_lang_text("For students","Για μαθητές");?></h3>
	<p>
<?php echo $this->users->echo_lang_text("Skepsis Graph advises prospective students looking for the school that really suits them, as well as graduates seeking a master's degree. The results of the test show what it is that fits the personality of the person objectively and not with the influence of environmental desires and external subjective factors, which often lead to wrong decisions.","Το <strong>Skepsis Graph</strong> συμβουλεύει τους υποψήφιους φοιτητές  που αναζητούν  τη σχολή που τους ταιριάζει πραγματικά, αλλά και τους πτυχιούχους που επιζητούν εξειδίκευση σε μεταπτυχιακό επίπεδο. 
Τα αποτελέσματα του τεστ δείχνουν τι είναι αυτό που ταιριάζει αντικειμενικά στην προσωπικότητα του ατόμου και όχι με επιρροή επιθυμιών του περιβάλλοντος και εξωτερικών υποκειμενικών παραγόντων, που τις περισσότερες φορές οδηγούν σε λάθος αποφάσεις.");?> </p>
</div>
	
</div>



