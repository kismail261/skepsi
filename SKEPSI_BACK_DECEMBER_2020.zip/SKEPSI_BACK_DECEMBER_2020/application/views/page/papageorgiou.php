<div class="row pages">

<div class="col-md-8 col-md-offset-2 pages_content">
	<?php echo $this->users->echo_lang_text("<h3>Curriculum vitae (CV)of Pericles Papageorgiou</h3>  (adapted for this project)","<h3>Βιογραφικό Περικλή Παπαγεωργίου</h3> (προσαρμοσμένο για το παρόν έργο)");?>
	<p>
<?php echo $this->users->echo_lang_text('Pericles Papageorgiou, a 1992 graduate student at UCLA University M. Apostolakis (macro / micro economics) and an associate of LSE Professor E. Kevorg (Bussines strategy) did business research using the new tool as a key tool technologies for the proper staffing of business departments, as well as the business strategy that companies need to follow depending on their executives and resources.<br>
In 1995 he graduated from Hertfordshire University with an MA in B.A, taking the 1st place among 950 students. Since 2005 she holds a PhD in "Internet Economy". He has received many honors, including his nomination to the Academy of Athens in 2014 and a 2016 documentary portrait from the state-owned French channel TVFrance on his cultural entrepreneurship as a founder and president of Deos Ancient Culture.<br>
Since 1998 he has been working as a business consultant specializing in e-economy, having worked with many large companies in Greece and abroad (Microsoft, Google, Apple, bwin etc.) as well as the Greek government (Ministry of Finance, Ministry of Health, GS Information Systems, etc.) He is a founder of NetHouse internet consulting since 1998, a founder of Deos Ancient Culture since 2013 and a President of the AAMK (AgioiAnargyri Municipality of Kamater) Cultural and Educational Organization since 2014.<br>
Since 2015, in collaboration with Professor Chr. Mouratidis, they have been implementing the Ur Project "Skepsis Graph" combining knowledge and experience with the aim of giving prospective students and professionals the most reliable tool in their academic and professional careers.
The test tool helps stakeholders with objective information so that through their personality and their talents they make the right decision to do what truly suits them, with maximum performance and personal happiness academically and professionally.<br>
"When studies and work are identical in character then they become a very good lucrative hobby of a happy person"','Ο Περικλής Παπαγεωργίου από φοιτητής το 1992 ως βοηθός του καθηγητή του UCLA University M. Αποστολάκη (macro / micro economics)  αλλά και συνεργάτης του Καθηγητή του LSE E. Kevorg (Bussines strategy) ασχολήθηκε ερευνητικά με την οργάνωση του επιχειρείν χρησιμοποιώντας ως βασικό εργαλείο τις νέες τεχνολογίες για την σωστή στελέχωση των τμημάτων των επιχειρήσεων, αλλά και την επιχειρηματική στρατηγική που πρέπει να ακολουθούν οι εταιρείες αναλόγως των στελεχών και των πόρων που διαθέτουν. <br>
Το 1995 αποφοίτησε από το Hertfordshire University με ειδικότητα Μ.Α in B.A καταλαμβάνοντας την 1η θέση βαθμολογίας μεταξύ 950 φοιτητών. Από το 2005 είναι κάτοχος PhD με θέμα την «οικονομία του διαδικτύου». <br>
Έχει λάβει πολλές τιμητικές διακρίσεις μεταξύ άλλων την υποψηφιότητα του στην Ακαδημία Αθηνών το 2014 αλλά και την προσωπογραφία ντοκιμαντέρ το 2016 από το κρατικό γαλλικό κανάλι το TVFrance με θέμα την πολιτιστική επιχειρηματική του δράση ως ιδρυτή και πρόεδρο της Deos Ancient Culture. <br>
Από το 1998 εργάζεται ως σύμβουλος επιχειρήσεων με ειδικότητα την ηλεκτρονική οικονομία έχοντας συνεργαστεί με πολλές μεγάλες επιχειρήσεις της Ελλάδας και του εξωτερικού (Microsoft, Google, Apple, bwin κ.α.) όπως και το ελληνικό δημόσιο (Υπ. Οικονομικών, Υπ. Υγείας,  Γ.Γ Πληροφοριακών συστημάτων κ.α.)<br>
Είναι ιδρυτής της εταιρείας NetHouse internet consulting από 1998, ιδρυτής της εταιρείας Deos Ancient Culture από το 2013 και Πρόεδρος του Οργανισμού Πολιτισμού Αθλητισμού και Παιδείας του ΔΑΑΚ από το 2014. <br>
Από το 2015 σε συνεργασία με τον καθηγητή Χ. Μουρατίδη υλοποιούν το Ur Project «Skepsis Graph» ενώνοντας γνώσεις και εμπειρία με σκοπό υποψήφιοι φοιτητές αλλά και επαγγελματίες να χρησιμοποιήσουν το πιο αξιόπιστο εργαλείο στην ακαδημαϊκή αλλά και επαγγελματική τους καριέρα. <br>
Το εργαλείο – τεστ βοηθάει τους ενδιαφερόμενους με αντικειμενικά στοιχεία ώστε μέσω της προσωπικότητάς τους και των ταλέντων τους να λάβουν την σωστή απόφαση ώστε να κάνουν αυτό που τους ταιριάζει πραγματικά, έχοντας την μέγιστη απόδοση αλλά και προσωπική ευτυχία ακαδημαϊκά και επαγγελματικά.<br>
«Όταν οι σπουδές και η δουλειά είναι ταυτόσημα του χαρακτήρα τότε γίνονται ένα πολύ καλό προσοδοφόρο χόμπι ενός ευτυχισμένου ανθρώπου»');?></p>

<br><br><br>
<span class="glyphicon glyphicon-earphone" aria-hidden="true"></span> 6985125140<br>
<span class="glyphicon glyphicon-envelope" aria-hidden="true"></span> perispap@icloud.com<br>
<a class="bio_link" href="https://www.facebook.com/periklis.papageorgiou.2014/" target="_blank">Facebook</a><br>
<a class="bio_link" href="https://twitter.com/perispap" target="_blank">Twitter</a><br>
<a class="bio_link" href="https://www.instagram.com/perispap/" target="_blank">Instagram</a> 
</div>
	
</div>




