<div class="row pages">
<div class="col-md-8 col-md-offset-2 pages_content">
	<h3><?php echo $this->users->echo_lang_text("You can pay by using one of the following methods :","Μπορείτε να πληρώσετε με έναν από τους παρακάτω τρόπους :");?></h3>
<p><?php echo $this->users->echo_lang_text("<b>Viva Payment using Visa – MasterCard – Prepay or Viva Wallet</b> <br><br>
By selecting this form of payment, you will be transferred to a secure trading environment of Viva Payment.<br>
We confirm that our company does not receive any information regarding your credit card.For more information’s about Viva Payments please visit:
<a href='https://www.vivawallet.com/el-gr/terms-conditions/'>https://www.vivawallet.com/el-gr/terms-conditions/</a><br><br>
<b>PayPal Payment</b> <br><br>
With secure PayPal online payment service. We confirm that our company does not receive any information regarding your credit card. For more information’s aboutPayPal please visit:  <a href='http://www.paypal.com'>http://www.paypal.com</a><br><br>
By choosing <b>«Payment»</b>, I certify that I have read, understood and accepted the  <a href='".site_url('page/terms')."' target='_blank'>Terms of Use and Privacy Policy.</a>
","<b>Πληρωμή μέσω Viva Payments με Visa – MasterCard – Prepay or Viva Wallet</b><br><br>Μπορείτε να πληρώσετε με χρήση της πιστωτική σας κάρτας μέσω πλατφόρμας της VivaPayments που εγγυάται 100% ασφάλεια συναλλαγών.<br>
Το σύστημα μας δεν αποθηκεύει ούτε εμπλέκεται με τα στοιχεία της κάρτας σας. Για περισσότερες πληροφορίες σχετικά με την VivaPayments επισκεφτείτε την διεύθυνση: <a href='https://www.vivawallet.com/el-gr/terms-conditions/'>https://www.vivawallet.com/el-gr/terms-conditions/</a><br><br>
<b>Πληρωμή με PayPal</b><br><br>Μπορείτε να πληρώσετε τις παραγγελίες μέσω της διαδικτυακής υπηρεσίας πληρωμών PayPal. Για περισσότερες πληροφορίες σχετικά με τηνPayPalεπισκεφτείτε την διεύθυνση: <a href='http://www.paypal.com'>http://www.paypal.com</a><br><br>
Επιλέγοντας <b>«Πληρωμή»</b>, βεβαιώνω ότι έχω διαβάσει, κατανοήσει και αποδεχθεί τους <a href='".site_url('page/terms')."' target='_blank'>Όρους χρήσης και την Πολιτική Απορρήτου.</a>

");?></p><p>
</div>
	
</div>


