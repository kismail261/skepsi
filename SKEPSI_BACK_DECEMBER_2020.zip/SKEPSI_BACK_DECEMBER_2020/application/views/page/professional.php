<div class="row pages">

<div class="col-md-8 col-md-offset-2 pages_content">
	<h3><?php echo $this->users->echo_lang_text("For professionals","Για επαγγελματίες");?></h3>
	<p><?php echo $this->users->echo_lang_text("Skepsis Graph advises professionals and employees who want to get to know their true skills, their slopes and alternative occupations that suit them. It is also a very useful tool for a company to get to know the strengths of its executives by putting them in the right place to fit their personality, thus having happy and efficient employees.","Το <strong>Skepsis Graph</strong> συμβουλεύει τους επαγγελματίες και τους εργαζόμενους που επιθυμούν να γνωρίσουν τις πραγματικές τους ικανότητες, τις κλίσεις τους αλλά και εναλλακτικά επαγγέλματα που τους ταιριάζουν. Επίσης είναι πολύ χρήσιμο εργαλείο ώστε μια εταιρεία να γνωρίσει τα δυνατά σημεία των στελεχών της τοποθετώντας τα στην σωστή θέση που να ταιριάζει στην προσωπικότητα  τους, έχοντας έτσι ευχαριστημένους και αποδοτικούς εργαζόμενους.");?></p>
</div>
	
</div>



