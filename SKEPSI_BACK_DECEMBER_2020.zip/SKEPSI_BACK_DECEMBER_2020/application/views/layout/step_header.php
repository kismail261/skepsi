<?php
if($this->session->userdata('mylang')) {
      // Do your code here
} else {
	$this->session->set_userdata('mylang', $this->config->item('language'));
}
$this->session->set_userdata('curreturl',current_url());
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<?php echo $meta; ?>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link href='https://necolas.github.io/normalize.css/3.0.2/normalize.css' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic&subset=greek,latin' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<link href='<?php echo site_url('assets/css/style.css'); ?>' rel='stylesheet' type='text/css'>
	
	
<link rel="shortcut icon" href="<?php echo base_url(); ?>assets/img/favicon.ico" type="image/x-icon">	
<link rel="apple-touch-icon" sizes="57x57" href="<?php echo base_url(); ?>assets/img/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="<?php echo base_url(); ?>assets/img/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="<?php echo base_url(); ?>assets/img/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url(); ?>assets/img/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="<?php echo base_url(); ?>assets/img/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="<?php echo base_url(); ?>assets/img/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="<?php echo base_url(); ?>assets/img/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="<?php echo base_url(); ?>assets/img/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url(); ?>assets/img/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="<?php echo base_url(); ?>assets/img/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url(); ?>assets/img/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="<?php echo base_url(); ?>assets/img/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url(); ?>assets/img/favicon-16x16.png">
<link rel="manifest" href="<?php echo base_url(); ?>assets/img/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="<?php echo base_url(); ?>assets/img/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

	<script>
		var requesturl = "<?php echo site_url('user/ajax');?>";
	</script>
</head>
<body>
<div class="container-fluid">
<header class="row bgcolor1">
<div class="col-md-12">
<nav class="navbar navbar-default">
<div class="container">
<!-- Brand and toggle get grouped for better mobile display -->
<div class="navbar-header">
    <a class="navbar-brand" href="<?php echo site_url(); ?>"><img src="<?php echo base_url().'assets/img/skepsi_small.jpg'; ?>" width="170"></a>
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>

</div>

<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul class="nav navbar-nav">
<li><a href="<?php echo site_url(); ?>"><?php echo $this->users->echo_lang_text('<b>&#9664;</b> Back to Home','<b>&#9664;</b> Επιστροφή στην αρχική'); ?></a></li>
<?php if($this->session->has_userdata('login')): ?>
<li><a href="<?php echo site_url('user/account'); ?>"><?php echo $this->users->echo_lang_text('My Account','Ο Λογαριασμός μου'); ?></a></li>
<?php endif; ?>
<li><a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
	<img src="<?php echo base_url('assets/img/'.$this->users->echo_lang_text( 'english', 'greek').'.png'); ?>" width="26" height="26"/>
	<span class="caret"></span></a>
		<ul class="dropdown-menu">
			<li><a href="<?PHP echo site_url('user/setlangen');?>"><img src="<?php echo base_url('assets/img/english.png'); ?>" width="26" height="26"/>
			<span  class="dropdown-item<?php if($this->session->userdata('mylang') ==='english') echo ' active';?>"><span>english</span></a>
			</li>
			<li><a href="<?PHP echo site_url('user/setlanggr');?>"><img src="<?php echo base_url('assets/img/greek.png'); ?>" width="26" height="26"/>
			<span  class="dropdown-item<?php if($this->session->userdata('mylang') ==='greek') echo ' active';?>"><span>Ελληνικά</span></a>
			</li>
		</ul>
</li>
</ul>
<ul class="nav navbar-nav navbar-right call">
<?php if(!$this->session->has_userdata('login')): ?>
<li><a href="<?php echo site_url('user/login'); ?>"><?php echo $this->users->echo_lang_text('Register','Κάνε εγγραφή'); ?></a></li>
<?php else: ?>
<li><a href="<?php echo site_url('user/logout'); ?>"><?php echo $this->users->echo_lang_text('Logout','Αποσύνδεση'); ?></a></li>
<?php endif; ?>     
</ul>
</div><!-- /.navbar-collapse -->
</div><!-- /.container-fluid -->
</nav>
</div>
		

</header>