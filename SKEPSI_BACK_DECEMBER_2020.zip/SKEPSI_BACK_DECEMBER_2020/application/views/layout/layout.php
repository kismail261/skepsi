<?php
$this->load->view('layout/header');
$this->load->view($page);
$this->load->view('layout/footer');
?>