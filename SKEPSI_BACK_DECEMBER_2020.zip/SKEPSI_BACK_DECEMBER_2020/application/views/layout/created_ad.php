<div class="container-fluid">
<div class="row navbar-fixed-bottom">
<footer class="col-md-12 footer">
<p>Created by NetHouse © 2016 by Periklis Papageorgiou</p>
</footer>
</div><!-- row -->