<div class="row start_page">
	<div class="col-md-6 col-md-offset-3 start_content">
		<p><?php echo $this->users->echo_lang_text("Skepsis Graph does not require much knowledge to complete it and the average completion time does not exceed 20 minutes. Its simplicity is also a great success in its effectiveness.","Το Σκέψης Γράφημα δεν χρειάζεται καμία ιδιαίτερη γνώση για να το συμπληρώσετε και ο μέσος χρόνος ολοκλήρωσής του δεν ξεπερνά τα 20 λεπτά. Αυτή η απλότητα του ειναι και η μεγάλη του επιτυχία στην αποτελεσματικότητα του.");?></p>
		<a class="btn btn-lg btn-more" href="<?php echo site_url('home/step1'); ?>"><?php echo $this->users->echo_lang_text("Do the Test","Ξεκίνα το test");?>	&#9654;</a>
	</div>
</div>