<div class="row register_page white">
	<div class="col-md-8 col-md-offset-2 pay_page text-center">
		<h2><?php echo $this->users->echo_lang_text("Payment page","Σελίδα πληρωμής");?></h2>
		<p><?php echo $this->users->echo_lang_text("You can start Skepis Graph in the next step by paying only <strong>".$this->config->item('test_cost')."&euro;"."</strong> in a secure environment or by using your coupon code.","Μόνο με <strong>".$this->config->item('test_cost')."&euro;"."</strong> με πληρωμή σε ασφαλές περιβάλλον ή έχοντας ήδη κωδικό κουπονιού μπορείτε στο επόμενο βήμα να ξεκινήσετε το Σκέψης Γράφημα");?></p>
	</div>
	<div class="col-md-10 col-md-offset-2 text-center">
		<div class="col-md-2 text-center"> 
		</div>
		<div class="col-md-3 text-center"> 
			<a class="btn btn-lg btn-warning pay_button blue" href="<?php echo site_url('user/payment'); ?>"><?php echo $this->users->echo_lang_text("Payment ".$this->config->item('test_cost')."&euro;","Πληρωμή ".$this->config->item('test_cost')."&euro;");?></a><br>
		</div>
		<div class="col-md-3 text-center"> 
			<a class="btn btn-lg btn-warning pay_button blue" href="<?php echo site_url('user/add_groupon'); ?>"><?php echo $this->users->echo_lang_text("I have a coupon","Έχω κουπόνι");?></a>
		</div>
		<div class="col-md-2 text-center"> 
		</div>
	</div>
	<div class="col-md-10 col-md-offset-2 text-center">
		<div class="col-md-3 text-center"> 
		</div>
		<div class="col-md-4 text-center">
<!-- Paypal start of code -->

<form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post" >
<input type="hidden" name="cmd" value="_cart">
<input type="hidden" name="business" value="bourlokas@yahoo.com">
<input type="hidden" name="lc" value="GR">
<input type="hidden" name="item_name" value="Pay for Test Skepsi">
<input type="hidden" name="item_number" value="id-skepsi-en">
<input type="hidden" name="amount" value="15.00">
<input type="hidden" name="currency_code" value="EUR">
<input type="hidden" name="button_subtype" value="products">
<input type="hidden" name="no_note" value="0">
<input type="hidden" name="add" value="1">
<input type="hidden" name="bn" value="PP-ShopCartBF:pay15en.png:NonHostedGuest">
<input type="image" src="https://agan.gr/sk/assets/img/pay15<?php echo $this->users->echo_lang_text("en","gr"); ?>.png" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
<img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
</form>

	
<!-- Paypal end of code -->
		</div>
		<div class="col-md-3 text-center"> 
		</div>
	</div>
</div>