<div class="row register_page white">
	<div class="col-md-8 col-md-offset-2 need_login_page">
		<h2><?php echo $this->users->echo_lang_text("Connect to continue","Για να συνεχίσεις πρέπει να κάνεις σύνδεση.");?></h2>
		<p><?php echo $this->users->echo_lang_text("The style of all the questions is like the above. To continue the Skepis Graph please connect with your account or create one with two clicks only.","Όλες οι ερωτήσεις είναι σε αυτό το ύφος για να προχωρήσετε στο Σκέψης Γράφημα παρακαλούμε συνδεθείτε με τον κωδικό σας ή δημιουργήστε κωδικό με δύο μόνο clicks.");?></p>
		<a class="btn btn-lg btn-warning need_login_button blue" href="<?php echo site_url('user/login'); ?>"><?php echo $this->users->echo_lang_text("Connect","Σύνδεση");?></a>
	</div>
</div>