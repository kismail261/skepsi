<div class="row">
    
    VALID VIVA PAYMENT
</div>