<div class="row">
<div class="index_page_only">
<div class="home_page">
	<div class="col-md-6 col-md-offset-3 home_content">
		<h2 id="rotate"><?php
				echo $this->users->echo_lang_text('Skepsis grafima...just a few clicks of success!!!','Σκέψης Γράφημα και απέχεις λίγα clicks απο την επιτυχία !!');
			?></h2>
		<a class="btn btn-lg btn-more" href="<?php echo site_url('page/more'); ?>"><?php echo 
		$this->users->echo_lang_text(html_entity_decode('Learn more &#9654;&#9654;'),html_entity_decode('Μάθε περισσότερα &#9654;&#9654;'));
					?></a>

	<div class="col-md-12 home_options">
		<div class="row">
			<div class="col-md-6 col-sm-6 col-xs-6">
				<div class="home_option"></div>
				<div class="link_home_option"><a href="<?php echo site_url('home/start'); ?>"><i class="fa fa-compass fa-5x"></i><br><?php
				echo $this->users->echo_lang_text('Try it','Δοκίμασέ το');
			?></a></div>
			</div>

			<!-- <div class="col-md-4 col-sm-4 col-xs-4">
				<div class="home_option"><i class="fa fa-users fa-5x"></i></div>
				<div class="link_home_option"><a href="#">Εγγραφή</a></div>
			</div> -->

			<div class="col-md-6 col-sm-6 col-xs-6">
				<div class="home_option"></div>
				    <div class="link_home_option"><a href="<?php echo site_url('home/start_test_index'); ?>"><i class="fa fa-graduation-cap fa-5x"></i><br><?php
				echo $this->users->echo_lang_text('Do the Test','Κάνε το Τέστ');
			?></a></div>
			</div>
		</div>
	</div>
	</div>
</div><!-- home_page -->
</div><!-- index_page_only -->
</div><!-- row -->
</div><!--container-->
<?php $this->load->view('layout/created_ad'); ?>