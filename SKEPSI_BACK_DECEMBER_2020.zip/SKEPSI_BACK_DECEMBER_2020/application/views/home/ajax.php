<?php
	  
	  $data = array(
            'title' => $this->input->post('title'),
            'description' => $this->input->post('description')
        );
      //$this->db->insert('items', $data);
	  /*
	public function setlangen(){
		$this->session->set_userdata('mylang', 'english');
		$this->config->set_item('language', 'english');
		//$this->config->set_item('language', $headinfo['accountinfo']['language']);
		redirect($_SERVER["REQUEST_URI"]);
	}

	public function setlanggr(){
		$this->session->set_userdata('mylang', 'greek');
		$this->config->set_item('language', 'greek');
		//$this->config->set_item('language', $headinfo['accountinfo']['language']);
		redirect($_SERVER["REQUEST_URI"]);

	}
	*/
      echo 'Added successfully.'.$data['title']; 
		if($data['title']==='english') redirect('home/index');<?php
?>