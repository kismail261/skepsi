<?php
    
if (isset($_POST['radio'])){
    $paymeth = $_POST['radio'];
    switch($paymeth) { 
    case "VivaPayments": 
        header("Location: ".base_url().'user/payment'); 
        break; 
    case "PayPal": 
        if(!empty($products)): foreach($products as $product): 
            $paupalurl = $product['id'];
        endforeach; endif;
        header("Location: ".base_url().'products/buy/'.$paupalurl); 
        break; 
    case "Coupon": 
        header("Location: ".base_url().'user/add_groupon'); 
        break; 
    }
}
?>

<div class="row register_page white">
	<div class="col-md-8 col-md-offset-2 pay_page text-center">
		<h2><?php echo $this->users->echo_lang_text("Payment page","Σελίδα πληρωμής");?></h2>
		<p><?php echo $this->users->echo_lang_text("You can start Skepis Graph in the next step by paying only <strong>".$this->config->item('test_cost')."&euro;"."</strong> in a secure environment or by using your coupon code.","Μόνο με <strong>".$this->config->item('test_cost')."&euro;"."</strong> με πληρωμή σε ασφαλές περιβάλλον ή έχοντας ήδη κωδικό κουπονιού μπορείτε στο επόμενο βήμα να ξεκινήσετε το Σκέψης Γράφημα");?></p>
	</div>

	<div class="col-md-12 text-center">

<form method="post" action="?" id="form1">
    <div style="color:white">
        <p> 
        </p>
        <p>
         <input style="width: 1em; height: 1em;" type="radio" name="radio" value="VivaPayments" checked>
          <img src="<?php echo base_url().'/assets/img/logo_creditcards_01.svg';?>"  width="250">
        </p>     
        <p>
         <input style="width: 1em; height: 1em;" type="radio" name="radio" value="PayPal">
            <img src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/buy-logo-large.png" width="250" alt="Buy now with PayPal" />
        </p>     
        <p>
         <input style="width: 1em; height: 1em;" type="radio" name="radio" value="Coupon">
            <img src="<?php echo base_url().'/assets/img/couponi.png';?>"  width="250">
        </p>     
        <p style="padding: 15px 0;">
              <input style="width: 0.8em; height: 0.8em;padding:10px;cursor:pointer;" type="checkbox" id="oroixrisis" name="acceptrule" />
               <span style="font-size:0.6em"><?php echo $this->users->echo_lang_text("I have read and accept ","Έχω διαβάσει και συμφωνώ με τους");?></span> <a style="font-size:0.6em"href="<?php echo site_url('page/payways');?> " target='_blank'><?php echo $this->users->echo_lang_text("PAYMENT METHODS","ΤΡΟΠΟΙ ΠΛΗΡΩΜΗΣ");?></a>
        </p>
     </div> 
    <button id="paybutton" class="btn btn-lg btn-warning pay_button blue" style="width: 200px; height: 70px;  font-weight:700; font-size: 1.8em; margin-left:30px; " type="submit" form="form1" value="Submit" disabled='disabled'><?php echo $this->users->echo_lang_text("PAY","ΠΛΗΡΩΜΗ");?></button>

</form>
	</div>
</div>
<p>
    <br>
</p>