<?php
    
if (isset($_POST['radio'])){
    $paymeth = $_POST['radio'];
    switch($paymeth) { 
    case "VivaPayments": 
        header("Location: ".base_url().'user/payment2'); 
        break; 
    case "PayPal": 
        if(!empty($products)): foreach($products as $product): 
            $paupalurl = $product['id'];
        endforeach; endif;
        header("Location: ".base_url().'products/buy/'.$paupalurl); 
        break; 
    case "Coupon": 
        header("Location: ".base_url().'user/add_groupon'); 
        break; 
    }
}
?>

<div class="row register_page white">
	<div class="col-md-8 col-md-offset-2 pay_page text-center">
		<h2><?php echo $this->users->echo_lang_text("Payment page","Σελίδα πληρωμής");?></h2>
		<p><?php echo $this->users->echo_lang_text("You can start Skepis Graph in the next step by paying only <strong>".$this->config->item('test_cost')."&euro;"."</strong> in a secure environment or by using your coupon code.","Μόνο με <strong>".$this->config->item('test_cost')."&euro;"."</strong> με πληρωμή σε ασφαλές περιβάλλον ή έχοντας ήδη κωδικό κουπονιού μπορείτε στο επόμενο βήμα να ξεκινήσετε το Σκέψης Γράφημα");?></p>
	</div>
	<div class="col-md-10 col-md-offset-2 text-center">
		<div class="col-md-2 text-center"> 
		</div>
		<div class="col-md-3 text-center"> 
			<a class="btn btn-lg btn-warning pay_button blue" href="<?php echo site_url('user/payment'); ?>"><?php echo $this->users->echo_lang_text("VivaPayment ".$this->config->item('test_cost')."&euro;","Viva Πληρωμή ".$this->config->item('test_cost')."&euro;");?></a><br>
		</div>
		<div class="col-md-3 text-center"> 
			<a class="btn btn-lg btn-warning pay_button blue" href="<?php echo site_url('user/add_groupon'); ?>"><?php echo $this->users->echo_lang_text("I have a coupon","Έχω κουπόνι");?></a>
		</div>
		<div class="col-md-2 text-center"> 
		</div>
	</div>
	<div class="col-md-12 text-center">
		<div class="col-md-2 text-center"> 
		</div>
		<div class="col-md-4 text-center">
<!-- VIVA start of code -->
            <a href="<?php echo site_url('user/payment2'); ?>">DEMO-VIVA</a>
		</div>
		
		<div class="col-md-4 text-center">
<!-- Paypal start of code -->
    <?php if(!empty($products)): foreach($products as $product): ?>
        <a href="<?php echo base_url().'products/buy/'.$product['id']; ?>"><img src="<?php echo base_url(); ?>assets/img/pay15en.png" style="width: 250px;"></a>
    <?php endforeach; endif; ?>
        </div>

		<div class="col-md-2 text-center"> 

<form method="post" action="?" id="form1">
    <div style="color:white">
        <p> 
            SELECT: 
        </p>
             
        <p>
         <input style="width: 1em; height: 1em;" type="radio" name="radio" value="VivaPayments" checked>
          <img src="<?php echo base_url().'/assets/img/logo_creditcards_01.svg';?>"  width="250">
        </p>     
        <p>
         <input style="width: 1em; height: 1em;" type="radio" name="radio" value="PayPal">
            <img src="https://www.paypalobjects.com/webstatic/en_US/i/buttons/buy-logo-large.png" width="250" alt="Buy now with PayPal" />
        </p>     
        <p>
         <input style="width: 1em; height: 1em;" type="radio" name="radio" value="Coupon">
            <img src="<?php echo base_url().'/assets/img/couponi.jpg';?>"  width="250">
        </p>     
        <p>
              <input style="width: 1em; height: 1em;" type="checkbox" id="oroixrisis" name="acceptrule" />
               <span>You have to accept</span> <a href="#">The Rules</a>
        </p>
    </div> 
    <button class="btn btn-lg btn-warning pay_button blue" style="width: 200px; height: 70px;  font-weight:700; font-size: 1.8em; margin-left:30px; " type="submit" form="form1" value="Submit">ΠΛΗΡΩΜΗ</button>

 </form>

<?PHP
    /*
    if( $paymeth === 'VivaPayments'){
        $paymeth = "VIVA";   
    } else if ( $paymeth === 'PayPal') {
        $paymeth = "PAYPAL";   
    } else if ( $paymeth === 'Coupon') {
        $paymeth = "COUPON";   
    } else $paymeth="";
    echo "PAY METHOD:".$paymeth;
    */
      ?>		
		
		
		</div>
	</div>
</div>