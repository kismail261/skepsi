<?php $this->load->view('layout/step_header'); ?>
<div class="row black">
	<div class="col-md-6 col-md-offset-3 text-right steps_counter">
		<p><?php echo $this->users->echo_lang_text('Step','Βήμα:');?> 18/50</p>
	</div>
</div>
<div class="row start_page">
	<div class="col-md-6 col-md-offset-3 step_content">
		<p><?php echo $this->users->echo_lang_text('The new people you meet can understand your interests:','Τα νέα άτομα που συναντάτε μπορούν να καταλάβουν τα ενδιαφέροντά σας:');?></p>
		<div class="col-md-12 question_panel">
			<?php echo form_open(); ?>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question17', 'class' => 'check_box', 'checked' => false, 'value' => 1]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('instantly','αμέσως');?></span>
			</label>				
			</div>
			<div class="ita"><?php echo $this->users->echo_lang_text('or','ή');?></div>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question17', 'class' => 'check_box', 'checked' => false, 'value' => 2]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('only after they have known you well','αφού πρώτα σας έχουν γνωρίσει');?></span>
			</label>				
			</div>
			<div class="form-group">
			<?php echo form_submit('next', $this->users->echo_lang_text(html_entity_decode('Next &#9654;&#9654;'),html_entity_decode('Επόμενο &#9654;&#9654;')), 'class="btn btn-lg btn-warning btn-next"'); ?>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>
<br>
<br>
<br>
<br>
<?php $this->load->view('layout/step_footer'); ?>