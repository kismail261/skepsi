<?php $this->load->view('layout/step_header'); ?>
<div class="row black">
	<div class="col-md-6 col-md-offset-3 text-right steps_counter">
		<p><?php echo $this->users->echo_lang_text('Step','Βήμα:');?> 47/50</p>
	</div>
</div>
<div class="row start_page">
	<div class="col-md-6 col-md-offset-3 step_content">
		<p><?php echo $this->users->echo_lang_text('Which of the two words do you prefer the most?<br>Think according to what may be the meaning of these words<br>and not how they may look or sound like, and mark the corresponding scale:','Ποια  από  τις δύο λέξεις σας αρέσει περισσότερο;<br>Σκεφτείτε  τι μπορεί να σημαίνουν οι λέξεις<br>και όχι πως μπορεί να φαίνονται ή να ηχούν:');?></p>
		<div class="col-md-12 question_panel">
			<?php echo form_open(); ?>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question46', 'class' => 'check_box', 'checked' => false, 'value' => 1]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('Hard','Σκληρό');?></span>
			</label>				
			</div>
			<div class="ita"><?php echo $this->users->echo_lang_text('or','ή');?></div>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question46', 'class' => 'check_box', 'checked' => false, 'value' => 2]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('Soft','Μαλακό');?></span>
			</label>				
			</div>
			<div class="form-group">
			<?php echo form_submit('next', $this->users->echo_lang_text(html_entity_decode('Next &#9654;&#9654;'),html_entity_decode('Επόμενο &#9654;&#9654;')), 'class="btn btn-lg btn-warning btn-next"'); ?>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>
<br>
<br>
<br>
<br>
<?php $this->load->view('layout/step_footer'); ?>