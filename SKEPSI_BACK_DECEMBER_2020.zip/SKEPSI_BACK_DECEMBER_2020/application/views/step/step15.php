<?php $this->load->view('layout/step_header'); ?>
<div class="row black">
	<div class="col-md-6 col-md-offset-3 text-right steps_counter">
		<p><?php echo $this->users->echo_lang_text('Step','Βήμα:');?> 16/50</p>
	</div>
</div>
<div class="row start_page">
	<div class="col-md-6 col-md-offset-3 step_content">
		<p><?php echo $this->users->echo_lang_text('When you meet up with friends, usually','Όταν βρίσκεστε με φίλους συνήθως:');?></p>
		<div class="col-md-12 question_panel">
			<?php echo form_open(); ?>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question15', 'class' => 'check_box', 'checked' => false, 'value' => 1]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('you have updates on every one of them','έχετε να πείτε κάτι νέο για τον καθένα');?></span>
			</label>				
			</div>
			<div class="ita"><?php echo $this->users->echo_lang_text('or','ή');?></div>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question15', 'class' => 'check_box', 'checked' => false, 'value' => 2]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('you are the last one to find out what is going on','είσαστε ο τελευταίος που μαθαίνει τι γίνεται');?></span>
			</label>				
			</div>
			<div class="form-group">
			<?php echo form_submit('next', $this->users->echo_lang_text(html_entity_decode('Next &#9654;&#9654;'),html_entity_decode('Επόμενο &#9654;&#9654;')), 'class="btn btn-lg btn-warning btn-next"'); ?>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>
<br>
<br>
<br>
<br>
<?php $this->load->view('layout/step_footer'); ?>