<?php $this->load->view('layout/step_header'); ?>
<div class="row black">
	<div class="col-md-6 col-md-offset-3 text-right steps_counter">
		<p><?php echo $this->users->echo_lang_text('Step','Βήμα:');?> 15/50</p>
	</div>
</div>
<div class="row start_page">
	<div class="col-md-6 col-md-offset-3 step_content">
		<p><?php echo $this->users->echo_lang_text('You would prefer to be friends with:','Θα προτιμούσατε να είχατε φίλο:');?></p>
		<div class="col-md-12 question_panel">
			<?php echo form_open(); ?>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question14', 'class' => 'check_box', 'checked' => false, 'value' => 1]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('someone who always thinks of new ideas','κάποιον που πάντα σκέφτεται νέες ιδέες');?></span>
			</label>				
			</div>
			<div class="ita"><?php echo $this->users->echo_lang_text('or','ή');?></div>
			<div class="checkbox">
			<label>
			<?php echo form_radio(['name' => 'question14', 'class' => 'check_box', 'checked' => false, 'value' => 2]); ?> <span class="question_text"><?php echo $this->users->echo_lang_text('someone reliable','κάποιον που πατά και με τα δύο του πόδια στο έδαφος');?></span>
			</label>				
			</div>
			<div class="form-group">
			<?php echo form_submit('next', $this->users->echo_lang_text(html_entity_decode('Next &#9654;&#9654;'),html_entity_decode('Επόμενο &#9654;&#9654;')), 'class="btn btn-lg btn-warning btn-next"'); ?>
			</div>
			<?php echo form_close(); ?>
		</div>
	</div>
</div>
<br>
<br>
<br>
<br>
<?php $this->load->view('layout/step_footer'); ?>