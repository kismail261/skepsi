<div id="header" style="height: 60px;position: absolute;top: 0;left: 0;right: 0;background-color: #FACB43;">
<div id="wraper" style="max-width: 600px;margin: 0 auto;">
<h2 style="float: left;padding-left: 5px;">Skepsi.eu</h2>
<div id="datetime" style="float: right;padding-right: 5px;margin-top: 25px;"><?php echo mdate('%d/%m/%Y', (int)$test->date); ?></div>
</div>
</div>
<div id="container" style="max-width: 600px;margin: 85px auto;">

<p><?php echo $this->users->echo_lang_text("We wish to thank you for participating in Skepsis Graph test and let you know your results.","Επιθυμούμε να σε ευχαριστήσουμε για τη συμμετοχή σου στο τεστ «Σκεψιγράφημα» και να σου ανακοινώσουμε τα αποτελέσματα σου.");?></p>

<p><?php echo $this->users->echo_lang_text("According to your answers, your profile of Mind and Behavior is ","Σύμφωνα με όσα σημείωσες στο σχετικό ερωτηματολόγιο, το προφίλ Σκέψης και Συμπεριφοράς σου είναι ");?><strong><?php echo ($left > $right) ? $this->users->echo_lang_text('«Left Domination»','«Αριστερής Κυριαρχίας»') : $this->users->echo_lang_text('«Right Domination»','«Δεξιάς Κυριαρχίας»'); ?></strong>, <?php echo $this->users->echo_lang_text("score on left","με σκορ αριστερά ");?><strong><?php echo $left; ?></strong> <?php echo $this->users->echo_lang_text("and on right ","και δεξιά ");?><strong><?php echo $right; ?></strong>.</p>

<p><?php echo $this->users->echo_lang_text("This means that you are using more, depending on the stimuli you are receiving or the environment you have to deal with, the dominant skills of the right or the left hemisphere of your brain.","Αυτό σημαίνει ότι χρησιμοποιείς περισσότερο,ανάλογα με τα ερεθίσματα που δέχεσαι ή το περιβάλλον που έχεις να αντιμετωπίσεις, τις κυρίαρχες ικανότητες του δεξιού ή του αριστερού ημισφαιρίου του εγκεφάλου σου.");?></p>

<p><?php echo $this->users->echo_lang_text("Let me remind you that the dominant functions of your left hemisphere are: writing, symbolism, speech, reading, spelling, locating details and facts, analytical and mathematical thinking, speaking and reciting, applying instructions, listening, association to sounds, problem solving, technique and the logic. These give the person Control, Conservation, Planning, Organizational and Administrative Behavior.","Σου θυμίζω ότι οι κυρίαρχες λειτουργίες του αριστερού ημισφαιρίου είναι : η γραφή, ο συμβολισμός, ο λόγος, η ανάγνωση, ο συλλαβισμός, η εντόπιση λεπτομερειών και γεγονότων, η αναλυτική και μαθηματική σκέψη, η ομιλία και απαγγελία, η εφαρμογή οδηγιών, η ακοή, ο συνειρμός ήχων, η λύση προβλημάτων, η τεχνική και η λογική. Αυτά προσδίδουν στο άτομο Ελεγκτική, Συντηρητική, Προγραμματιστική, Οργανωτική και Διοικητική συμπεριφορά.");?></p>

<p><?php echo $this->users->echo_lang_text("The dominant functions of the right hemisphere are: touch, space perception, formatting, numbering, color sensitivity, song and music, creativity, imagination, artistic expression, feelings and emotions, synthetic, imaginative and holistic thinking. These give the person Interpersonal, Emotional, Musical, Spiritual and Participatory Behavior.","Οι κυρίαρχες λειτουργίες του δεξιού ημισφαιρίου είναι : η αφή, η αντίληψη χώρου, η σχηματοποίηση, η αρίθμηση, η ευαισθησία στα χρώματα, το τραγούδι και η μουσική, η δημιουργικότητα, η φαντασία, η καλλιτεχνική έκφραση, τα αισθήματα και οι συγκινήσεις, η συνθετική, επινοητική και ολιστική σκέψη. Αυτά προσδίδουν στο άτομο Διαπροσωπική, Συναισθηματική, Μουσική, Πνευματική και Συμμετοχική συμπεριφορά.");?></p>

<p><?php echo $this->users->echo_lang_text("Your answers result that you are a type. ","Επίσης προκύπτει πως είσαι τύπος ");?><strong><?php echo $test->charact; ?> </strong><?php echo $this->users->echo_lang_text("that means","δηλαδή"); ?> <strong><?php echo $this->users->echo_lang_text($char->desc_en,$char->desc); ?></strong>.</p>
<br>
<p><?php echo $this->users->echo_lang_text("In details,","Αναλυτικότερα τώρα,");?></p>

<?php foreach($types as $t): ?>
  <p><?php echo $this->users->echo_lang_text($t->l_body_en,$t->l_body); ?></p>
<?php endforeach; ?>

<br>
<p><?php echo $this->users->echo_lang_text($char->body_en,$char->body); ?></p>

<br><br><br>

<?php echo $this->users->echo_lang_text("Best Regards","Με τις καλύτερες ευχές μας");?>
<br><br>
<?php echo $this->users->echo_lang_text("Christos Mouratidis","Χρήστος Μουρατίδης");?>
<br>
<?php echo $this->users->echo_lang_text("Mathematician, M.Ed., M.Sc.","Μαθηματικός, M.Ed., M.Sc.");?>
<br><br>
<?php echo $this->users->echo_lang_text("Pericles Papageorgiou","Περικλής Παπαγεωργίου");?><br>
<?php echo $this->users->echo_lang_text("Business Consultant PhD","Επιχειρησιακός Σύμβουλος PhD");?>
</div>

