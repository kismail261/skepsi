<?php $this->load->view('layout/admin_nav'); ?>
<div class="row two">
<div class="col-md-4 col-md-offset-4">
	<?php echo form_open(); ?>
		<input type="text" style="opacity:0">
		<input type="password" style="opacity:0">
		<div class="form-group">
    		<label for="exampleInputEmail1">Αριθμός κουπονιών</label>
    		<?php echo form_dropdown('total', [1,2,3,4,5], 0, 'class="form-control"'); ?>
  		</div>
  		<div class="form-group">
    		<?php echo form_submit('create', 'Πάμε', 'class="btn btn-lg btn-warning"'); ?>
  		</div>
		<?php echo form_close(); ?>
</div>
</div>