<?php $this->load->view('layout/admin_nav'); ?>
<div class="row two">
<div class="col-md-6 col-md-offset-3">
	<table class="table">
	<?php if(count($users)): ?>
	<tr>
		<td>email</td>
		<td>Φύλο</td>
		<td>Ημερομ γεν</td>
		<td>delete</td>
	</tr>
	<?php foreach($users as $user): ?>
		<tr>
			<td><?php echo $user->email; ?></td>
			<td><?php echo $user->gender; ?></td>
			<td><?php echo $user->yearbirthdate; ?></td>
			<td><?php echo anchor(site_url('admin/user_delete/' . $user->id), 'Delete', array(
'onclick' => "return confirm('Σίγουρα θέλεις να διαγράψεις χρήστη?');")); ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
	<?php else: ?>
	<p>Δεν υπάρχουν χρήστες</p>
	<?php endif; ?>
</div>
</div>

<div class="row">
<div class="com-md-12 pagination_links text-center">
<?php echo $this->pagination->create_links(); ?>
</div>
</div>