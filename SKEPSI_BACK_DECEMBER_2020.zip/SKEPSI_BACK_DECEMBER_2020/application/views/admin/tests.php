<?php $this->load->view('layout/admin_nav'); ?>
<div class="row two">
<div class="col-md-6 col-md-offset-3">
	<table class="table">
	<?php if(count($tests)): ?>
	<tr>
		<td>username</td>
		<td>character</td>
		<td>left</td>
		<td>right</td>
		<td>date</td>
	</tr>
	<?php foreach($tests as $test): ?>
		<tr>
			<td><?php echo $test->email; ?></td>
			<td><?php echo $test->charact; ?></td>
			<td><?php echo $test->left_sum; ?>%</td>
			<td><?php echo $test->right_sum; ?>%</td>
			<td><?php echo mdate('%d-%m-%Y', $test->date); ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
	<?php else: ?>
	<p>Δεν υπάρχουν tests</p>
	<?php endif; ?>
</div>
</div>

<div class="row">
<div class="com-md-12 pagination_links text-center">
<?php echo $this->pagination->create_links(); ?>
</div>
</div>