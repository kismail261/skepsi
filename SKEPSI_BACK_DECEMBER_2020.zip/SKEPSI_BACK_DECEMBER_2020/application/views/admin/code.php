<?php $this->load->view('layout/admin_nav'); ?>
<div class="row two">
<div class="col-md-6 col-md-offset-3">
	<table class="table">
	<?php if(count($groupons)): ?>
	<tr>
		<td>Id</td>
		<td>Κωδικοί</td>
		<td>Χρησιμοποιημένα</td>
		<td>Σταλμένα</td>
		<td>Διαγραφή</td>
	</tr>
	<?php foreach($groupons as $groupon): ?>
		<tr>
			<td><?php echo $groupon->id; ?></td>
			<td><?php echo $groupon->code; ?></td>
			<td><?php echo $groupon->used == 0 ? 'Όχι' : 'Ναί' ; ?></td>
			<td><?php echo $groupon->assets == 0 ? 'Όχι' : 'Ναί' ; ?><br><?php echo anchor('admin/code_change/'.$groupon->id , 'Αλλαγή'); ?></td>
			<td><?php echo anchor('admin/code_delete/' . $groupon->id, 'Delete'); ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
	<?php else: ?>
	<p>Δεν υπάρχουν κωδικοί</p>
	<?php endif; ?>
</div>
</div>

<div class="row">
<div class="com-md-12 pagination_links text-center">
<?php echo $this->pagination->create_links(); ?>
</div>
</div>