<?php $this->load->view('layout/admin_nav'); ?>
<div class="row">
<div class="col-md-4"></div>
	<div class="col-md-4 one">
		<?php echo validation_errors(); ?>
		<?php echo form_open(); ?>
		<input type="text" style="opacity:0">
		<input type="password" style="opacity:0">
		<div class="form-group">
    		<label for="exampleInputEmail1">Username</label>
    		<?php echo form_input(['name' => 'username', 'value' => $admin->username, 'placeholder' => 'Όνομα χρήστη', 'class' => 'form-control']); ?>
  		</div>
  		<div class="form-group">
        <label for="exampleInputEmail1">Password</label>
        <?php echo form_password(['name' => 'password', 'placeholder' => 'Κωδικός πρόσβασης', 'class' => 'form-control']); ?>
      </div>
      <div class="form-group">
    		<label for="exampleInputEmail1">Password Again</label>
    		<?php echo form_password(['name' => 'repassword', 'placeholder' => 'Επανάληψη Κωδικού πρόσβασης', 'class' => 'form-control']); ?>
  		</div>
  		<div class="form-group">
        <?php echo form_hidden('id', $admin->id); ?>
    		<?php echo form_submit('login', 'Προσθήκη', 'class="btn btn-lg btn-warning"'); ?>
  		</div>
		<?php echo form_close(); ?>
	</div>
</div>