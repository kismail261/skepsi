<?php $this->load->view('layout/admin_nav'); ?>
<div class="row two">
<div class="col-md-6 col-md-offset-3">
	<table class="table">
	<?php if(count($admins)): ?>
	<tr>
		<td>username</td>
		<td>edit</td>
		<td>delete</td>
	</tr>
	<?php foreach($admins as $admin): ?>
		<tr>
			<td><?php echo $admin->username; ?></td>
			<td><?php echo anchor(site_url('admin/admin_edit/' . $admin->id), 'Edit'); ?></td>
			<td><?php echo anchor(site_url('admin/admin_delete/' . $admin->id), 'Delete', array(
'onclick' => "return confirm('Σίγουρα θέλεις να διαγράψεις διαχειριστή?');")); ?></td>
		</tr>
	<?php endforeach; ?>
	</table>
	<?php else: ?>
	<p>Δεν υπάρχουν διαχειριστές</p>
	<?php endif; ?>
</div>
</div>

<div class="row">
<div class="com-md-12 pagination_links text-center">
<?php echo $this->pagination->create_links(); ?>
</div>
</div>