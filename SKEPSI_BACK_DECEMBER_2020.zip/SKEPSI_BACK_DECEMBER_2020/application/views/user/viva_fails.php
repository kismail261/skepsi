<div class="row register_page white">
	<div class="col-md-4 col-md-offset-4 register_content">
		<h3><?php echo $this->users->echo_lang_text("The payment canceled by Vivapayments.","Η πληρωμή ακυρώθηκε απο Vivapayments.");?></h3>
		<a class="btn btn-lg btn-warning success_payment_btn" href="<?php echo site_url('home/pay'); ?>"><?php echo $this->users->echo_lang_text("Try again","Προσπάθησε πάλι");?></a>
	</div>
</div>