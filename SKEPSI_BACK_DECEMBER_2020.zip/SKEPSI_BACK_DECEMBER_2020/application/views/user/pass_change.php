<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
			<div class="valerrors">
			<?php 
				echo $this->users->echo_valid_errors(validation_errors()); 
			?>
			</div>
		<?php echo form_open(); ?>
		<input type="text" style="opacity:0">
		<input type="password" style="opacity:0">
		<div class="form-group">
	    <label for="exampleInputEmail1"><?php echo $this->users->echo_lang_text("Old password","Παλιός κωδικός πρόσβασης");?></label>
			<?php echo form_password(['name' => 'oldpassword', 'class' => 'form-control', 'value' => set_value('oldpassword')]); ?>
		</div>
		<div class="form-group">
	    <label for="exampleInputEmail1"><?php echo $this->users->echo_lang_text("New password","Νέος κωδικός πρόσβασης");?></label>
			<?php echo form_password(['name' => 'newpassword', 'class' => 'form-control', 'value' => set_value('newpassword')]); ?>
		</div>
		<div class="form-group">
	    <label for="exampleInputEmail1"><?php echo $this->users->echo_lang_text("Retype New password","Επανάληψη νέου κωδικός πρόσβασης");?></label>
			<?php echo form_password(['name' => 'renewpassword', 'class' => 'form-control', 'value' => set_value('renewpassword')]); ?>
		</div>
		<div class="form-group">
			<?php echo form_submit('pass_change', $this->users->echo_lang_text("Change Password","Αλλαγή κωδικού"), 'class="btn btn-lg btn-info"'); ?>
		</div>
		<?php echo form_close(); ?>
	</div>
</div>