<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
		<h2><?php echo $this->users->echo_lang_text("Successful registration!","Επιτυχής εγγραφή!");?></h2>
		<a class='btn btn-md btn-warning success_reg_link'href="<?php echo site_url('home/start'); ?>"><?php echo $this->users->echo_lang_text("Start Test","Ξεκίνα το test");?></a>  ή <a class='btn btn-md btn-warning success_reg_link'href="<?php echo site_url('user/account'); ?>"><?php echo $this->users->echo_lang_text("My account","Πήγαινε στον λογαριασμό μου");?></a>
	</div>
</div>