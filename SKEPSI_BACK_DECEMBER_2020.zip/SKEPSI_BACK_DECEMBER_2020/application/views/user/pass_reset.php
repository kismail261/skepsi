<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
		    <span class="message"><?php if($this->session->has_userdata('messagemail')): echo $this->session->userdata('messagemail'); endif; ?></span>
			<?php echo validation_errors(); ?>
			<?php echo form_open(); ?>
			<input type="text" style="opacity:0">
			<input type="password" style="opacity:0">
			<div class="form-group">
			<label for="password1"><?php echo $this->users->echo_lang_text("New password","Νέος Κωδικός πρόσβασης");?></label>
			<?php echo form_password(['name' => 'password', 'class' => 'form-control', 'id' => 'password1', 'autocomplete' => 'off']); ?>
			</div>
			<div class="form-group">
			<label for="password2"><?php echo $this->users->echo_lang_text("retype New password","Επανάλληψη νέου κωδικού πρόσβασης");?></label>
			<?php echo form_password(['name' => 'repassword', 'class' => 'form-control', 'id' => 'password2', 'autocomplete' => 'off']); ?>
			</div>
			<?php echo form_submit('change', $this->users->echo_lang_text("Change Password","Αλλαγή κωδικού"), 'class="btn btn-lg btn-info"'); ?>
			<?php echo form_close(); ?>
	</div>
</div>