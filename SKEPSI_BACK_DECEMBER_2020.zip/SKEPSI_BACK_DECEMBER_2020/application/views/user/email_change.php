<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
			<div class="valerrors">
			<?php 
				echo $this->users->echo_valid_errors(validation_errors()); 
			?>
			</div>
		<?php echo form_open(); ?>
		<!--
		<input type="text" style="opacity:0">
		<input type="password" style="opacity:0">
		-->
		<div class="form-group">
	    <label for="exampleInputEmail1"><?php echo $this->users->echo_lang_text("Current email","Email που έχετε:");?></label>
			<?php echo form_input(['name' => 'email', 'class' => 'form-control', 'value' => $email, 'placeholder' => $email, 'disabled' => 'disabled']); ?>
		</div>
		<div class="form-group">
	    <label for="exampleInputEmail1"><?php echo $this->users->echo_lang_text("New email","Νέο email");?></label>
			<?php echo form_input(['name' => 'newemail', 'type' => 'email', 'class' => 'form-control', 'value' => set_value('newemail')]); ?>
		</div>
		<div class="form-group">
			<?php echo form_submit('email_change', $this->users->echo_lang_text("Change Email","Αλλαγή email"), 'class="btn btn-lg btn-info"'); ?>
		</div>
		<?php echo form_close(); ?>
	</div>
</div>