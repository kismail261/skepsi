<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
	    <h2><?php echo $this->users->echo_lang_text("My Account","Ο Λογαριασμός μου");?></h2>
		<ul class="list-group list_account">
		<li class="list-group-item"><a href="<?php echo site_url('home/start'); ?>"><?php echo $this->users->echo_lang_text("Start Test ","Ξεκίνησε το test ");?></a><small class="start_new_test"><?php echo $this->users->echo_lang_text("(It is recommended that the tests be at least 6 months apart)","(Συνίσταται τα test να έχουν τουλάχιστον 6 μήνες διαφορά)");?></small></li>

		<li class="list-group-item"><a href="<?php echo site_url('user/result_test'); ?>"><?php echo $this->users->echo_lang_text("Get your results","Δες τα αποτελέσματα σου");?></a></li>

		<li class="list-group-item"><a href="<?php echo site_url('user/pass_change'); ?>"><?php echo $this->users->echo_lang_text("Change Password","Αλλαγή κωδικού πρόσβασης");?></a></li>
		
		<li class="list-group-item"><a href="<?php echo site_url('user/email_change'); ?>"><?php echo $this->users->echo_lang_text("Change Email","Αλλαγή email");?></a>
		
		<li class="list-group-item"><a href="<?php echo site_url('home/pay'); ?>"><?php echo $this->users->echo_lang_text("Pay for Test","Πλήρωσε για το test");?></a></li>
		
		<li class="list-group-item"><a href="<?php echo site_url('user/add_groupon'); ?>"><?php echo $this->users->echo_lang_text("Insert Code","Βάλε το κουπόνι");?></a></li>
		
		</ul>
	</div>
</div>