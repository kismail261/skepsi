<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
		<h2><?php echo $this->users->echo_lang_text('Register to Start','Κάνε εγγραφή για να ξεκινήσεις');?></h2>
			<div class="valerrors">
			<?php 
				echo $this->users->echo_valid_errors(validation_errors()); 
			?>
			</div>
			<?php echo form_open(); ?>
			<input type="text" style="opacity:0">
			<input type="password" style="opacity:0">
			<div class="form-group">
			<label for="email1">Email</label>
			<?php echo form_input(['type' => 'email','name' => 'email', 'placeholder' => $this->users->echo_lang_text('e.g. test@example.com','π.χ. test@example.com'), 'class' => 'form-control', 'id' => 'email1', 'autocomplete' => 'off', 'value' => set_value('email')]); ?>
			</div>
			<div class="form-group">
			<label for="password1"><?php echo $this->users->echo_lang_text('Password','Κωδικός πρόσβασης');?></label>
			<?php echo form_password(['name' => 'password', 'class' => 'form-control', 'id' => 'password1', 'autocomplete' => 'off', 'value' => set_value('password')]); ?>
			</div>
			<div class="form-group">
			<label for="password2"><?php echo $this->users->echo_lang_text('Retype Password','Επανάλληψη κωδικού πρόσβασης');?></label>
			<?php echo form_password(['name' => 'repassword', 'class' => 'form-control', 'id' => 'password2', 'autocomplete' => 'off', 'value' => set_value('repassword')]); ?>
			</div>
			<div class="form-group">
			<label for="gender"><?php echo $this->users->echo_lang_text('Select Gender','Επέλεξε φύλο');?></label>
			<?php echo form_dropdown('gender', ['male' => $this->users->echo_lang_text('Male','Άνδρας'), 'female' => $this->users->echo_lang_text('Female','Γυναίκα')], 'male', 'class="form-control" id="gender"'); ?>
			</div>
			<div class="form-group">
			<label for="year"><?php echo $this->users->echo_lang_text('Year of birth','Έτος γέννησης');?></label>
			<?php
				$year = [];
				for ($i=1950; $i <= date('Y'); $i++) { 
					$year[$i] = $i;
				}
			?>
			<?php echo form_dropdown('year', $year, date('Y'), 'class="form-control" id="year"'); ?>
			</div>
			<?php echo form_submit('register', $this->users->echo_lang_text('Register','Εγγραφή'), 'class="btn btn-lg btn-info"'); ?>
			<?php echo form_close(); ?>
	</div>
</div>