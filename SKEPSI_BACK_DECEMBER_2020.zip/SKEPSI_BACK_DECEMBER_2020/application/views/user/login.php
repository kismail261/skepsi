<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
			<h2><?php echo $this->users->echo_lang_text('Login/Register','Σύνδεση/Εγγραφή');	?></h2>
			<div class="valerrors">
			<?php 
				echo $this->users->echo_valid_errors(validation_errors()); 
			?>
			</div>
			<?php echo form_open(); ?>
			<input type="text" style="opacity:0">
			<input type="password" style="opacity:0">
			<div class="form-group">
			<label for="email1">Email</label>
			<?php echo form_input(['type' => 'email','name' => 'email', 'placeholder' => $this->users->echo_lang_text('e.g. test@example.com','π.χ. test@example.com'), 'class' => 'form-control', 'id' => 'email1', 'autocomplete' => 'off', 'value' => set_value('email')]); ?>
			</div>
			<div class="form-group">
			<label for="password1"><?php echo $this->users->echo_lang_text('Password','Κωδικός πρόσβασης');
			?></label>
			<?php echo form_password(['name' => 'password', 'class' => 'form-control', 'id' => 'password1', 'autocomplete' => 'off', 'value' => set_value('password')]); ?>
			</div>

			<div class="form-group">
			<p><a class="white" href="<?php echo site_url('user/forgot_pass'); ?>"><?php 
				echo $this->users->echo_lang_text('Forgot password?','Ξέχασες τον κωδικό;');
				?></a></p>
			</div>

			<div class="form-group">
				<p>
				<br>
			<?php 
			echo form_submit('login', $this->users->echo_lang_text('Login','Σύνδεση'), 'class="btn btn-lg btn-info blue"'); 
			?>  <a class="white" href="<?php echo site_url('user/register'); ?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php 
				echo $this->users->echo_lang_text('Registration','Δημιουργία λογαριασμού');
				?></a>
				</p>
			</div>
			
			<?php echo form_close(); ?>
	</div>
</div>