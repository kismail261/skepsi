<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
		<h2><?php echo $this->users->echo_lang_text("Enter the email with which you registered and we will send you an email with a cancellation code","Γράψτε το email με το οποίο κάνατε εγγραφή και θα σας στείλουμε στο email κωδικό ακύρωσης κωδικού");?></h2>
		    <span class="message"><?php if($this->session->has_userdata('messagemail')): echo $this->session->userdata('messagemail'); endif; ?></span>
			<div class="valerrors">
			<?php 
				echo $this->users->echo_valid_errors(validation_errors()); 
			?>
			</div>
			<?php echo form_open(); ?>
			<input type="text" style="opacity:0">
			<input type="password" style="opacity:0">
			<div class="form-group">
			<label for="email1">Email</label>
			<?php echo form_input(['type' => 'email', 'name' => 'email', 'placeholder' => $this->users->echo_lang_text('e.g. test@example.com','π.χ. test@example.com'), 'class' => 'form-control', 'id' => 'email1', 'autocomplete' => 'off']); ?>
			</div>
			<?php echo form_submit('sent', $this->users->echo_lang_text("Send","Αποστολή"), 'class="btn btn-lg btn-info"'); ?>
			<?php echo form_close(); ?>
	</div>
</div>