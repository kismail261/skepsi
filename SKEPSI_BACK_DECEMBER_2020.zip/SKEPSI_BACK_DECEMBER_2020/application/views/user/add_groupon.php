<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
		<h2><?php echo $this->users->echo_lang_text("Add your Code","Πρόσθεσε τον κωδικό σου");?></h2>
			<?php echo validation_errors(); ?>
			<?php echo form_open(); ?>
			<input type="text" style="opacity:0">
			<input type="password" style="opacity:0">
			<div class="form-group">
			<label for="email1"><?php echo $this->users->echo_lang_text("Code","Κωδικός");?></label>
			<?php echo form_input(['type' => 'text','name' => 'groupon', 'placeholder' => $this->users->echo_lang_text("e.g. 23dfdr567j","π.χ. 23dftr567j"), 'class' => 'form-control', 'id' => 'email1', 'autocomplete' => 'off']); ?>
			</div>
			<div class="form-group">
			<?php echo form_submit('add', $this->users->echo_lang_text("Add code","Προσθήκη κωδικού"), 'class="btn btn-lg btn-info bold"'); ?>
			</div>
			<?php echo form_close(); ?>
	</div>
</div>