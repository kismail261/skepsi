<div class="row show_result_black">
	<div class="col-md-4 col-md-offset-4 register_content">
		<ul class="list-group">
			<li class="list-group-item"><?php echo $this->users->echo_lang_text("Date: ","Ημερ/ία Test: ");?><span class="test_res"><?php echo mdate('%d - %m - %Y', (int)$test->date); ?></span></li>
			<li class="list-group-item"><?php echo $this->users->echo_lang_text("User mail: ","Email χρήστη: ");?><span class="test_res"><?php echo $test->email; ?></span></li>
			<li class="list-group-item"><?php echo $this->users->echo_lang_text("Left hemisphere: ","Αριστερό ημισφαίριο: ");?><span class="test_res"><?php echo $test->left_sum; ?></span></li>
			<li class="list-group-item"><?php echo $this->users->echo_lang_text("Right hemisphere: ","Δεξιό ημισφαίριο: ");?><span class="test_res"><?php echo $test->right_sum; ?></span></li>
			<li class="list-group-item"><?php echo $this->users->echo_lang_text("Character type: ","Τύπος χαρακτήρα: ");?><span class="test_res"><?php echo $test->charact; ?></span></li>
		</ul>
	</div>
</div>

<div class="row show_result_black white">
	<div class="col-md-8 col-md-offset-2 charact_area">
		<h4><?php echo $this->users->echo_lang_text("Result of Skepis Graph","Αποτέλεσμα σκεψηγραφήματος:");?></h4>
		<p><?php echo $this->users->echo_lang_text($test->body_en,$test->body); ?></p>
	</div>	
</div>

<div class="row show_result_black white">
	<div class="col-md-8 col-md-offset-2 charact_letter">
		<h4><?php echo $this->users->echo_lang_text("Based on your character type in addition:","Με βάση τον τύπο του χαρακτήρα σου επιπλέον:");?></h4>
		<?php foreach($letter as $l): ?>
			<p><?php echo $this->users->echo_lang_text($l->l_body_en,$l->l_body); ?></p>
		<?php endforeach; ?>
	</div>	
</div>
</div>