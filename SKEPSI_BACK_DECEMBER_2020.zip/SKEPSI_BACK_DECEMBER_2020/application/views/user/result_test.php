<div class="row register_page">
	<div class="col-md-4 col-md-offset-4 register_content">
		<?php if($tests): ?>
		<ul class="list-group list_account">
		<?php foreach($tests as $test): ?>
	        <?php if($test->finish == 1){ ?>
    		<li class="list-group-item"><a href="<?php echo site_url('user/show_test/'.$test->id); ?>"><?php echo $this->users->echo_lang_text("Finished at","Ολοκληρωμένο στις");?> <?php echo mdate('%d - %m - %Y', (int)$test->date); ?> <small class="small_date"><?php echo $this->users->echo_lang_text("details","λεπτομέρειες");?></small></a></li>
    		<?php } else { ?>
            <div class="alert alert-danger" role="alert">
			    <p><?php echo $this->users->echo_lang_text("You have not completed the test yet","Δεν έχετε ολοκληρώσει ακόμα το test");?>, <a href="<?php echo site_url('home/start'); ?>"><?php echo $this->users->echo_lang_text("start it now","ξεκινήστε το τώρα");?></a></p>
		    </div>
		    		<?php }  ?>

		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</div>
</div>