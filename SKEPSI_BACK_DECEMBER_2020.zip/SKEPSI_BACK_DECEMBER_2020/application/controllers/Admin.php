<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller{

	public function __construct() {        
    	parent::__construct();
    	$this->config->set_item('language', 'greek');
    	$this->load->library('pagination');

    	$no_session = ['index', 'logout'];
    	if (!in_array($this->uri->segment(2), $no_session)) {

    		if (!$this->session->has_userdata('adminlogin') && !$this->session->has_userdata('adminloged_id')) {
    			redirect('admin/logout');
    		}
    		
    	}
	}


	public function index(){

		$data['page'] = 'admin/index';

		if ($this->input->post('login')) {
			$this->form_validation->set_rules('username', 'Όνομα χρήστη', 'trim|required');
			$this->form_validation->set_rules('password', 'Κωδικός πρόσβασης', 'trim|required');

			if($this->form_validation->run() == FALSE){
                echo 'Something Error!!!';
			}else{
				$login = $this->db->get_where('admin', ['username' => $this->input->post('username'), 'password' => md5($this->input->post('password'))])->row();
				if ($login) {
					$this->session->set_userdata('adminlogin', true);
					$this->session->set_userdata('adminloged_id', $login->id);
					redirect('admin/home');
				}
				
			}
		}
		$this->load->view('layout/admin', $data);
	}

	public function logout(){

		$this->session->unset_userdata('adminlogin');
		$this->session->unset_userdata('adminloged_id');
		redirect('admin/index');
	}

	public function home(){

		$data['page'] = 'admin/home';

		$this->load->view('layout/admin', $data);
	}


	public function admins(){

		$config['base_url'] = site_url('admin/admins/');;
        $config['total_rows'] = $this->db->get('admin')->num_rows();
        $config['per_page'] = 15;
        $config['uri_segment'] = 3;
        $config['num_links'] = 5;
        $this->pagination->initialize($config);

		$data['page'] = 'admin/admins';
		$data['admins'] = $this->db->order_by('id', 'DESC')->get('admin', $config['per_page'], $this->uri->segment(3))->result();

		$this->load->view('layout/admin', $data);
	}


	public function admin_add(){

		$data['page'] = 'admin/admin_add';

		if ($this->input->post('login')) {
			$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[12]|is_unique[admin.username]');
			$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]');
			$this->form_validation->set_rules('repassword', 'Password Again', 'trim|required|matches[password]');

			if($this->form_validation->run() == FALSE){

			}else{

				$this->db->insert('admin', ['username' => $this->input->post('username'), 'password' => md5($this->input->post('password'))]);
				redirect('admin/admins');
				
			}
		}

		$this->load->view('layout/admin', $data);
	}

	public function admin_edit($id){

		$data['page'] = 'admin/admin_edit';
		$data['admin'] = $this->db->get_where('admin', ['id' => (int)$id])->row();
		$username = $this->db->get_where('admin', ['id' => (int)$id])->row('username');

		if ($username == $this->input->post('username')) {
			$str = '';
		}else{
			$str = '|is_unique[admin.username]';
		}



		if ($this->input->post('login')) {
			$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[5]|max_length[12]'.$str);
			$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]');
			$this->form_validation->set_rules('repassword', 'Password Again', 'trim|required|matches[password]');

			if($this->form_validation->run() == FALSE){

			}else{
				$this->db->where('id', (int)$this->input->post('id'));
				$this->db->update('admin', ['username' => $this->input->post('username'), 'password' => md5($this->input->post('password'))]);
				redirect('admin/admins');
				
			}
		}

		$this->load->view('layout/admin', $data);
	}


	public function admin_delete($id){

		if((int)$id){
			$this->db->where('id', $id);
			$this->db->delete('admin');
			redirect('admin/admins');
		}
	}

	public function users(){

		$config['base_url'] = site_url('admin/users/');;
        $config['total_rows'] = $this->db->get('users')->num_rows();
        $config['per_page'] = 15;
        $config['uri_segment'] = 3;
        $config['num_links'] = 5;
        $this->pagination->initialize($config);

		
		$data['page'] = 'admin/users';
		$data['users'] = $this->db->order_by('id', 'DESC')->get('users', $config['per_page'], $this->uri->segment(3))->result();




		$this->load->view('layout/admin', $data);
	}

	public function user_delete($id){

		if((int)$id){
			$this->db->where('id', $id);
			$this->db->delete('users');
			redirect('admin/users');
		}
	}



	public function tests(){

		$config['base_url'] = site_url('admin/tests/');;
        $config['total_rows'] = $this->db->get('tests')->num_rows();
        $config['per_page'] = 15;
        $config['uri_segment'] = 3;
        $config['num_links'] = 5;
        $this->pagination->initialize($config);

		$data['page'] = 'admin/tests';
		$this->db->join('users', 'tests.u_id=users.id');
		$data['tests'] = $this->db->where('finish', 1)->order_by('tests.id', 'DESC')->get('tests', $config['per_page'], $this->uri->segment(3))->result();

		$this->load->view('layout/admin', $data);
	}

	public function code(){
		$config['base_url'] = site_url('admin/code/');;
        $config['total_rows'] = $this->db->get('groupons')->num_rows();
        $config['per_page'] = 25;
        $config['uri_segment'] = 3;
        $config['num_links'] = 5;
        $this->pagination->initialize($config);

		$data['page'] = 'admin/code';
		$data['groupons'] = $this->db->order_by('groupons.id', 'DESC')->get('groupons', $config['per_page'], $this->uri->segment(3))->result();




		$this->load->view('layout/admin', $data);
	}


	public function code_generation(){
		$config['base_url'] = site_url('admin/code_generation/');;
        $config['total_rows'] = $this->db->get('groupons')->num_rows();
        $config['per_page'] = 25;
        $config['uri_segment'] = 3;
        $config['num_links'] = 5;
        $this->pagination->initialize($config);

		$data['page'] = 'admin/code_generation';
		$data['groupons'] = $this->db->order_by('groupons.id', 'DESC')->get('groupons', $config['per_page'], $this->uri->segment(3))->result();

		if ($this->input->post('create')) {

			$codes = [];

			for ($i=0; $i <= $this->input->post('total'); $i++) { 
				$codes[] = $i.uniqid();
			}

			if (count($codes)) {
				$multiplecodes = [];
				foreach ($codes as $code) {
					$this->db->insert('groupons', ['code' => $code, 'used' => 0, 'assets' => 0]);
				}
				redirect('admin/code');
			}

		}

		$this->load->view('layout/admin', $data);
	}

	public function code_delete($id){
		if((int)$id){
			$this->db->where('id', $id);
			$this->db->delete('groupons');
			redirect('admin/code');
		}
	}

	public function code_change($id){
		if((int)$id){
			$this->db->where('id', $id);
			$this->db->update('groupons', ['assets' => 1]);
		}
		redirect('admin/code');	
	}

	
}
