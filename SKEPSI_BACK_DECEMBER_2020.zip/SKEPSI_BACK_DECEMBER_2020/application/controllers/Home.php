<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller{

	public function __construct() {        
    	parent::__construct();
        $this->load->library('paypal_lib');
        $this->load->model('product');
    	
	}

	public function index(){

		$data['page'] = 'home/index';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	public function viva_valid(){

		$data['page'] = 'home/viva_valid';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	public function viva_error(){

		$data['page'] = 'home/viva_error';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	public function start_test_index(){
		if($this->users->is_login_return_boolean()) {
			// if user is login go to pay

			if($this->users->is_payment_to_save()) {
				redirect('home/start');
			}else{
				redirect('home/pay');
			}
			

		}else{
			// if user not login go to login
			redirect('user/login');
			
		}
	}

	public function pay(){

		$record = $this->db->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'finish' => 0])->num_rows();

		if ($record > 0) {
    		redirect('user/result_test');
    	} else {
    		$data['page'] = 'home/pay';
    		$data['meta'] = $this->meta->title();
            $data['products'] = $this->product->getRows();
		$this->load->view('layout/layout', $data);
    	}
	}

	public function need_login(){

		$data['page'] = 'home/need_login';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	public function start(){
		$data['page'] = 'home/start';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	///// 1 a)

	public function step1(){
		
		if($this->users->is_login_with_save_step()) {
			if (!$this->users->is_payment_to_save()) {
				redirect('home/pay');
				
			}else{
				$this->users->start_test();
			}
		}
		

		$data['meta'] = $this->meta->title();

		if($this->input->post('next') && (int)$this->input->post('question1')){

			if ((int)$this->input->post('question1') == 1) {

				if ($this->users->is_login_with_save_step()) {
					$this->users->save_step(1, 2, 'red');
				}
								
				redirect('home/step2');

			}elseif((int)$this->input->post('question1') == 2){

				if ($this->users->is_login_with_save_step()) {
					$this->users->save_step(1, 2, 'pink');
				}

				redirect('home/step2');
			}

		}

		$this->load->view('step/step1', $data);
	}

	///// 1 b)
	public function step2(){		

		$data['meta'] = $this->meta->title();

		if($this->input->post('next') && $this->input->post('question2')){

			if ((int)$this->input->post('question2') == 1) {
				if ($this->users->is_login_with_save_step()) {
					$this->users->save_step(2, 2, 'red');
				}
				
				
				redirect('home/step3');

			}elseif((int)$this->input->post('question2') == 2){
				if ($this->users->is_login_with_save_step()) {
					$this->users->save_step(2, 1, 'pink');
				}
				
				redirect('home/step3');
			}

		}


		$this->load->view('step/step2', $data);
	}

	///// 1 c)
	public function step3(){
		if (!$this->users->is_login_with_save_step()) {
			redirect('home/need_login');
		}
			
		$this->users->is_payment();

		$data['meta'] = $this->meta->title();

		if($this->input->post('next') && $this->input->post('question3')){

			if ((int)$this->input->post('question3') == 1) {
				
				$this->users->save_step(3, 1, 'red');
				redirect('home/step4');

			}elseif((int)$this->input->post('question3') == 2){
				$this->users->save_step(3, 1, 'pink');
				redirect('home/step4');
			}

		}


		$this->load->view('step/step3', $data);
	}

	///// 2 a)

	public function step4(){
		$this->users->is_login();

		$data['meta'] = $this->meta->title();

		if($this->input->post('next') && $this->input->post('question4')){

			if ((int)$this->input->post('question4') == 1) {
				
				$this->users->save_step(4, 2, 'yellow');
				redirect('home/step5');

			}elseif((int)$this->input->post('question4') == 2){
				$this->users->save_step(4, 2, 'orange');
				redirect('home/step5');
			}

		}


		$this->load->view('step/step4', $data);
	}

	///// 2 b)
	public function step5(){
		$this->users->is_login();

		$data['meta'] = $this->meta->title();

		if($this->input->post('next') && $this->input->post('question5')){

			if ((int)$this->input->post('question5') == 1) {
				
				$this->users->save_step(5, 1, 'yellow');
				redirect('home/step6');

			}elseif((int)$this->input->post('question5') == 2){
				$this->users->save_step(5, 2, 'orange');
				redirect('home/step6');
			}

		}


		$this->load->view('step/step5', $data);
	}

	///// 2  c)
	public function step6(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question6')){

			if ((int)$this->input->post('question6') == 1) {
			
			$this->users->save_step(6, 2, 'yellow');
			redirect('home/step7');

			}elseif((int)$this->input->post('question6') == 2){
				$this->users->save_step(6, 2, 'orange');
				redirect('home/step7');
			}

			}


			$this->load->view('step/step6', $data);
	}

	///// 3 a)

	public function step7(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question7')){

				if ((int)$this->input->post('question7') == 1) {
				
					$this->users->save_step(7, 2, 'light_blue');
					redirect('home/step8');

				}elseif((int)$this->input->post('question7') == 2){
					$this->users->save_step(7, 2, 'blue');
					redirect('home/step8');
				}
			}


			$this->load->view('step/step7', $data);
	}

	///// 3 b)
	public function step8(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question8')){

				if ((int)$this->input->post('question8') == 1) {
				
					$this->users->save_step(8, 1, 'light_blue');
					redirect('home/step9');

				}elseif((int)$this->input->post('question8') == 2){
					$this->users->save_step(8, 2, 'blue');
					redirect('home/step9');
				}

			}


			$this->load->view('step/step8', $data);
	}

	///// 3 c)
	public function step9(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question9')){

				if ((int)$this->input->post('question9') == 1) {
				
					$this->users->save_step(9, 2, 'light_blue');
					redirect('home/step10');

				}elseif((int)$this->input->post('question9') == 2){
					$this->users->save_step(9, 2, 'blue');
					redirect('home/step10');
				}

			}


			$this->load->view('step/step9', $data);
	}
	//// 4 a
	public function step10(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question10')){

				if ((int)$this->input->post('question10') == 1) {
				
					$this->users->save_step(10, 1, 'brown');
					redirect('home/step11');

				}elseif((int)$this->input->post('question10') == 2){
					$this->users->save_step(10, 2, 'green');
					redirect('home/step11');
				}

			}


			$this->load->view('step/step10', $data);
	}
	///// 4 b)
	public function step11(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question101')){

				if ((int)$this->input->post('question101') == 1) {
				
					$this->users->save_step(11, 1, 'brown');
					redirect('home/step12');

				}elseif((int)$this->input->post('question101') == 2){
					$this->users->save_step(11, 2, 'green');
					redirect('home/step12');
				}

			}


			$this->load->view('step/step101', $data);
	}

	///// 4 c)
	public function step12(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question11')){

				if ((int)$this->input->post('question11') == 1) {
				
					$this->users->save_step(12, 2, 'brown');
					redirect('home/step13');

				}elseif((int)$this->input->post('question11') == 2){
					$this->users->save_step(12, 2, 'green');
					redirect('home/step13');
				}
			}


			$this->load->view('step/step11', $data);
	}

	/// 5 a
	public function step13(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question12')){

				if ((int)$this->input->post('question12') == 1) {
				
					$this->users->save_step(13, 1, 'orange');
					redirect('home/step14');

				}elseif((int)$this->input->post('question12') == 2){
					$this->users->save_step(13, 1, 'yellow');
					redirect('home/step14');
				}

			}


			$this->load->view('step/step12', $data);
	}
	
 	///// 5 b)
	public function step14(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question13')){

				if ((int)$this->input->post('question13') == 1) {
				
					$this->users->save_step(14, 0, 'orange');
					redirect('home/step15');

				}elseif((int)$this->input->post('question13') == 2){
					$this->users->save_step(14, 1, 'yellow');
					redirect('home/step15');
				}

			}


			$this->load->view('step/step13', $data);
	}
	///// 5 c)
	public function step15(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question14')){

				if ((int)$this->input->post('question14') == 1) {
				
					$this->users->save_step(15, 1, 'orange');
					redirect('home/step16');

				}elseif((int)$this->input->post('question14') == 2){
					$this->users->save_step(15, 2, 'yellow');
					redirect('home/step16');
				}

			}


			$this->load->view('step/step14', $data);
	}

	///// 6 a)
	public function step16(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question15')){

				if ((int)$this->input->post('question15') == 1) {
				
					$this->users->save_step(16, 2, 'light_blue');
					redirect('home/step17');

				}elseif((int)$this->input->post('question15') == 2){
					$this->users->save_step(16, 1, 'blue');
					redirect('home/step17');
				}

			}


			$this->load->view('step/step15', $data);
	}

	///// 6 b
	public function step17(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question16')){

				if ((int)$this->input->post('question16') == 1) {
				
					$this->users->save_step(17, 2, 'light_blue');
					redirect('home/step18');

				}elseif((int)$this->input->post('question16') == 2){
					$this->users->save_step(17, 2, 'blue');
					redirect('home/step18');
				}
			}


			$this->load->view('step/step16', $data);
	}

	//// 6 c
	public function step18(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question17')){

				if ((int)$this->input->post('question17') == 1) {
				
					$this->users->save_step(18, 1, 'light_blue');
					redirect('home/step19');

				}elseif((int)$this->input->post('question17') == 2){
					$this->users->save_step(18, 1, 'blue');
					redirect('home/step19');
				}

			}


			$this->load->view('step/step17', $data);
	}
	/// 7 a
	public function step19(){
		$this->users->is_login();

			$data['meta'] = $this->meta->title();

			if($this->input->post('next') && $this->input->post('question18')){

				if ((int)$this->input->post('question18') == 1) {
				
					$this->users->save_step(19, 1, 'red');
					redirect('home/step20');

				}elseif((int)$this->input->post('question18') == 2){
					$this->users->save_step(19, 1, 'pink');
					redirect('home/step20');
				}elseif((int)$this->input->post('question18') == 3){
					$this->users->save_step(19, 0, 'pink');
					redirect('home/step20');
				}

			}


			$this->load->view('step/step18', $data);
	}
	//// 7 b
	public function step20(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question19')){

			if ((int)$this->input->post('question19') == 1) {
				
					$this->users->save_step(20, 2, 'red');
					redirect('home/step21');

				}elseif((int)$this->input->post('question19') == 2){
					$this->users->save_step(20, 2, 'pink');
					redirect('home/step21');
				}
		}

		$this->load->view('step/step19', $data);
	}


	///// 7 c 
	public function step21(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question20')){
			if ((int)$this->input->post('question20') == 1) {
			$this->users->save_step(21, 1, 'red');
			redirect('home/step22');

			}elseif((int)$this->input->post('question20') == 2){
			$this->users->save_step(21, 1, 'pink');
			redirect('home/step22');
			}elseif((int)$this->input->post('question20') == 3){
			$this->users->save_step(21, 0, 'pink');
			redirect('home/step22');
			}
		}
		$this->load->view('step/step20', $data);
	}


	 ///// 8 a
	public function step22(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question21')){
		if ((int)$this->input->post('question21') == 1) {
				
					$this->users->save_step(22, 1, 'red');
					redirect('home/step23');

				}elseif((int)$this->input->post('question21') == 2){
					$this->users->save_step(22, 2, 'pink');
					redirect('home/step23');
				}
		}
		$this->load->view('step/step21', $data);
	}

	//// 8 b

	public function step23(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question22')){
			if ((int)$this->input->post('question22') == 1) {
				
					$this->users->save_step(23, 1, 'red');
					redirect('home/step24');

				}elseif((int)$this->input->post('question22') == 2){
					$this->users->save_step(23, 1, 'pink');
					redirect('home/step24');
				}
		}
		$this->load->view('step/step22', $data);
	}


	//// 9 a
	public function step24(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question23')){
			if ((int)$this->input->post('question23') == 1) {
				
					$this->users->save_step(24, 2, 'light_blue');
					redirect('home/step25');

				}elseif((int)$this->input->post('question23') == 2){
					$this->users->save_step(24, 1, 'blue');
					redirect('home/step25');
				}
		}
		$this->load->view('step/step23', $data);
	}


	//// 9 b
	public function step25(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question24')){
			if ((int)$this->input->post('question24') == 1) {
				
					$this->users->save_step(25, 1, 'light_blue');
					redirect('home/step26');

				}elseif((int)$this->input->post('question24') == 2){
					$this->users->save_step(25, 0, 'blue');
					redirect('home/step26');
				}
		}
		$this->load->view('step/step24', $data);
	}


	////// 10 a
	public function step26(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question25')){
			if ((int)$this->input->post('question25') == 1) {
				
					$this->users->save_step(26, 1, 'yellow');
					redirect('home/step27');

				}elseif((int)$this->input->post('question25') == 2){
					$this->users->save_step(26, 2, 'orange');
					redirect('home/step27');
				}
		}
		$this->load->view('step/step25', $data);
	}
	/////// part 2 -- 1 a

	public function step27(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question26')){
			if ((int)$this->input->post('question26') == 1) {
				
					$this->users->save_step(27, 2, 'red');
					redirect('home/step28');

				}elseif((int)$this->input->post('question26') == 2){
					$this->users->save_step(27, 2, 'pink');
					redirect('home/step28');
				}
		}
		$this->load->view('step/step26', $data);
	}
	/// 1 b
	public function step28(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question27')){
			if ((int)$this->input->post('question27') == 1) {
				
					$this->users->save_step(28, 2, 'red');
					redirect('home/step29');

				}elseif((int)$this->input->post('question27') == 2){
					$this->users->save_step(28, 2, 'pink');
					redirect('home/step29');
				}
		}
		$this->load->view('step/step27', $data);
	}
	// 1 c
	public function step29(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question28')){
			if ((int)$this->input->post('question28') == 1) {
				
					$this->users->save_step(29, 2, 'red');
					redirect('home/step30');

				}elseif((int)$this->input->post('question28') == 2){
					$this->users->save_step(29, 2, 'pink');
					redirect('home/step30');
				}
		}
		$this->load->view('step/step28', $data);
	}
	// 2 a
	public function step30(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question29')){
			if ((int)$this->input->post('question29') == 1) {
				
					$this->users->save_step(30, 2, 'yellow');
					redirect('home/step31');

				}elseif((int)$this->input->post('question29') == 2){
					$this->users->save_step(30, 1, 'orange');
					redirect('home/step31');
				}
		}
		$this->load->view('step/step29', $data);
	}
	// 2 b
	public function step31(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question30')){
			if ((int)$this->input->post('question30') == 1) {
				
					$this->users->save_step(31, 2, 'yellow');
					redirect('home/step32');

				}elseif((int)$this->input->post('question30') == 2){
					$this->users->save_step(31, 1, 'orange');
					redirect('home/step32');
				}
		}
		$this->load->view('step/step30', $data);
	}
	// 2 c
	public function step32(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question31')){
			if ((int)$this->input->post('question31') == 1) {
				
					$this->users->save_step(32, 1, 'yellow');
					redirect('home/step33');

				}elseif((int)$this->input->post('question31') == 2){
					$this->users->save_step(32, 2, 'orange');
					redirect('home/step33');
				}
		}
		$this->load->view('step/step31', $data);
	}
	// 2 d
	public function step33(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question32')){
			if ((int)$this->input->post('question32') == 1) {
				
					$this->users->save_step(33, 1, 'yellow');
					redirect('home/step34');

				}elseif((int)$this->input->post('question32') == 2){
					$this->users->save_step(33, 1, 'orange');
					redirect('home/step34');
				}
		}
		$this->load->view('step/step32', $data);
	}
	// 3 a
	public function step34(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question33')){
			if ((int)$this->input->post('question33') == 1) {
				
					$this->users->save_step(34, 2, 'light_blue');
					redirect('home/step35');

				}elseif((int)$this->input->post('question33') == 2){
					$this->users->save_step(34, 2, 'blue');
					redirect('home/step35');
				}
		}
		$this->load->view('step/step33', $data);
	}
	// 3 b
	public function step35(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question34')){
			if ((int)$this->input->post('question34') == 1) {
				
					$this->users->save_step(35, 1, 'light_blue');
					redirect('home/step36');

				}elseif((int)$this->input->post('question34') == 2){
					$this->users->save_step(35, 2, 'blue');
					redirect('home/step36');
				}
		}
		$this->load->view('step/step34', $data);
	}
	// 3 c
	public function step36(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question35')){
			if ((int)$this->input->post('question35') == 1) {
				
					$this->users->save_step(36, 1, 'light_blue');
					redirect('home/step37');

				}elseif((int)$this->input->post('question35') == 2){
					$this->users->save_step(36, 1, 'blue');
					redirect('home/step37');
				}
		}
		$this->load->view('step/step35', $data);
	}
	// 4 a
	public function step37(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question36')){
			if ((int)$this->input->post('question36') == 1) {
				
					$this->users->save_step(37, 2, 'green');
					redirect('home/step38');

				}elseif((int)$this->input->post('question36') == 2){
					$this->users->save_step(37, 1, 'brown');
					redirect('home/step38');
				}
		}
		$this->load->view('step/step36', $data);
	}
	// 4 b
	public function step38(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question37')){
			if ((int)$this->input->post('question37') == 1) {
				
					$this->users->save_step(38, 1, 'green');
					redirect('home/step39');

				}elseif((int)$this->input->post('question37') == 2){
					$this->users->save_step(38, 2, 'brown');
					redirect('home/step39');
				}
		}
		$this->load->view('step/step37', $data);
	}
	// 4 c
	public function step39(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question38')){
			if ((int)$this->input->post('question38') == 1) {
				
					$this->users->save_step(39, 1, 'green');
					redirect('home/step40');

				}elseif((int)$this->input->post('question38') == 2){
					$this->users->save_step(39, 2, 'brown');
					redirect('home/step40');
				}
		}
		$this->load->view('step/step38', $data);
	}
	// 4 d
	public function step40(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question39')){
			if ((int)$this->input->post('question39') == 1) {
				
					$this->users->save_step(40, 2, 'green');
					redirect('home/step41');

				}elseif((int)$this->input->post('question39') == 2){
					$this->users->save_step(40, 1, 'brown');
					redirect('home/step41');
				}
		}
		$this->load->view('step/step39', $data);
	}
	// 5 a
	public function step41(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question40')){
			if ((int)$this->input->post('question40') == 1) {
				
					$this->users->save_step(41, 0, 'orange');
					redirect('home/step42');

				}elseif((int)$this->input->post('question40') == 2){
					$this->users->save_step(41, 2, 'yellow');
					redirect('home/step42');
				}
		}
		$this->load->view('step/step40', $data);
	}
	// 5 b
	public function step42(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question41')){
			if ((int)$this->input->post('question41') == 1) {
				
					$this->users->save_step(42, 0, 'orange');
					redirect('home/step43');

				}elseif((int)$this->input->post('question41') == 2){
					$this->users->save_step(42, 2, 'yellow');
					redirect('home/step43');
				}
		}
		$this->load->view('step/step41', $data);
	}
	// 5 c
	public function step43(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question42')){
			if ((int)$this->input->post('question42') == 1) {
				
					$this->users->save_step(43, 0, 'orange');
					redirect('home/step44');

				}elseif((int)$this->input->post('question42') == 2){
					$this->users->save_step(43, 2, 'yellow');
					redirect('home/step44');
				}
		}
		$this->load->view('step/step42', $data);
	}
	// 6 a
	public function step44(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question43')){
			if ((int)$this->input->post('question43') == 1) {
				
					$this->users->save_step(44, 1, 'green');
					redirect('home/step45');

				}elseif((int)$this->input->post('question43') == 2){
					$this->users->save_step(44, 1, 'brown');
					redirect('home/step45');
				}
		}
		$this->load->view('step/step43', $data);
	}
	// 6 b
	public function step45(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question44')){
			if ((int)$this->input->post('question44') == 1) {
				
					$this->users->save_step(45, 1, 'green');
					redirect('home/step46');

				}elseif((int)$this->input->post('question44') == 2){
					$this->users->save_step(45, 1, 'brown');
					redirect('home/step46');
				}
		}
		$this->load->view('step/step44', $data);
	}
	// 6 c
	public function step46(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question45')){
			if ((int)$this->input->post('question45') == 1) {
				
					$this->users->save_step(46, 2, 'green');
					redirect('home/step47');

				}elseif((int)$this->input->post('question45') == 2){
					$this->users->save_step(46, 0, 'brown');
					redirect('home/step47');
				}
		}
		$this->load->view('step/step45', $data);
	}
	// 6 d
	public function step47(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question46')){
			if ((int)$this->input->post('question46') == 1) {
				
					$this->users->save_step(47, 2, 'green');
					redirect('home/step48');

				}elseif((int)$this->input->post('question46') == 2){
					$this->users->save_step(47, 0, 'brown');
					redirect('home/step48');
				}
		}
		$this->load->view('step/step46', $data);
	}
	// 7 a
	public function step48(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question47')){
			if ((int)$this->input->post('question47') == 1) {
				
					$this->users->save_step(48, 0, 'brown');
					redirect('home/step49');

				}elseif((int)$this->input->post('question47') == 2){
					$this->users->save_step(48, 2, 'green');
					redirect('home/step49');
				}
		}
		$this->load->view('step/step47', $data);
	}
	// 7 b
	public function step49(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question48')){
			if ((int)$this->input->post('question48') == 1) {
				
					$this->users->save_step(49, 1, 'brown');
					redirect('home/step50');

				}elseif((int)$this->input->post('question48') == 2){
					$this->users->save_step(49, 2, 'green');
					redirect('home/step50');
				}
		}
		$this->load->view('step/step48', $data);
	}
	// 7c
	public function step50(){
		$this->users->is_login();
		$data['meta'] = $this->meta->title();
		if($this->input->post('next') && $this->input->post('question49')){
			if ((int)$this->input->post('question49') == 1) {
				
					$this->users->save_step(50, 1, 'brown');
					$this->users->finnish_test();
					redirect('user/result_test');

				}elseif((int)$this->input->post('question49') == 2){
					$this->users->save_step(50, 2, 'green');
					$this->users->finnish_test();
					redirect('user/result_test');
				}
		}
		$this->load->view('step/step49', $data);
	}

	



	
}
