<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Paypal extends CI_Controller 
{
     function  __construct(){
        parent::__construct();
        $this->load->library('paypal_lib');
        $this->load->model('product');
     }
     
     function success(){
        //get the transaction data
        $paypalInfo    = $this->input->post();
//        $paypalInfo = $this->input->get();

        //print_r($paypalInfo);
        
        $data['item_name']      = $paypalInfo['item_name'];
        $data['item_number']    = $paypalInfo['item_number'];
        $data['txn_id']         = $paypalInfo["txn_id"];
        $data['payment_amt']    = $paypalInfo["mc_gross"];
        $data['currency_code']  = $paypalInfo["mc_currency"];
        $data['status']         = $paypalInfo["payment_status"];

		if(isset($paypalInfo['custom'])){
		    /*
		    payment_id
user_id
product_id
txn_id
payment_gross
currency_code
payer_email
payment_status
internalcode
date
order_id
*/
        $this->db->insert(' payments', 
                ['user_id' => $paypalInfo['custom'], 
                //['user_id' => $this->session->userdata('loged_id'), 
                'product_id' => $paypalInfo['item_number'], 
                'txn_id'=> $paypalInfo["txn_id"],
                'internalcode'=> $paypalInfo['custom'],
                'payment_gross'=> $paypalInfo['mc_gross'],
                'payer_email'=> $paypalInfo['payer_email'],
                'currency_code'=> $paypalInfo['mc_currency'],
                'ventor'=> 'PayPal',
                'date' => time()
                ]);	


			$this->db->where('internalcode', $paypalInfo['custom']);
			$this->db->set('code', $paypalInfo["txn_id"]);
			$this->db->set('payment', 1);
	        $this->db->update('tests');
    		$data['page'] = 'user/paypal_success';




        } else {
            $this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');
    		$data['page'] = 'paypal/cancel';
        }
        
        
        //pass the transaction data to view
        //$this->users->start_test();
		//$data['page'] = 'user/paypal_success';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);  
     }
     
     
     function cancel(){
            $this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');
		$data['page'] = 'paypal/cancel';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);  

     }
     
     function ipn(){
        //paypal return transaction details array
        $paypalInfo    = $this->input->post();
        
        print_r($paypalInfo);
        
        $data['user_id'] = $paypalInfo['custom'];
        $data['product_id']    = $paypalInfo["item_number"];
        $data['txn_id']    = $paypalInfo["txn_id"];
        $data['payment_gross'] = $paypalInfo["mc_gross"];
        $data['currency_code'] = $paypalInfo["mc_currency"];
        $data['payer_email'] = $paypalInfo["payer_email"];
        $data['payment_status']    = $paypalInfo["payment_status"];

        $paypalURL = $this->paypal_lib->paypal_url;        
        $result    = $this->paypal_lib->curlPost($paypalURL,$paypalInfo);
        
        //check whether the payment is verified
        if(preg_match("/VERIFIED/i",$result)){
            //insert the transaction data into the database
            $this->product->insertTransaction($data);
        }
    }

/*
     function ipn(){
        // Paypal posts the transaction data
        $paypalInfo = $this->input->post();
                
        echo 'IPN-PAYPALINFO:\n';
        print_r($paypalInfo);
        
        if(!empty($paypalInfo)){
            // Validate and get the ipn response
            $ipnCheck = $this->paypal_lib->validate_ipn($paypalInfo);

            // Check whether the transaction is valid
            if($ipnCheck){
                // Insert the transaction data in the database
                $data['user_id']        = $paypalInfo["custom"];
                $data['product_id']        = $paypalInfo["item_number"];
                $data['txn_id']            = $paypalInfo["txn_id"];
                $data['payment_gross']    = $paypalInfo["mc_gross"];
                $data['currency_code']    = $paypalInfo["mc_currency"];
                $data['payer_email']    = $paypalInfo["payer_email"];
                $data['payment_status'] = $paypalInfo["payment_status"];

                $this->product->insertTransaction($data);
            }
        }
    }
*/
    
    
    
}