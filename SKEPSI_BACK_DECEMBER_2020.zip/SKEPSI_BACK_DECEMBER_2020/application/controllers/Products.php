<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Products extends CI_Controller
{
    function  __construct() {
        parent::__construct();
        $this->load->library('paypal_lib');
        $this->load->model('product');
    }
    
    function index(){
        $data = array();
        //get products data from database
        $data['products'] = $this->product->getRows();
        //pass the products data to view
        $this->load->view('products/index', $data);
    }

    function buy($id){
        // Set variables for paypal form
        $returnURL = base_url().'paypal/success';
        $cancelURL = base_url().'paypal/cancel';
        $notifyURL = base_url().'paypal/ipn';
        
        // Get product data from the database
        $product = $this->product->getRows($id);
        
        // Get current user ID from the session
        $userID = $this->session->userdata('loged_id');
        // Add fields to paypal form
        $this->paypal_lib->add_field('return', $returnURL);
        $this->paypal_lib->add_field('cancel_return', $cancelURL);
        $this->paypal_lib->add_field('notify_url', $notifyURL);
        $this->paypal_lib->add_field('item_name', $product['name']);
        $this->paypal_lib->add_field('custom', $userID);
        $this->paypal_lib->add_field('item_number',  $product['id']);
//        $this->paypal_lib->add_field('amount',  $product['price']);
        $this->paypal_lib->add_field('amount',  $this->config->item('test_cost'));
        $this->paypal_lib->add_field('LOCALECODE',  'el-GR');
        
        
        $myval=uniqid();
        $this->paypal_lib->add_field('custom',  $myval);
        
        $this->db->insert('tests', 
                ['u_id' => $this->session->userdata('loged_id'), 
                'finish' => 0, 
                'payment'=> 0,
                'internalcode' => $myval,
                'date' => time()
                ]);	

        // Render paypal form
        $this->paypal_lib->paypal_auto_form();
    }    
}