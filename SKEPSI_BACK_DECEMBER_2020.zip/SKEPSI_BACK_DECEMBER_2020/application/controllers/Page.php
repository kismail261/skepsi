<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends CI_Controller{

	public function __construct() {        
    	parent::__construct();
	}


	public function payways(){
		$data['page'] = 'page/payways';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	public function terms(){
		$data['page'] = 'page/terms';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function professional(){
		$data['page'] = 'page/professional';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function student(){
		$data['page'] = 'page/student';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function team(){
		$data['page'] = 'page/team';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function what(){
		$data['page'] = 'page/what';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function who(){
		$data['page'] = 'page/who';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}


	public function more(){
		$data['page'] = 'page/more';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function papageorgiou(){
		$data['page'] = 'page/papageorgiou';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}

	public function mouratidis(){
		$data['page'] = 'page/mouratidis';
		$data['meta'] = $this->meta->title();


		$this->load->view('layout/layout', $data);
	}



}
