<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller{

	public function __construct() {        
    	parent::__construct();
    	$this->config->set_item('language', 'greek');

	}


	public function register(){

		$data['page'] = 'user/register';
		$data['meta'] = $this->meta->title();

		if($this->input->post('register')){

			$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
			$this->form_validation->set_rules('password', $this->users->echo_lang_text('Your password','Κωδικός πρόσβασης'), 'required|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('repassword', $this->users->echo_lang_text('Retype Your password','Επανάλληψη κωδικού πρόσβασης'), 'required|matches[password]');
			$this->form_validation->set_rules('gender', $this->users->echo_lang_text('Gender','Φύλο'), 'required');
			$this->form_validation->set_rules('year', $this->users->echo_lang_text('Birth Year','Έτος γέννησης'), 'required');

			if($this->form_validation->run() == FALSE){
				
			}else{
				$this->users->register($this->input->post('email'), $this->input->post('password'), $this->input->post('gender'), $this->input->post('year'));
				redirect('home/start');
			}
		}


		$this->load->view('layout/layout', $data);
	}
	
	public function setlangen(){
		$this->session->set_userdata('mylang', 'english');
		$this->config->set_item('language', 'english');
		redirect($this->session->userdata('curreturl'));
	}

	public function setlanggr(){
		$this->session->set_userdata('mylang', 'greek');
		$this->config->set_item('language', 'greek');
		redirect($this->session->userdata('curreturl'));
	}

	public function login(){

		$data['page'] = 'user/login';
		$data['meta'] = $this->meta->title();

		if($this->input->post('login')){
			$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|callback_email_check');
			$this->form_validation->set_rules('password', $this->users->echo_lang_text('Your password','Κωδικός πρόσβασης'), 'trim|required');

			if($this->form_validation->run() == FALSE){

			}else{

				$this->session->set_userdata('login', true);
				$this->session->set_userdata('loged_id', $this->db->get_where('users', ['email' => $this->input->post('email')])->row('id'));
				
			$this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');

				redirect('home/start');
				
			}
		}

		$this->load->view('layout/layout', $data);
	}

	public function logout(){

		$this->session->unset_userdata('login');
		$this->session->unset_userdata('loged_id');
		redirect('home/index');
	}

	public function email_check($email){

		$password = $this->input->post('password');

		if($this->users->login($email, $password)){
			return true;
		}else{
			$this->form_validation->set_message('email_check', $this->users->echo_lang_text('Wrong email or Password','Λάθος email ή κωδικός πρόσβασης'));
			return false;
		}
	}


	public function success_login(){
		$data['page'] = 'user/success_login';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);
	}

	public function account(){
	    if($this->users->is_login_return_boolean()) {
			$this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');
	    

		$data['page'] = 'user/account';
		$data['meta'] = $this->meta->title();
	    } else {
		    $data['page'] = 'user/login';
    		$data['meta'] = $this->meta->title();
	        
	    }
		$this->load->view('layout/layout', $data);
	}

	public function pass_change(){

		$data['page'] = 'user/pass_change';
		$data['meta'] = $this->meta->title();

		if($this->input->post('pass_change')) {
			$this->form_validation->set_rules('oldpassword', $this->users->echo_lang_text('Old Password','Παλιός κωδικός πρόσβασης'), 'required|callback_password_check');
			$this->form_validation->set_rules('newpassword', $this->users->echo_lang_text('New Password','Νέος κωδικός πρόσβασης'), 'required|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('renewpassword', $this->users->echo_lang_text('Retype New Password','Επανάληψη νέου κωδικός πρόσβασης'), 'required|matches[newpassword]');


			if($this->form_validation->run() == FALSE){

			}else{
				if($this->users->pass_change($this->input->post('newpassword'))) {
					$this->session->set_flashdata('message', $this->users->echo_lang_text('Your password has changed!','Ο Κωδικός πρόσβασης άλλαξε!'));
				}
				
			}
		}

		


		$this->load->view('layout/layout', $data);
	}

	public function forgot_pass(){
		$data['page'] = 'user/forgot_pass';
		$data['meta'] = $this->meta->title();


		if ($this->input->post('sent')) {
		    

			$this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_exist');
			

			if($this->form_validation->run() == FALSE ){

            }else{

				$user_email = $this->db->get_where('users', ['email' => $this->input->post('email')])->row();
				
                $addresmail=$user_email->email;
                $this->load->library('email');
                $this->config->item('language');
                /*//$this->email->from('testforSKEPSI@agan.gr', 'TestForSkepsi');*/
                $this->email->from($this->config->item('sender_email'), $this->config->item('sender_name'));
                $this->email->to($addresmail);
                $this->email->set_header("MIME-Version","1.0"."\r\n");
                $this->email->set_header("Content-type","text/html;charset=UTF-8" . "\r\n");
                $this->email->cc('');
                $this->email->bcc('');
                $this->email->subject($this->users->echo_lang_text('Reset Password','Ακύρωση κωδικού'));
                $this->email->message($this->users->echo_lang_text('Please press the follow link to <b>Reset</b> your Password :','<b>Παρακαλώ</b> πατήστε <i>στο παρακάτω</i> link για να <b>ακυρώσετε</b> τον κωδικό σας: ').anchor(site_url('user/pass_reset/'. $user_email->id.'/'.$user_email->email), $this->users->echo_lang_text('Link','Σύνδεσμος')));
                //$this->email->send();

				if($this->email->send()){
					//$mailer->ErrorInfo;
					//redirect('user/forgot_pass');
					$this->session->set_flashdata('messagemail', $this->users->echo_lang_text('Successs, your password canceled. You will receive an email in a few minutes.','Επιτυχής ακύρωση κωδικού! Σε λίγα λεπτά θα λάβετε ένα email.'));
					redirect('user/forgot_pass');
					
				}else{
					$this->session->set_flashdata('messagemail', $this->users->echo_lang_text('Error to send email. Try again','Λάθος στην αποστολή email. Προσπάθησε πάλι'));
					redirect('user/forgot_pass');
				}
			}
		}

		$this->load->view('layout/layout', $data);
	}

	public function pass_reset($id = null, $email = null){

		$data['page'] = 'user/pass_reset';
		$data['meta'] = $this->meta->title();

		if((int)$id && $email){
			$user = $this->db->get_where('users', ['id' => (int)$id, 'email' => $email])->row();

			if(!$user) {
				
				redirect('home/index');
				
			}


		if ($this->input->post('change')) {
			$this->form_validation->set_rules('password', $this->users->echo_lang_text('New Password','Νέος κωδικός πρόσβασης'), 'required|min_length[5]|max_length[12]');
			$this->form_validation->set_rules('repassword', $this->users->echo_lang_text('Retype New Password','Επανάληψη νέου κωδικός πρόσβασης'), 'required|matches[password]');

			if($this->form_validation->run() == FALSE){

			}else{
				$this->db->where('id', $user->id);
				$this->db->update('users', ['password' => md5($this->input->post('password'))]);
				$this->session->set_flashdata('messagemail', $this->users->echo_lang_text('Success! Your password has changed','Επιτυχής αλλαγή κωδικού πρόσβασης.'));
				redirect('user/pass_reset/' . $id . '/' . $email);
			}
		}


			$this->load->view('layout/layout', $data);
		}
	}

	public function email_exist($email = null)
    {
            if($email){
                $user = $this->db->get_where('users', ['email' => $email])->num_rows();

                if($user){
                	return TRUE;                    	
                }else{
                	$this->form_validation->set_message('required', $this->users->echo_lang_text('This email is unknown.','Το email που εισάγετε είναι άγνωστο.'));
                	return FALSE;
                }
                
            }
    }


	public function email_change(){

		$data['page'] = 'user/email_change';
		$data['email'] = $this->users->get_email();
		$data['meta'] = $this->meta->title();

		if($this->input->post('email_change')) {

			if($this->input->post('newemail') == $this->users->get_email()){
				$yourself = '';
			}else{
				$yourself = '|is_unique[users.email]';
			}

			$this->form_validation->set_rules('newemail', 'Νέο email', 'required|valid_email' . $yourself);


			if($this->form_validation->run() == FALSE){

			}else{
				if($this->users->change_email($this->input->post('newemail'))) {
					$this->session->set_flashdata('message', $this->users->echo_lang_text('Your  email is changed.','Το email σας άλλαξε!'));
					redirect('user/email_change');
				}
				
			}
		}

		$this->load->view('layout/layout', $data);
	}


	public function password_check($password){
		$user = $this->db->get_where('users', ['id' => (int)$this->session->userdata('loged_id'), 'password' => md5($password)])->num_rows();

		if($user > 0 && $user == 1) {
			return true;
		}else{
			$this->form_validation->set_message('password_check', $this->users->echo_lang_text('Wrong Old Password','Ο παλιός κωδικός πρόσβασης είναι λάθος.') . '<a href="'.site_url('user/forgot_pass').'">'.$this->users->echo_lang_text('Forgot my Password','Ξέχασα τον κωδικό μου').'</a>');
			return false;
		}
	}

	public function result_test(){
	    
			$this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');
	    
	    
		$data['page'] = 'user/result_test';
		$data['meta'] = $this->meta->title();
		$data['tests'] = $this->users->get_tests();
		$this->load->view('layout/layout', $data);
	}

	public function show_test($id = null){
		if(!(int)$id) {
			redirect('home/index');
		}

		$data['page'] = 'user/show_test';
		$data['meta'] = $this->meta->title();
		$data['test'] = $this->users->get_test($id);
		$data['letter'] = $this->users->get_by_letter($id);
		
		$this->load->view('layout/layout', $data);
	}

	public function payment(){

	//$this->users->start_test();

	// The POST URL and parameters


    $config['sandbox'] = TRUE; // FALSE for live environment
    if($this->config->item('viva_sandbox') == TRUE){
	    $request =  'https://demo.vivapayments.com/api/orders';
    	$MerchantId = $this->config->item('viva_merchantid_sandbox');
    	$APIKey =  $this->config->item('viva_apikey_sandbox'); 	
    	$Amount = 100*$this->config->item('test_cost');	
        $Source = $this->config->item('viva_source_sandbox'); 
//        $urlredirect='https://demo.vivapayments.com/web/newtransaction.aspx?ref=';     
        $urlredirect='https://demo.vivapayments.com/web/checkout?ref=';     
    } else {
    	$request =  'https://www.vivapayments.com/api/orders';
    	$MerchantId = $this->config->item('viva_merchantid');
	    $APIKey = $this->config->item('viva_apikey'); 	
    	$Amount = 100*$this->config->item('test_cost');
	    $Source = $this->config->item('viva_source'); 
	    $urlredirect='http://www.vivapayments.com/web/newtransaction.aspx?ref=';      
	    
    }
    // /api/transactions/?ordercode=
	// Your merchant ID and API Key can be found in the 'Security' settings on your profile.
    $mycodee='121314'; //rand(10000, 300000);
    $this->session->set_userdata('mycodee',$mycodee);
	//Set the Payment Amount

	//Set some optional parameters (Full list available here: https://github.com/VivaPayments/API/wiki/Optional-Parameters)
	$AllowRecurring = 'false'; // This flag will prompt the customer to accept recurring payments in tbe future.
	$RequestLang = $this->users->echo_lang_text('en-US','el-GR'); //This will display the payment page in English (default language is Greek)
	    // This will assign the transaction to the Source with Code = "Default". If left empty, the default source will be used.
    
    $myval=uniqid();

	$postargs = 'Amount='.urlencode($Amount).'&AllowRecurring='.$AllowRecurring.'&RequestLang='.$RequestLang.'&SourceCode='.$Source.'&actionUser='.$this->session->userdata('loged_id');

	// Get the curl session object
	$session = curl_init($request);


	// Set the POST options.
	curl_setopt($session, CURLOPT_POST, true);
	curl_setopt($session, CURLOPT_POSTFIELDS, $postargs);
	curl_setopt($session, CURLOPT_HEADER, true);
	curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($session, CURLOPT_USERPWD, $MerchantId.':'.$APIKey);
	curl_setopt($session, CURLOPT_SSLVERSION, CURL_SSLVERSION_TLSv1);

	// Do the POST and then close the session
	$response = curl_exec($session);

	// Separate Header from Body
	$header_len = curl_getinfo($session, CURLINFO_HEADER_SIZE);
	$resHeader = substr($response, 0, $header_len);
	$resBody =  substr($response, $header_len);

	curl_close($session);

	// Parse the JSON response
	try {
	if(is_object(json_decode($resBody))){
	$resultObj=json_decode($resBody);
	}else{
	preg_match('#^HTTP/1.(?:0|1) [\d]{3} (.*)$#m', $resHeader, $match);
	throw new Exception("API Call failed! The error was: ".trim($match[1]));
	}
	} catch( Exception $e ) {
	echo $e->getMessage();
	}

//echo 'ERRR='.$resultObj->ErrorCode.'----'.$resultObj->OrderCode.'----'.$this->session->userdata('loged_id');
	if ($resultObj->ErrorCode==0){	//success when ErrorCode = 0

		$this->session->set_userdata('hash', $resultObj->OrderCode);
        $this->db->insert('tests', 
                ['u_id' => $this->session->userdata('loged_id'), 
                'finish' => 0, 
                'payment'=> 0,
                'code' => $this->session->userdata('hash'),
                'date' => time()
                ]);				
/*
        $this->db->where('u_id', $this->session->userdata('loged_id'));
		$this->db->where('payment', 0);
		$this->db->where('finish', 0);
		$this->db->order_by('id', 'DESC');
		$this->db->limit(1);
		//$test = $this->db->get('tests')->row('id');
		
		$this->db->where('id', $test);
		$this->db->set('code', $this->session->userdata('hash'));
		$this->db->update('tests');
*/


		redirect($urlredirect.$resultObj->OrderCode);
	}

	else{
	    echo 'The following error occured: ' . $resultObj->ErrorText;
	}

	}


	public function viva_success(){
		if(isset($_GET['s'])){

        $this->db->insert(' payments', 
                ['user_id' => $this->session->userdata('loged_id'), 
                'order_id' => $_GET['s'], 
                'txn_id'=> $_GET['t'],
                'ventor'=> 'VivaPayments',
                'date' => time()
                ]);	

			$this->db->where('code', $_GET['s']);
			$this->db->set('payment', 1);
			//$this->db->set('payment', 1);
	        $this->db->update('tests');
    		$data['page'] = 'user/viva_success';

        } else {
            $this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');
    		$data['page'] = 'user/viva_fails';
        }

		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);        
	}
	
	
	public function viva_fails(){
            $this->db->where('u_id', $this->session->userdata('loged_id'));
    		$this->db->where('payment', 0);
            $this->db->delete('tests');
		$data['page'] = 'user/viva_fails';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);        
	}

	public function payment_success(){
		if(isset($_GET['s'])){
			$this->db->where('code', $_GET['s']);
			$this->db->set('payment', 1);
	        $this->db->update('tests');
		}
		
		$data['page'] = 'user/payment_success';
		$data['meta'] = $this->meta->title();
		$this->load->view('layout/layout', $data);        
	}


	public function add_groupon(){		
		$data['page'] = 'user/add_groupon';
		$data['meta'] = $this->meta->title();

		if($this->input->post('add')){

			if ($this->users->is_login_with_save_step()) {

				$code = (int)$this->db->get_where('groupons', ['code' => $this->input->post('groupon'), 'used' => 0])->num_rows();
				/*
				$asset = (int)$this->db->get_where('groupons', ['code' => $this->input->post('groupon'), 'used' => 1, 'assets' => 0])->num_rows();
				*/
				if ($code == 1)  {

					$this->db->where('code', $this->input->post('groupon'));
					$this->db->update('groupons', ['u_id' => (int)$this->session->userdata('loged_id'), 'used' => 1]);
					
					$record = $this->db->get_where('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'finish' => 0])->num_rows();

					if ($record == 0) {
            			$this->db->insert('tests', ['u_id' => (int)$this->session->userdata('loged_id'), 'finish' => 0, 'date' => time(), 'payment' => 1]);
            			redirect('user/groupon_success');
        			}

        		}
        		
			}
			
		}
		
		$this->load->view('layout/layout', $data);        
	}

	public function groupon_success(){
		$data['page'] = 'user/groupon_success';
		$data['meta'] = $this->meta->title();

		if(!$this->users->is_login_with_save_step()){
			redirect('home/index');
		}

		$this->load->view('layout/layout', $data);    
	}

}





     