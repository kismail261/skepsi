$(document).ready(function(){

    $("li").hover(function(){
        var dropdownMenu = $(this).children("a");
        if(dropdownMenu.is(":visible")){
            dropdownMenu.parent().toggleClass("open");
        }

    });  
    
    clearForm('form');                    
    function clearForm(form) {
      $(':input', form).each(function() {
        var type = this.type;
        var tag = this.tagName.toLowerCase(); // normalize case
        if (type == 'text' || type == 'password' || tag == 'textarea')
          this.value = "";
        else if (type == 'checkbox' || type == 'radio')
          this.checked = false;
        else if (tag == 'select')
          this.selectedIndex = -1;
      });
    }    
    
	if( $('#rotate').length) {
	  	var i = 0

		setInterval(function(){
		 var array = [rndmess1,rndmess2,rndmess3,rndmess4];
		 var element = document.getElementById('rotate');
		 element.innerHTML = array[i]
		 if (i == array.length -1) {
		   i = 0
		 } else {
		    i = i + 1
		 }
		}, 3000);

	}
	
	$("#english").click(function(){
		var title = 'english';
		var description = '';
        $.ajax({
           url: requesturl,
           type: 'POST',
           data: {title: title, description: description},
           error: function() {
              alert('Something is wrong');
           },
           success: function(data) {
           }
        });
		location.reload();
		console.log('english');		
    }); 
	
	$("#greek").click(function(){
		var title = 'greek';
		var description = '';
        $.ajax({
           url: requesturl,
           type: 'POST',
           data: {title: title, description: description},
           error: function() {
              alert('Something is wrong');
           },
           success: function(data) {
           }
        });
		location.reload();
		console.log('greek');
    }); 

     $("input[name=acceptrule]").click(function(){
         if ($(this).is(":checked"))
            {
    	        console.log('CHECKED');
    	        $("#paybutton").attr("disabled", false);
            } else {
    	        $("#paybutton").attr("disabled", true);
            }
    	        
//    	        console.log($('#check_id').val());
    	        //$('#btnSubmit').attr("disabled", false);
    });

    var valerrostxt = $('div.valerrors').text();
    if(valerrostxt.trim() ===''){
        $('div.valerrors').css("background-color","black");    
    }

    var timeflag = true;
    setInterval(function () {
        if (timeflag){
           	$( "div" ).each( function( index, el ) {
              	if ($( el ).hasClass("flashmess")){
              	    timeflag = false;
                    setTimeout(function() { 
                        $("div.flashmess").remove();
                            clearForm('form');                   
                        //location.reload();
                    }, 3000);
            	}
        	});        
        }
    }, 500);	
    

});